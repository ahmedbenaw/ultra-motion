# ULTRA Motion development preview

ULTRA Motion is a working title. Public naming and native-host qualification remain pending. This development build adds portable product and decision projects alongside the existing media runtime. See [implementation status](docs/build-status.md) and [export support](docs/exports.md) for the exact implemented scope and remaining gates.

## Start a portable project

```sh
python3 scripts/project.py init --project projects/my-engagement --name "My engagement" --preset client-engagement
python3 scripts/project.py plan --project projects/my-engagement
python3 scripts/project.py preview --project projects/my-engagement
python3 scripts/project.py serve --project projects/my-engagement
```

`serve` prints an optional loopback preview URL. The native-file snapshot works without a server and downloads command proposals. Voice remains your host's input capability, not a microphone implementation in this preview.

Define the example work packages with `define-jobs --file examples/work-packages.json --revision REVISION`. Review the complete plan and record its digest through an `approve` command with the approving actor before running jobs. Use `run --background` for a real local worker, then `status`. See the [runtime contract](skills/engagement-director/references/runtime-contract.md).

An approved `render_proof` work package now makes checked, short MP4, transparent MOV or PNG drafts from supported Moments. `quantitative_check` recomputes explicitly supplied source-linked calculations. Neither output substitutes for content review. For GitHub-selected projects, `branch-init`, `branch-save`, `branch-restore` and `branch-push` provide explicit branch storage; remote push needs your configured private GitHub repository and credentials. The local project room can display generated media and lets you choose a starting recipe.

## Existing media workflows

### Reelcraft

Reelcraft turns a product brief into an approved shot plan, then builds and reviews a motion reel or a shorter B-roll sequence where a video runtime is available. The package contains eight skills across Claude and ChatGPT/Codex. The renderer is a local toolchain; installing instructions alone does not install ffmpeg, Chromium, or Python packages on a user's computer.

## Who it is for

| User | Typical request | Useful output |
| --- | --- | --- |
| Founder or product team | Announce a feature or launch | Brief, shot plan, product reel |
| Marketing and social team | Cut one story for several placements | Format-specific exports and readable end cards |
| Motion designer or editor | Place timed overlays around a talking-head video | Timeline, source assets, composite, edit timing |
| Agency or in-house studio | Maintain a consistent campaign look | Reusable direction, review log, export set |
| Educator or explainer creator | Show how a product works | Clear screen sequence and narration plan |
| Reviewer or creative lead | Find defects before delivery | Timestamped issues and prioritized fixes |

## Start a project

Ask for a reel or a B-roll sequence in Claude or ChatGPT/Codex. Reelcraft collects missing inputs, prepares a shot plan, and stops for approval. For example:

> Plan a 15-second vertical launch reel for my product. Here are the brand assets and a link to the interface. Show me the shot plan before rendering.

The outcome skills are `motion-reel` for a complete film, `motion-broll` for cutaways and graphics over supplied footage, and `studio-review` for a critique of an existing draft. They can produce plans and review notes in a chat. Video rendering needs an execution environment with the dependencies reported by `doctor`.

The `studio-director` skill coordinates the chain: `brand-intake` → `timeline-plan` → `audio-design` (when requested) → render → `studio-review`. The assistant selects skills; the runner executes the approved scene specification. Background execution does not cause an idle chat to resume automatically.

## Release status

Version 0.4.0 is a development checkpoint. Native FFmpeg exports and the local MCP wire protocol have integration coverage. Fresh Claude/OpenAI installs, Windows/macOS execution, and Chromium rendering have not been verified. Native rendering uses timed static scenes; spring animation requires the browser engine. See [implementation status](docs/build-status.md) and [export support](docs/exports.md) and [verification and postmortem](docs/verification.md).

### Local runtime

Create a spec file for the approved direction. This minimal reel uses two text scenes; replace its claims and visual direction with your own verified material:

```json
{
  "workflow": "reel",
  "name": "Example launch",
  "input": {"product": "Example product"},
  "timeline": {
    "duration": 6,
    "fps": 30,
    "scenes": [
      {"id": "open", "start": 0, "end": 3, "type": "title", "text": "Meet the product"},
      {"id": "close", "start": 3, "end": 6, "type": "panel", "text": "Explore it today"}
    ]
  },
  "formats": ["16x9", "9x16"],
  "audio": {"mode": "none"}
}
```

Save it as `spec.json`. Relative media paths resolve from the spec file directory. A B-roll spec instead sets `workflow` to `broll` and provides `input.source_video` as a local media file. An `input.captions` SRT or VTT file is optional for subtitle and timing work. See `python3 scripts/studio.py --help` and the spec validation messages for supported scene fields and formats.

From the plugin directory:

```bash
python3 scripts/studio.py doctor
python3 scripts/studio.py init --spec spec.json --project path/to/my-reel
python3 scripts/studio.py plan --project path/to/my-reel
```

Review the generated plan and record the user's explicit approval before continuing:

```bash
python3 scripts/studio.py approve --project path/to/my-reel --hash PLAN_SHA256_FROM_PLAN
python3 scripts/studio.py run --project path/to/my-reel
```

Use `run --project path/to/my-reel --detach` to request a background job in a supported local runtime; `status --project path/to/my-reel` reports its state. `retry` and `cancel` use the same `--project` option. Check `python3 scripts/studio.py --help` for the installed version's exact options and its project schema. Plan approval is a separate step even for a background run.

The local toolchain requires Python 3.10+, Node.js 22+, FFmpeg and ffprobe. Run `python3 scripts/setup.py` to check it; `python3 scripts/setup.py --browser` installs the pinned optional browser dependencies (network required). On Windows, configure the host command as `python` if `python3` is unavailable. A browser-backed render path also needs Chromium available to Playwright; a supported fallback may have different requirements. Audio synthesis, supplied music, and local narration use FFmpeg and the Python standard library. External generation services are not bundled. `doctor` is the setup check for the installed package.

## Install as a plugin

- **Claude Code:** load the checked-out plugin folder with Claude Code's `--plugin-dir` option during development. This repository also includes a marketplace catalog, so after it is published on GitHub, add its `owner/repo` to Claude Code's marketplaces and install `reelcraft@reelcraft-marketplace`.
- **ChatGPT/Codex:** package this single directory with its root `plugin.json` and `skills/` directory. Import the plugin ZIP where plugin upload is available, or use a local marketplace in a supported Codex environment. Test it in a new conversation. Directory publication is a separate review and publishing process.

See [platform support](docs/platforms.md) for what each host can execute and [architecture](docs/architecture.md) for the project flow.

## Delivery standard

Every completed project includes the approved plan, the source timeline and assets used, review evidence, and the formats actually rendered. Report missing inputs or runtime capabilities honestly. A plan can be useful on its own when the host cannot run the renderer.

## Local MCP tools

`mcp.json` and the Claude `.mcp.json` expose the original eight rendering tools plus engagement, work-package, recipe and branch tools. `render_start` defaults to background execution; set `wait: true` to wait. Set `REELCRAFT_WORKSPACE` to an absolute directory for project and media staging; otherwise it uses `projects/` under the server's launch directory. File references must remain inside this workspace. The server runs locally. A separate, explicit branch push can upload a selected project to a configured GitHub repository.

Templates provide reel/B-roll specs, a brief, and a review log. Presets provide visual direction; the assistant must translate selected preferences into the scene spec. They are not silently applied by the renderer.

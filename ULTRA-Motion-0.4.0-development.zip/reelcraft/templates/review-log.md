# Review log

Record observations from actual media. Avoid invented scores or a claim of
perfect quality based on test success.

## Round 1: story and composition

- Evidence inspected:
- Readability, brand fidelity and source accuracy:
- Three highest priority issues:
- Changes:

## Round 2: motion and sound

- Evidence inspected:
- Timing, transitions, narration and cue alignment:
- Three highest priority issues:
- Changes:

## Round 3: delivery

- Formats, codec, alpha, audio and manifest checks:
- Evidence inspected:
- Remaining limitations:
- Human review decision:

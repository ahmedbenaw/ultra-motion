# Motion brief

- Outcome: product reel / timed B-roll
- Audience:
- One message:
- Exact CTA:
- Duration and formats:
- Product facts and evidence:
- Assets and permitted use:
- Palette and type:
- Source video and transcript:
- Music, narration and sound cues:
- Things to avoid:
- Open decisions:

## Shot plan

| Scene | Start–end | Exact words | Source evidence | Placement and motion | Sound | Format notes |
| --- | --- | --- | --- | --- | --- | --- |

## Approval

Reviewed plan digest:

User decision and date:

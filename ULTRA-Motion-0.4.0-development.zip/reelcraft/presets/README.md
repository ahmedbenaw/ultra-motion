# Style presets

Presets are creative starting points. Copy values into a project spec after
checking the actual product brand, text and footage. They do not establish
permission to use a logo, font, music track, or another creator's work.

Each JSON file names the background, text, accent and suggested scene geometry.
The local runner accepts the resulting project spec; it does not silently
override approved scenes with a preset.

# Evaluation fixtures

`reel-basic` is a fictional product brief with supplied brand values and explicit claim boundaries. `broll-basic` provides an SRT and a synthetic six-second source-video recipe. The brief files describe desired outcomes, not a private engine interface; adapters may map them to a versioned CLI schema.

Generate the B-roll input locally with `sh evals/fixtures/broll-basic/make-video.sh`. The resulting `source.mp4` is deliberately ignored by version control. It contains a moving presenter placeholder on the left and open space on the right, so both transparent overlay and full-frame cutaway choices can be evaluated. No actual person or product is depicted.

`cases.json` specifies assertions for a harness. It is deliberately strict about factual claims, approvals, alpha, placement, and real output inspection. `validate-fixtures.py` checks source fixture integrity; it does not certify a render.

From the repository root:

```bash
python3 evals/validate-fixtures.py
sh evals/fixtures/broll-basic/make-video.sh
ffprobe -v error -show_entries format=duration -of default=nw=1 evals/fixtures/broll-basic/source.mp4
```

#!/usr/bin/env python3
"""Validate bundled evaluation inputs, not rendered output."""

import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent
TIMECODE = re.compile(r"^(\d{2}):(\d{2}):(\d{2}),(\d{3})$")


def seconds(value):
    match = TIMECODE.fullmatch(value)
    if not match:
        raise ValueError(f"Invalid SRT timecode: {value}")
    hours, minutes, whole, ms = map(int, match.groups())
    if minutes >= 60 or whole >= 60:
        raise ValueError(f"Out-of-range SRT timecode: {value}")
    return 3600 * hours + 60 * minutes + whole + ms / 1000


def main():
    cases = json.loads((ROOT / "cases.json").read_text())
    assert cases["version"] == 1
    assert len({case["id"] for case in cases["cases"]}) == len(cases["cases"])
    for case in cases["cases"]:
        fixture = (ROOT / case["fixture"]).resolve()
        assert fixture.is_relative_to(ROOT), case["fixture"]
        assert fixture.exists(), fixture
        assert case["assertions"], case["id"]
        assert json.loads(fixture.read_text())["mode"] == case["mode"]

    reel = json.loads((ROOT / "fixtures/reel-basic/brief.json").read_text())
    assert reel["duration_seconds"] > 0 and reel["formats"]
    assert reel["source_facts"] and reel["exact_cta"]

    broll_dir = ROOT / "fixtures/broll-basic"
    broll = json.loads((broll_dir / "brief.json").read_text())
    transcript = (broll_dir / broll["transcript"]).read_text().strip()
    intervals = []
    for block in re.split(r"\n\s*\n", transcript):
        lines = block.splitlines()
        assert len(lines) >= 3, block
        start, end = lines[1].split(" --> ")
        intervals.append((seconds(start), seconds(end)))
    assert intervals and all(a < b <= 6 for a, b in intervals)
    assert all(intervals[i][1] <= intervals[i + 1][0] for i in range(len(intervals) - 1))
    assert all(0 <= segment["start_seconds"] < segment["end_seconds"] <= 6
               for segment in broll["requested_segments"])
    print(f"Fixtures valid: {len(cases['cases'])} cases, {len(intervals)} transcript cues")


if __name__ == "__main__":
    try:
        main()
    except (AssertionError, ValueError, KeyError, OSError) as error:
        print(f"Fixture validation failed: {error}", file=sys.stderr)
        sys.exit(1)

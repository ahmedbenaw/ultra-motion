#!/bin/sh
set -eu
cd "$(dirname "$0")"
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "ffmpeg is required to generate this synthetic fixture" >&2
  exit 1
fi
ffmpeg -hide_banner -loglevel error -y \
  -f lavfi -i 'color=c=0x101820:s=640x360:r=30:d=6' \
  -f lavfi -i 'sine=frequency=220:sample_rate=48000:duration=6' \
  -f lavfi -i 'color=c=0xF2B84B:s=160x240:r=30:d=6' \
  -f lavfi -i 'color=c=0xF8F5EF:s=90x90:r=30:d=6' \
  -filter_complex '[0:v][2:v]overlay=x=50+6*t:y=90:eval=frame[body];[body][3:v]overlay=x=85+6*t:y=35:eval=frame[v]' \
  -map '[v]' -map 1:a -c:v libx264 -pix_fmt yuv420p -r 30 \
  -c:a aac -b:a 128k -t 6 -movflags +faststart source.mp4
echo "Generated $(pwd)/source.mp4"

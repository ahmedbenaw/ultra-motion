#!/usr/bin/env python3
"""Run synthetic portable engagements. This is not native-host or human acceptance."""
import argparse
import json
from pathlib import Path
import platform
import sys
import tempfile
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from studio import jobs, branch_store
from studio.project import CONTENT_FIELDS, ProjectStore, new_project


def approval(store):
    plan = store.plan()
    store.apply({'id': 'approve-'+str(plan['revision']), 'expected_revision': plan['revision'],
                 'action': 'approve', 'payload': {'actor': 'Synthetic acceptance fixture', 'digest': plan['digest']}})


def engagement(base, name, preset, formats, background=False):
    value = new_project(name, preset)
    value['mission']['objective'] = 'Explain a synthetic decision with supplied evidence.'
    value['mission']['decision'] = 'Which synthetic option deserves further validation?'
    value['truth']['sources'] = [{'id': 'fixture', 'title': 'Synthetic inputs', 'uri': 'fixture:local', 'status': 'supplied'}]
    value['truth']['claims'] = [{'id': 'change', 'text': 'Illustrative change from 10 to 12.', 'status': 'illustrative', 'sources': ['fixture'],
        'calculation': {'operation': 'percent_change', 'inputs': [{'label': 'Before', 'value': '10', 'unit': 'count', 'source': 'fixture'},
        {'label': 'After', 'value': '12', 'unit': 'count', 'source': 'fixture'}]}}]
    value['moments'] = [{'id': 'point', 'title': 'Decision point', 'content': '' if 'lottie' in formats else 'Review the supplied evidence',
        'anchor': {'kind': 'seconds', 'seconds': 0}, 'duration': 1, 'visual': {'type': 'panel'}, 'claims': ['change']}]
    value['outputs'] = [{'id': kind, 'kind': kind, 'ratio': '9:16' if preset=='mobile-demo' else '16:9', 'fps': '10', 'sample_rate': 8000} for kind in formats]
    store = ProjectStore.create(base/preset, value)
    definitions = [{'id': 'numbers', 'handler': 'quantitative_check', 'depends_on': [], 'inputs': ['truth']}]
    for handler in ('compile_moments', 'preview', 'export_outputs'):
        definitions.append({'id': handler, 'handler': handler, 'depends_on': ['numbers'], 'inputs': sorted(CONTENT_FIELDS)})
    if set(formats)&{'mp4','webm','gif','png','mov-alpha'}:
        definitions.append({'id': 'media', 'handler': 'render_proof', 'depends_on': ['compile_moments'], 'inputs': sorted(CONTENT_FIELDS)})
    if 'wav' in formats:
        definitions.append({'id': 'audio', 'handler': 'assemble_audio', 'depends_on': ['compile_moments'], 'inputs': sorted(CONTENT_FIELDS)})
    jobs.define(store, definitions, 0)
    approval(store)
    if background:
        jobs.start_background(store)
        deadline = time.monotonic()+30
        while time.monotonic()<deadline:
            state = jobs.status(store)
            if all(j['state']=='verified' for j in state['jobs']) or any(j['state']=='failed' for j in state['jobs']):
                break
            time.sleep(.05)
    else:
        state = jobs.run(store)
    assert all(j['state']=='verified' for j in state['jobs']), state
    number = json.loads((store.directory/state['jobs'][0]['artifacts'][0]['path']).read_text())
    assert number['calculations'][0]['result']=='20.00'
    initial_count = sum(len(j['artifacts']) for j in state['jobs'])
    store.apply({'id': 'edit', 'expected_revision': store.read()['revision'], 'action': 'set_mission', 'payload': {'objective': 'Revised synthetic decision'}})
    assert not store.plan()['approved']
    assert any(j['state']=='stale' for j in jobs.status(store)['jobs'])
    approval(store)
    assert all(j['state']=='verified' for j in jobs.run(store)['jobs'])
    store.apply({'id': 'storage', 'expected_revision': store.read()['revision'], 'action': 'set_policy', 'payload': {'storage': 'github'}})
    approval(store)
    jobs.run(store)
    repository = base/(preset+'.git')
    branch_store.initialize(repository)
    snapshot = branch_store.save(repository, store)
    restored = base/(preset+'-restored')
    branch_store.restore(repository, value['id'], restored)
    assert all(j['state']=='verified' for j in jobs.status(ProjectStore(restored))['jobs'])
    return {'engagement': preset, 'state': 'PASS', 'mode': 'background' if background else 'foreground',
            'formats_requested': formats, 'artifacts_verified': initial_count,
            'checks': ['approval', 'execution', 'arithmetic', 'integrity', 'stale-after-edit', 'reapprove-rerun', 'local-branch-save-restore'],
            'branch_commit': snapshot['commit']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    with tempfile.TemporaryDirectory() as folder:
        base = Path(folder)
        results = [engagement(base, 'Synthetic mobile product', 'mobile-demo', ['mp4','webm','gif','png','json','srt','vtt','wav']),
                   engagement(base, 'Synthetic consulting decision', 'consulting-decision', ['pdf','pptx','json'], True),
                   engagement(base, 'Synthetic academic explanation', 'academic-explainer', ['pdf','pptx','json','lottie'])]
    report = {'scope': 'Synthetic portable runtime acceptance only', 'platform': platform.system(), 'python': platform.python_version(),
              'results': results, 'unqualified': ['native-host-install', 'native-live-interaction', 'native-voice', 'browser-visual-QA', 'human-creative-acceptance', 'authenticated-GitHub-sync', 'macOS-and-Windows']}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

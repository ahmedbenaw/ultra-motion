#!/usr/bin/env python3
"""Inspect caption timing or estimate a beat grid from local music."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from studio.timing import analyze_music, parse_captions


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("kind", choices=["music", "captions"])
    parser.add_argument("path", type=Path)
    parser.add_argument("--bpm", type=float)
    args = parser.parse_args()
    result = analyze_music(args.path, args.bpm) if args.kind == "music" else parse_captions(args.path)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

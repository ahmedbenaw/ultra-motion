#!/usr/bin/env python3
"""Optional public HTTPS metadata capture for Reelcraft."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from studio.capture import CaptureError, capture


def main(argv=None):
    parser = argparse.ArgumentParser(description="Capture public HTTPS brand metadata and provenance")
    parser.add_argument("url", help="public HTTPS product URL")
    parser.add_argument("--output", required=True, type=Path, help="empty destination directory")
    parser.add_argument("--screenshot", action="store_true",
                        help="offline HTML screenshot; linked resources are blocked")
    args = parser.parse_args(argv)
    try:
        result = capture(args.url, args.output, screenshot=args.screenshot)
    except (CaptureError, OSError) as exc:
        print(json.dumps({"status": "error", "message": str(exc)}), file=sys.stderr)
        return 1
    print(json.dumps({"status": "ok", "output": str(args.output), "capture": result},
                     ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Reelcraft project coordinator. ``python scripts/studio.py --help``."""

import argparse
import json
from pathlib import Path
import sys
import subprocess

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from studio import ProjectError, approve, cancel, create, plan, retry, run, status
from studio.core import _execute, doctor


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Plan, approve, render and review local motion jobs")
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init", help="create a project from a JSON spec in an empty directory")
    init.add_argument("--spec", required=True, type=Path)
    init.add_argument("--project", required=True, type=Path)
    sub.add_parser("doctor", help="inspect installed renderer and media capabilities")
    for name in ("plan", "validate", "status", "cancel", "run", "retry", "_worker", "approve"):
        p = sub.add_parser(name)
        p.add_argument("--project", required=True, type=Path)
        if name in ("run", "retry"):
            p.add_argument("--detach", action="store_true")
        if name == "approve":
            p.add_argument("--hash", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "doctor":
            result = doctor()
        elif args.command == "init":
            result = create(json.loads(args.spec.read_text(encoding="utf-8")), args.project, base_dir=args.spec.resolve().parent)
        elif args.command == "plan":
            result = plan(args.project)
        elif args.command == "validate":
            result = {"valid": True, **plan(args.project)}
        elif args.command == "approve":
            result = approve(args.project, args.hash)
        elif args.command == "status":
            result = status(args.project)
        elif args.command == "run":
            result = run(args.project, args.detach)
        elif args.command == "retry":
            result = retry(args.project, args.detach)
        elif args.command == "cancel":
            result = cancel(args.project)
        else:
            result = _execute(args.project)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    except (ValueError, OSError, RuntimeError, subprocess.SubprocessError) as exc:
        print(json.dumps({"status": "error", "message": str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

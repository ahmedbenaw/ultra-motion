#!/usr/bin/env python3
"""Local MCP tools for Reelcraft. Stdout is reserved for JSON-RPC."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from studio import create, plan, approve, run, retry, cancel, status
from studio.core import doctor
from studio.project import ProjectStore, new_project
from studio.presets import catalog, recommend, compose, work_proposal
from studio import jobs, branch_store
from studio.preview import write_preview

WORKSPACE = Path(os.environ.get("REELCRAFT_WORKSPACE", Path.cwd() / "projects")).resolve()


def local(value: str) -> Path:
    path = (WORKSPACE / value).resolve()
    if not path.is_relative_to(WORKSPACE) or path == WORKSPACE:
        raise ValueError("Project path must be inside the Reelcraft workspace")
    return path


def schema(properties=None, required=None):
    return {"type": "object", "properties": properties or {},
            "required": required or [], "additionalProperties": False}


PROJECT = {"project": {"type": "string", "description": "Project directory relative to the configured workspace"}}
TOOLS = [
    {"name": "runtime_doctor", "description": "Report installed media tools and render capabilities", "inputSchema": schema()},
    {"name": "project_create", "description": "Create an isolated project from an editable scene spec", "inputSchema": schema({**PROJECT, "spec": {"type": "object"}}, ["project", "spec"])},
    {"name": "project_plan", "description": "Validate a project and return the current plan approval hash", "inputSchema": schema(PROJECT, ["project"])},
    {"name": "project_approve", "description": "Record the user's approval of the exact reviewed plan hash", "inputSchema": schema({**PROJECT, "hash": {"type": "string"}}, ["project", "hash"])},
    {"name": "render_start", "description": "Run an approved plan synchronously or start a background worker", "inputSchema": schema({**PROJECT, "wait": {"type": "boolean", "default": False}}, ["project"])},
    {"name": "job_status", "description": "Read job status and produced artifacts", "inputSchema": schema(PROJECT, ["project"])},
    {"name": "job_retry", "description": "Retry a failed, cancelled or stale job in a new attempt directory", "inputSchema": schema(PROJECT, ["project"])},
    {"name": "job_cancel", "description": "Request cancellation of an active job", "inputSchema": schema(PROJECT, ["project"])},
]
TOOLS += [
    {"name": "work_propose", "description": "Prepare supported work packages from requested outputs and supplied evidence; does not define or approve them", "inputSchema": schema(PROJECT, ["project"])},
    {"name": "recipe_recommend", "description": "Propose a case-specific rule-based recipe without changing the project", "inputSchema": schema(PROJECT, ["project"])},
    {"name": "recipe_compose", "description": "Compare recipes and return explicit control conflicts or a resolved proposal", "inputSchema": schema({**PROJECT, "secondary": {"type": "object"}, "resolutions": {"type": "object"}}, ["project", "secondary"])},
    {"name": "recipe_catalog", "description": "List project recipes and their complete control coverage. Recipes remain proposals until reviewed.", "inputSchema": schema()},
    {"name": "engagement_create", "description": "Create a portable v2 product, strategy or visual engagement", "inputSchema": schema({**PROJECT, "name": {"type": "string"}, "preset": {"type": "string"}}, ["project", "name"])},
    {"name": "engagement_plan", "description": "Return the reviewable mission, evidence, Moments and exact approval digest", "inputSchema": schema(PROJECT, ["project"])},
    {"name": "engagement_command", "description": "Apply a revision-checked, idempotent project command or explicit user approval", "inputSchema": schema({**PROJECT, "command": {"type": "object"}}, ["project", "command"])},
    {"name": "work_define", "description": "Define scoped work packages and their dependency graph", "inputSchema": schema({**PROJECT, "jobs": {"type": "array", "items": {"type": "object"}}, "revision": {"type": "integer"}}, ["project", "jobs", "revision"])},
    {"name": "work_start", "description": "Execute approved work or start a real background worker; starting is not completion", "inputSchema": schema({**PROJECT, "wait": {"type": "boolean"}}, ["project"])},
    {"name": "work_status", "description": "Read work states, stale input detection and artifact integrity", "inputSchema": schema(PROJECT, ["project"])},
    {"name": "work_control", "description": "Cooperatively pause, cancel, resume or retry a work package", "inputSchema": schema({**PROJECT, "job": {"type": "string"}, "action": {"type": "string", "enum": ["pause", "cancel", "resume", "retry"]}}, ["project", "job", "action"])},
    {"name": "engagement_preview", "description": "Write a self-contained project snapshot for native file/artifact preview. Commands in a snapshot are proposals, not persisted changes.", "inputSchema": schema(PROJECT, ["project"])},
    {"name": "branch_repository_init", "description": "Create an isolated local project branch repository inside the workspace", "inputSchema": schema({"repository": {"type": "string"}}, ["repository"])},
    {"name": "branch_save", "description": "Snapshot a GitHub-selected project to its local branch with optional divergence guard", "inputSchema": schema({**PROJECT, "repository": {"type": "string"}, "expected_tip": {"type": "string"}}, ["project", "repository"])},
    {"name": "branch_restore", "description": "Restore a project branch into a new workspace directory and check artifact hashes", "inputSchema": schema({"repository": {"type": "string"}, "project_id": {"type": "string"}, "destination": {"type": "string"}}, ["repository", "project_id", "destination"])},
    {"name": "branch_push", "description": "Push the saved project branch to its explicitly configured GitHub origin; non-force push", "inputSchema": schema({"repository": {"type": "string"}, "project_id": {"type": "string"}}, ["repository", "project_id"])},
    {"name": "branch_configure", "description": "Set the user-selected GitHub project repository as origin; refuses to replace another origin", "inputSchema": schema({"repository": {"type": "string"}, "origin": {"type": "string"}}, ["repository", "origin"])},
    {"name": "branch_fetch", "description": "Fetch a project branch from configured GitHub origin without overwriting divergent local history", "inputSchema": schema({"repository": {"type": "string"}, "project_id": {"type": "string"}}, ["repository", "project_id"])},
]
for tool in TOOLS:
    tool["annotations"] = {"readOnlyHint": tool["name"] in {"runtime_doctor", "project_plan", "job_status", "recipe_catalog", "recipe_recommend", "recipe_compose", "work_propose", "engagement_plan", "work_status"},
                           "destructiveHint": False, "openWorldHint": tool["name"] in {"branch_push", "branch_fetch"}}


def scoped_spec(spec: dict) -> dict:
    # Files supplied to the MCP runtime must already be staged in its workspace.
    result = json.loads(json.dumps(spec))
    references = []
    for key in ("source_video", "captions"):
        if result.get("input", {}).get(key):
            references.append((result["input"], key))
    for key in ("file", "voice_file"):
        if result.get("audio", {}).get(key):
            references.append((result["audio"], key))
    for scene in result.get("timeline", {}).get("scenes", []):
        if scene.get("type") == "image":
            references.append((scene, "image"))
    for container, key in references:
        container[key] = str(local(container[key]))
    return result


def call(name: str, args: dict) -> dict:
    tool = next((tool for tool in TOOLS if tool["name"] == name), None)
    if not tool or not isinstance(args, dict):
        raise ValueError("Unknown tool or invalid arguments")
    contract = tool["inputSchema"]
    if set(args) - set(contract["properties"]) or any(key not in args for key in contract["required"]):
        raise ValueError("Missing or unsupported tool argument")
    expected_types = {"string": str, "object": dict, "array": list, "boolean": bool, "integer": int}
    for key, value in args.items():
        field = contract["properties"][key]
        if type(value) is not expected_types[field["type"]]:
            raise ValueError(f"Invalid type for {key}")
        if "enum" in field and value not in field["enum"]:
            raise ValueError(f"Invalid value for {key}")
    if name == "runtime_doctor":
        import importlib.util
        return {**doctor(), "project_protocol": 2, "v2_handlers": sorted(jobs.HANDLERS), "native_host_qualification": "pending", "v2_exports": ["json", "html", "markdown", "mp4-proof", "mov-alpha-proof", "png-proof", "webm-proof", "gif-proof", "srt", "vtt", "restricted-lottie", "pdf-brief", "pptx-brief", "wav-pcm"], "optional_exports_installed": {name: importlib.util.find_spec(name) is not None for name in ("reportlab", "pypdf", "pptx")}}
    if name == "recipe_catalog":
        return {"presets": catalog()}
    if name == "branch_repository_init":
        return branch_store.initialize(local(args["repository"]))
    if name == "branch_restore":
        return branch_store.restore(local(args["repository"]), args["project_id"], local(args["destination"]))
    if name == "branch_push":
        return branch_store.push(local(args["repository"]), args["project_id"])
    if name == "branch_configure":
        return branch_store.configure_origin(local(args["repository"]), args["origin"])
    if name == "branch_fetch":
        return branch_store.fetch(local(args["repository"]), args["project_id"])
    project = local(args["project"])
    if name == "engagement_create":
        return ProjectStore.create(project, new_project(args["name"], args.get("preset", "client-engagement"))).plan()
    store = ProjectStore(project)
    if name == "work_propose":
        return work_proposal(store.read())
    if name == "recipe_recommend":
        return {"state": "proposal", "recipe": recommend(store.read())}
    if name == "recipe_compose":
        return compose(store.read()['preset'], args['secondary'], args.get('resolutions'))
    if name == "engagement_plan":
        return store.plan()
    if name == "engagement_command":
        return store.apply(args["command"])
    if name == "work_define":
        return jobs.define(store, args["jobs"], args["revision"])
    if name == "work_start":
        return jobs.run(store) if args.get("wait", False) else jobs.start_background(store)
    if name == "work_status":
        return jobs.status(store)
    if name == "work_control":
        return jobs.control(store, args["job"], args["action"])
    if name == "engagement_preview":
        return {"preview": write_preview(store.read(), project / "preview.html"), "mode": "portable snapshot"}
    if name == "branch_save":
        return branch_store.save(local(args["repository"]), store, args.get("expected_tip"))
    if name == "project_create":
        return create(scoped_spec(args["spec"]), project)
    if name == "project_plan":
        return plan(project)
    if name == "project_approve":
        return approve(project, args["hash"])
    if name == "render_start":
        return run(project, detach=not args.get("wait", False))
    if name == "job_status":
        return status(project)
    if name == "job_retry":
        return retry(project, detach=True)
    return cancel(project)


def handle(request: dict) -> dict | None:
    request_id = request.get("id")
    method = request.get("method")
    if request_id is None:
        return None
    response = {"jsonrpc": "2.0", "id": request_id}
    params = request.get("params") or {}
    if method == "initialize":
        response["result"] = {"protocolVersion": params.get("protocolVersion", "2025-03-26"),
                              "capabilities": {"tools": {}},
                              "serverInfo": {"name": "reelcraft", "version": "0.4.0"},
                              "instructions": "Use engagement_plan for v2 projects, then record explicit user approval of its digest before work_start. Legacy media projects use project_plan. Local workspace: " + str(WORKSPACE)}
    elif method == "ping":
        response["result"] = {}
    elif method == "tools/list":
        response["result"] = {"tools": TOOLS}
    elif method == "tools/call":
        try:
            data = call(params["name"], params.get("arguments", {}))
            response["result"] = {"content": [{"type": "text", "text": json.dumps(data, ensure_ascii=False)}],
                                  "structuredContent": data, "isError": False}
        except Exception as exc:
            response["result"] = {"content": [{"type": "text", "text": str(exc)}], "isError": True}
    else:
        response["error"] = {"code": -32601, "message": "Method not found"}
    return response


def main():
    for line in sys.stdin:
        try:
            if len(line) > 2_000_000:
                raise ValueError("MCP message exceeds 2 MB")
            request = json.loads(line)
            if not isinstance(request, dict) or request.get("jsonrpc") != "2.0":
                raise ValueError("Invalid JSON-RPC message")
            response = handle(request)
        except Exception as exc:
            response = {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": str(exc)}}
        if response is not None:
            print(json.dumps(response, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()

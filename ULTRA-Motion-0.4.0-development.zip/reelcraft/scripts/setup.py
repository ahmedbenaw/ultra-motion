#!/usr/bin/env python3
"""Check the local runtime; optionally install the pinned browser renderer."""
import argparse
from pathlib import Path
import subprocess
import sys
import json

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from studio.core import doctor


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--browser", action="store_true", help="install npm dependencies and Chromium (network required)")
    parser.add_argument("--exports", action="store_true", help="install pinned PDF and PPTX dependencies (network required)")
    args = parser.parse_args()
    if args.exports:
        subprocess.run([sys.executable, '-m', 'pip', 'install', '-r', str(ROOT / 'requirements-exports.txt')], check=True)
    if args.browser:
        npm = "npm.cmd" if sys.platform == "win32" else "npm"
        subprocess.run([npm, "ci", "--ignore-scripts", "--no-audit", "--no-fund"], cwd=ROOT, check=True)
        subprocess.run([npm, "run", "browser:install"], cwd=ROOT, check=True)
    report = doctor()
    print(json.dumps(report, indent=2))
    return 0 if report["ready"] and (not args.browser or report["capabilities"]["chromium_binary"]) else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, subprocess.SubprocessError) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)

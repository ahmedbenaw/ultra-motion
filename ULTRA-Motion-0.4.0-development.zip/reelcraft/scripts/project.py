#!/usr/bin/env python3
"""Portable project CLI. Local preview is optional and binds to loopback only."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import secrets
import sys
from urllib.parse import unquote

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from studio.project import ProjectStore, new_project, import_v1, compile_moments, ProjectError
from studio.presets import catalog, project_recipes, recommend, compose, work_proposal
from studio import jobs
from studio import branch_store
from studio.preview import write_preview
from studio.exports_v2 import MIME_TYPES


def serve(store, port):
    token = secrets.token_urlsafe(32)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass
        def response(self, value, status=200, media='application/json'):
            content = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header('Content-Type', media+'; charset=utf-8')
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(content)
        def trusted_host(self):
            return self.headers.get('Host') == f'127.0.0.1:{self.server.server_port}'
        def do_GET(self):
            if not self.trusted_host():
                return self.response({'error': 'invalid host'}, 403)
            try:
                if self.path == '/api/state':
                    project = store.read()
                    project['jobs'] = jobs.status(store)['jobs']
                    self.response({'project': project, 'compiled': compile_moments(project), 'plan': store.plan(), 'presets': project_recipes(project), 'work_proposal': work_proposal(project)})
                elif self.path.startswith('/artifact/'):
                    relative = unquote(self.path.removeprefix('/artifact/'))
                    project = store.read()
                    allowed = {a['path'] for j in project['jobs'] for a in j['artifacts']}
                    path = (store.directory / relative).resolve()
                    if relative not in allowed or not path.is_relative_to(store.directory):
                        return self.response({'error': 'artifact unavailable'}, 404)
                    media = MIME_TYPES.get(path.suffix, 'application/octet-stream')
                    self.response(path.read_bytes(), media=media)
                elif self.path == '/':
                    path = store.directory / 'local-preview.html'
                    write_preview(store.read(), path, token)
                    self.response(path.read_bytes(), media='text/html')
                else:
                    self.response({'error': 'not found'}, 404)
            except (ValueError, OSError) as exc:
                self.response({'error': str(exc)}, 400)
        def do_POST(self):
            origin = self.headers.get('Origin')
            if not self.trusted_host() or self.headers.get('X-Project-Token') != token or (origin and origin != f'http://127.0.0.1:{self.server.server_port}'):
                return self.response({'error': 'invalid request origin or token'}, 403)
            try:
                length = int(self.headers.get('Content-Length', 0))
                if not 0 < length <= 1_000_000:
                    raise ProjectError('invalid request size')
                value = json.loads(self.rfile.read(length))
                if self.path == '/api/command':
                    self.response(store.apply(value))
                elif self.path == '/api/run':
                    self.response(jobs.start_background(store))
                elif self.path == '/api/control':
                    if not isinstance(value, dict) or set(value) != {'job', 'action'} or not all(isinstance(v, str) for v in value.values()):
                        raise ProjectError('choose a work package and supported action')
                    self.response(jobs.control(store, value['job'], value['action']))
                elif self.path == '/api/compose':
                    if not isinstance(value, dict) or 'secondary' not in value or set(value)-{'secondary', 'resolutions'}:
                        raise ProjectError('choose a second recipe and optional control resolutions')
                    self.response(compose(store.read()['preset'], value['secondary'], value.get('resolutions')))
                else:
                    self.response({'error': 'not found'}, 404)
            except (ValueError, OSError) as exc:
                self.response({'error': str(exc)}, 400)
    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    print(json.dumps({'preview': f'http://127.0.0.1:{server.server_port}', 'mode': 'optional local preview'}), flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('presets')
    for command in ('init', 'import-v1', 'plan', 'apply', 'compile', 'define-jobs', 'propose-work', 'run', 'status', 'control', 'preview', 'serve', 'recommend', 'compose', 'branch-init', 'branch-save', 'branch-restore', 'branch-push', 'branch-configure', 'branch-fetch'):
        p = sub.add_parser(command)
        if command not in {'branch-init', 'branch-restore', 'branch-push', 'branch-configure', 'branch-fetch'}:
            p.add_argument('--project', type=Path, required=True)
        if command.startswith('branch-'):
            p.add_argument('--repo', type=Path, required=True)
        if command in {'branch-restore', 'branch-push', 'branch-fetch'}:
            p.add_argument('--id', required=True)
        if command == 'branch-configure':
            p.add_argument('--origin', required=True)
        if command == 'branch-restore':
            p.add_argument('--destination', type=Path, required=True)
        if command == 'branch-save':
            p.add_argument('--expected-tip')
        if command == 'init':
            p.add_argument('--name', required=True)
            p.add_argument('--preset', default='client-engagement')
        if command in {'import-v1', 'apply', 'define-jobs', 'compose'}:
            p.add_argument('--file', type=Path, required=True)
        if command == 'define-jobs':
            p.add_argument('--revision', type=int, required=True)
        if command == 'run':
            p.add_argument('--background', action='store_true')
        if command == 'control':
            p.add_argument('--job', required=True)
            p.add_argument('--action', choices=['pause', 'cancel', 'retry', 'resume'], required=True)
        if command == 'preview':
            p.add_argument('--output', type=Path)
        if command == 'serve':
            p.add_argument('--port', type=int, default=0)
    args = parser.parse_args()
    try:
        if args.command == 'presets':
            result = {'presets': catalog()}
        elif args.command == 'branch-init':
            result = branch_store.initialize(args.repo)
        elif args.command == 'branch-restore':
            result = branch_store.restore(args.repo, args.id, args.destination)
        elif args.command == 'branch-push':
            result = branch_store.push(args.repo, args.id)
        elif args.command == 'branch-configure':
            result = branch_store.configure_origin(args.repo, args.origin)
        elif args.command == 'branch-fetch':
            result = branch_store.fetch(args.repo, args.id)
        elif args.command in {'init', 'import-v1'}:
            value = new_project(args.name, args.preset) if args.command == 'init' else import_v1(json.loads(args.file.read_text()))
            result = ProjectStore.create(args.project, value).plan()
        else:
            store = ProjectStore(args.project)
            if args.command == 'plan':
                result = store.plan()
            elif args.command == 'apply':
                result = store.apply(json.loads(args.file.read_text()))
            elif args.command == 'compile':
                result = compile_moments(store.read())
            elif args.command == 'recommend':
                result = {'state': 'proposal', 'recipe': recommend(store.read())}
            elif args.command == 'propose-work':
                result = work_proposal(store.read())
            elif args.command == 'compose':
                request = json.loads(args.file.read_text())
                if not isinstance(request, dict) or 'secondary' not in request or set(request)-{'secondary', 'resolutions'}:
                    raise ProjectError('composition requires a secondary recipe and optional resolutions')
                result = compose(store.read()['preset'], request['secondary'], request.get('resolutions'))
            elif args.command == 'define-jobs':
                result = jobs.define(store, json.loads(args.file.read_text()), args.revision)
            elif args.command == 'run':
                result = jobs.start_background(store) if args.background else jobs.run(store)
            elif args.command == 'status':
                result = jobs.status(store)
            elif args.command == 'branch-save':
                result = branch_store.save(args.repo, store, args.expected_tip)
            elif args.command == 'control':
                result = jobs.control(store, args.job, args.action)
            elif args.command == 'preview':
                result = {'preview': write_preview(store.read(), args.output or store.directory/'preview.html'), 'mode': 'portable snapshot'}
            else:
                serve(store, args.port)
                return 0
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    except (ValueError, OSError) as exc:
        print(json.dumps({'status': 'error', 'message': str(exc)}), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())

#!/usr/bin/env python3
"""Validate and archive exactly the distributable source, including host overlays."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {"node_modules", "__pycache__", ".git", "projects", "output"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    destination = args.output.resolve()
    if destination.is_relative_to(ROOT):
        parser.error("archive must be outside the plugin directory")
    manifest = json.loads((ROOT / "plugin.json").read_text())
    assert manifest["name"] == ROOT.name
    assert len(manifest["extensions"]["com.openai"]["interface"]["shortDescription"]) <= 30
    assert json.loads((ROOT / ".claude-plugin/plugin.json").read_text())["version"] == manifest["version"]
    skills = list((ROOT / "skills").glob("*/SKILL.md"))
    assert skills, "Package must contain at least one workflow skill"
    assert len({skill.parent.name for skill in skills}) == len(skills)
    for skill in skills:
        text = skill.read_text()
        assert re.search(r"^name: " + re.escape(skill.parent.name) + r"$", text, re.M)
        assert re.search(r"^description: .+", text, re.M)
    for config in ("mcp.json", ".mcp.json", "hooks/claude.json", "hooks/codex.json"):
        json.loads((ROOT / config).read_text())
    files = []
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED for part in relative.parts) or path.suffix in {".pyc", ".log"} or path.name == ".DS_Store":
            continue
        if path.is_symlink():
            raise ValueError(f"Symlink is not distributable: {relative}")
        if not path.is_file():
            continue
        if relative.parts[:2] == ("evals", "fixtures") and path.suffix in {".mp4", ".mov", ".wav"}:
            continue
        files.append(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
        for file in files:
            archive.write(file, str(Path(ROOT.name) / file.relative_to(ROOT)))
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert f"{ROOT.name}/.claude-plugin/plugin.json" in archive.namelist()
        assert f"{ROOT.name}/plugin.json" in archive.namelist()
    print(json.dumps({"archive": str(destination), "files": len(files), "skills": len(skills),
                      "sha256": hashlib.sha256(destination.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    main()

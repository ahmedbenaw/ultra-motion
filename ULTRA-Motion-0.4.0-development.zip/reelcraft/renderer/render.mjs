#!/usr/bin/env node
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { randomUUID } from 'node:crypto';
import { once } from 'node:events';
import { pathToFileURL } from 'node:url';
import { FORMATS, loadProject, resolveImage } from './project.mjs';

const exec = promisify(execFile);

async function verifyMedia(output, size, fps, duration, alpha, frame) {
  const { stdout } = await exec('ffprobe', ['-v', 'error', '-count_frames', '-select_streams', 'v:0',
    '-show_entries', 'stream=codec_name,pix_fmt,width,height,nb_read_frames,avg_frame_rate:format=duration', '-of', 'json', output], { timeout: 120000 });
  const probe = JSON.parse(stdout), stream = probe.streams?.[0];
  if (!stream || stream.width !== size.width || stream.height !== size.height) throw new Error('Encoded video geometry is invalid');
  if (frame === undefined) {
    if (Number(stream.nb_read_frames) !== Math.ceil(duration * fps)) throw new Error('Encoded frame count is incomplete');
    if (Math.abs(Number(probe.format.duration) - Math.ceil(duration * fps) / fps) > 0.1) throw new Error('Encoded duration is invalid');
    if (alpha && !stream.pix_fmt?.startsWith('yuva')) throw new Error('Alpha export has no alpha channel');
  }
  return { codec: stream.codec_name, pixelFormat: stream.pix_fmt, checkedFrames: Number(stream.nb_read_frames) };
}

function argumentsFor(argv) {
  const allowed = new Set(['project', 'format', 'output', 'draft', 'alpha', 'frame', 'engine']);
  const args = {};
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];
    if (!arg.startsWith('--') || !allowed.has(arg.slice(2))) throw new Error(`Unknown argument: ${arg}`);
    const name = arg.slice(2);
    if (['draft', 'alpha'].includes(name)) args[name] = true;
    else if (!argv[i + 1] || argv[i + 1].startsWith('--')) throw new Error(`Missing value for ${arg}`);
    else args[name] = argv[++i];
  }
  if (!args.project || !args.format || !args.output) throw new Error('Usage: render.mjs --project project.json --format 16x9|1x1|4x5|9x16 --output file.mp4 [--draft] [--alpha] [--frame seconds] [--engine auto|browser|ffmpeg]');
  if (!(args.format in FORMATS)) throw new Error(`Unsupported format: ${args.format}`);
  if (args.engine && !['auto', 'browser', 'ffmpeg'].includes(args.engine)) throw new Error(`Unsupported engine: ${args.engine}`);
  if (args.frame !== undefined && (!Number.isFinite(+args.frame) || +args.frame < 0)) throw new Error('--frame requires a nonnegative time in seconds');
  const ext = path.extname(args.output).toLowerCase();
  if (args.frame !== undefined && ext !== '.png') throw new Error('--frame output must be .png');
  if (args.frame === undefined && ext !== (args.alpha ? '.mov' : '.mp4')) throw new Error(`Output must be ${args.alpha ? '.mov' : '.mp4'}`);
  return args;
}

function processExit(command, args, input) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: [input ? 'pipe' : 'ignore', 'ignore', 'pipe'] });
    let stderr = '';
    child.stderr.on('data', (buffer) => { stderr = (stderr + buffer).slice(-12000); });
    child.on('error', reject);
    child.on('close', (code) => code === 0 ? resolve() : reject(new Error(`${command} exited ${code}: ${stderr}`)));
    if (input) input(child.stdin, reject);
  });
}

function sizeFor(format, draft) {
  const [width, height] = FORMATS[format];
  return { width: draft ? Math.floor(width / 4) * 2 : width, height: draft ? Math.floor(height / 4) * 2 : height };
}

function encoderArgs(alpha, draft) {
  return alpha
    ? ['-c:v', 'prores_ks', '-profile:v', '4', '-pix_fmt', 'yuva444p10le', '-vendor', 'apl0']
    : ['-c:v', 'libx264', '-preset', draft ? 'veryfast' : 'medium', '-crf', draft ? '22' : '16', '-pix_fmt', 'yuv420p', '-movflags', '+faststart'];
}

async function imageData(root, project) {
  const images = {};
  for (const scene of project.scenes.filter((s) => s.type === 'image')) {
    const file = resolveImage(root, scene.image);
    const ext = path.extname(file).toLowerCase();
    const mime = ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
    images[scene.id] = `data:${mime};base64,${(await fsp.readFile(file)).toString('base64')}`;
  }
  return images;
}

async function tryBrowser({ project, root, format, size, fps, alpha, output, frame, draft }) {
  let chromium;
  try { ({ chromium } = await import('playwright')); }
  catch (err) { if (err.code === 'ERR_MODULE_NOT_FOUND') return { unavailable: 'Playwright package is not installed' }; throw err; }
  let browser;
  try { browser = await chromium.launch({ headless: true }); }
  catch (err) { return { unavailable: `Chromium could not start: ${err.message.split('\n')[0]}` }; }
  try {
    const page = await browser.newPage({ viewport: size, deviceScaleFactor: 1 });
    const pageErrors = [];
    page.on('pageerror', (err) => pageErrors.push(err.message));
    await page.goto(pathToFileURL(path.resolve(import.meta.dirname, '../engine/index.html')).href);
    await page.evaluate(({ project, size, images, alpha, format }) => window.Reelcraft.init(project, size, images, alpha, format),
      { project, size, images: await imageData(root, project), alpha, format });
    await page.evaluate(() => document.fonts.ready);
    await page.waitForFunction(() => [...document.images].every((image) => image.complete && image.naturalWidth > 0));
    if (pageErrors.length) throw new Error(`Browser scene error: ${pageErrors.join('; ')}`);

    if (frame !== undefined) {
      if (+frame > project.duration) throw new Error('--frame is later than project duration');
      await page.evaluate((t) => window.Reelcraft.seek(t), +frame);
      await page.screenshot({ path: output, type: 'png', omitBackground: alpha });
      return { engine: 'browser', frames: 1 };
    }

    const count = Math.ceil(project.duration * fps);
    const ff = spawn('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'png', '-i', '-', ...encoderArgs(alpha, draft), output],
      { stdio: ['pipe', 'ignore', 'pipe'] });
    let stderr = '';
    let error = null;
    const completion = new Promise((resolve) => ff.once('close', resolve));
    ff.stderr.on('data', (b) => { stderr = (stderr + b).slice(-12000); });
    ff.on('error', (e) => { error = e; });
    ff.stdin.on('error', (e) => { error = e; });
    try {
      for (let i = 0; i < count; i++) {
        await page.evaluate((t) => window.Reelcraft.seek(t), i / fps);
        if (pageErrors.length) throw new Error(`Browser scene error: ${pageErrors.join('; ')}`);
        const png = await page.screenshot({ type: 'png', omitBackground: alpha });
        if (error) throw error;
        if (!ff.stdin.write(png)) await once(ff.stdin, 'drain');
      }
      ff.stdin.end();
      const code = await completion;
      if (error) throw error;
      if (code !== 0) throw new Error(`FFmpeg exited ${code}: ${stderr}`);
    } catch (err) {
      ff.stdin.destroy(); ff.kill();
      throw err;
    }
    return { engine: 'browser', frames: count };
  } finally { await browser.close(); }
}

const ffColor = (color) => `0x${color.slice(1)}`;
function dim(value, axis) { return Math.round(value * axis); }
function sceneStyle(scene, format) { return { ...scene.style, ...(scene.styleByFormat[format] || {}) }; }

async function ffmpegFallback({ project, root, format, size, fps, alpha, output, frame, draft }) {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'reelcraft-render-'));
  try {
    const duration = frame === undefined ? project.duration : Math.max(1 / fps, Math.min(project.duration, +frame + 1 / fps));
    const args = ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i', `color=c=${alpha ? 'black@0.0' : ffColor(project.background)}:s=${size.width}x${size.height}:r=${fps}:d=${duration},format=rgba`];
    const imageScenes = project.scenes.filter((s) => s.type === 'image');
    for (const scene of imageScenes) args.push('-loop', '1', '-framerate', String(fps), '-t', String(duration), '-i', resolveImage(root, scene.image));
    const filters = ['[0:v]format=rgba[base]'];
    let last = 'base';
    let imageIndex = 0;
    for (const [i, scene] of project.scenes.entries()) {
      const s = sceneStyle(scene, format);
      const x = dim(s.x, size.width), y = dim(s.y, size.height);
      const w = dim(s.w, size.width), h = dim(s.h, size.height);
      const start = scene.start.toFixed(6), end = scene.end.toFixed(6);
      if (scene.type === 'image') {
        const pad = s.fit === 'cover'
          ? `scale=${w}:${h}:force_original_aspect_ratio=increase,crop=${w}:${h}`
          : `scale=${w}:${h}:force_original_aspect_ratio=decrease,pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2:color=black@0`;
        filters.push(`[${++imageIndex}:v]${pad},format=rgba[image${i}]`);
        filters.push(`[${last}][image${i}]overlay=x=${x}:y=${y}:format=auto:enable='between(t,${start},${end})'[out${i}]`);
        last = `out${i}`;
        continue;
      }
      const textPath = path.join(dir, `text-${i}.txt`);
      await fsp.writeFile(textPath, scene.text, 'utf8');
      const textX = s.align === 'center' ? `${x}+(${w}-text_w)/2` : s.align === 'right' ? `${x}+${w}-text_w` : x + (scene.type === 'panel' ? Math.round(30 * size.width / 1920) : 0);
      const textY = y + Math.round(h * 0.35);
      const fontSize = Math.max(8, Math.round((s.fontSize || (scene.type === 'title' ? 112 : 68)) * Math.min(size.width / 1920, size.height / 1080)));
      const box = scene.type === 'panel'
        ? `drawbox=x=${x}:y=${y}:w=${w}:h=${h}:color=${ffColor(s.background || '#202832')}@0.96:t=fill:replace=1:enable='between(t,${start},${end})',`
        : '';
      filters.push(`[${last}]${box}drawtext=font=Sans:textfile=${textPath}:expansion=none:fontcolor=${ffColor(s.color || '#ffffff')}:fontsize=${fontSize}:x=${textX}:y=${textY}:enable='between(t,${start},${end})'[out${i}]`);
      last = `out${i}`;
    }
    const final = alpha ? 'yuva444p10le' : 'yuv420p';
    filters.push(`[${last}]format=${final}[result]`);
    args.push('-filter_complex', filters.join(';'), '-map', '[result]');
    if (frame === undefined) args.push('-frames:v', String(Math.ceil(project.duration * fps)), ...encoderArgs(alpha, draft));
    else args.push('-ss', String(+frame), '-frames:v', '1');
    args.push(output);
    await processExit('ffmpeg', args);
    return { engine: 'ffmpeg', frames: frame === undefined ? Math.ceil(project.duration * fps) : 1, limitation: 'Native fallback uses timed static elements; browser spring motion is unavailable.' };
  } finally { await fsp.rm(dir, { recursive: true, force: true }); }
}

export async function render(options) {
  const args = typeof options === 'object' && !Array.isArray(options) ? options : argumentsFor(options);
  const { root, project } = loadProject(args.project);
  const size = sizeFor(args.format, args.draft);
  const fps = args.draft ? Math.min(project.fps, 30) : project.fps;
  const output = path.resolve(args.output);
  await fsp.mkdir(path.dirname(output), { recursive: true });
  if (args.frame !== undefined && +args.frame >= project.duration) throw new Error('--frame must be earlier than project duration');
  const staging = path.join(path.dirname(output), `.${path.basename(output, path.extname(output))}-${randomUUID()}.partial${path.extname(output)}`);
  const request = { project, root, format: args.format, size, fps, alpha: Boolean(args.alpha), output: staging, frame: args.frame, draft: Boolean(args.draft) };
  const selected = args.engine || 'auto';
  let result, verification;
  try {
  if (selected !== 'ffmpeg') result = await tryBrowser(request);
  if (result?.unavailable) {
    if (selected === 'browser') throw new Error(result.unavailable);
    process.stderr.write(`Browser renderer unavailable (${result.unavailable}); using native FFmpeg fallback.\n`);
  }
  if (!result || result.unavailable) result = await ffmpegFallback(request);
  verification = await verifyMedia(staging, size, fps, project.duration, Boolean(args.alpha), args.frame);
  await fsp.rename(staging, output);
  } catch (error) {
    await fsp.rm(staging, { force: true });
    throw error;
  }
  const manifest = { output, ...result, ...verification, format: args.format, width: size.width, height: size.height, fps, duration: project.duration, alpha: Boolean(args.alpha), draft: Boolean(args.draft) };
  if (args.frame === undefined) await fsp.writeFile(`${output}.render.json`, JSON.stringify(manifest, null, 2) + '\n');
  return manifest;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(import.meta.filename)) {
  render(argumentsFor(process.argv.slice(2))).then((result) => console.log(JSON.stringify(result)), (err) => { console.error(err.stack || err); process.exitCode = 1; });
}

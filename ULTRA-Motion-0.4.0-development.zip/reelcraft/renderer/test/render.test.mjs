import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import vm from 'node:vm';
import { validateProject } from '../project.mjs';
import { render } from '../render.mjs';

const motionContext = { module: { exports: {} } };
vm.runInNewContext(fs.readFileSync(new URL('../../engine/motion.js', import.meta.url), 'utf8'), motionContext);
const { springStep, sceneMotion } = motionContext.module.exports;
const available = ['ffmpeg', 'ffprobe'].every((bin) => spawnSync(bin, ['-version'], { stdio: 'ignore' }).status === 0);

function fixture() {
  return {
    version: 1, duration: 0.5, fps: 4, background: '#14202c',
    scenes: [
      { id: 'headline', start: 0, end: 0.5, type: 'title', text: 'Reelcraft', style: { color: '#ffffff', fontSize: 72 } },
      { id: 'card', start: 0, end: 0.5, type: 'panel', text: 'A clear point', style: { x: 0.1, y: 0.65, w: 0.8, h: 0.25, background: '#ff612e', color: '#101010' } },
      { id: 'product', start: 0, end: 0.5, type: 'image', image: 'assets/product.png', style: { x: 0.7, y: 0.05, w: 0.2, h: 0.2 } },
    ],
  };
}

test('schema rejects unsafe and malformed projects', () => {
  assert.equal(validateProject(fixture()).scenes.length, 3);
  assert.throws(() => validateProject({ ...fixture(), fps: 0 }), /fps/);
  assert.throws(() => validateProject({ ...fixture(), scenes: [{ ...fixture().scenes[0], type: 'script' }] }), /type/);
  assert.throws(() => validateProject({ ...fixture(), scenes: [{ ...fixture().scenes[0], style: { x: 0.8, w: 0.5 } }] }), /width/);
});

test('spring values and seeks are deterministic', () => {
  assert.equal(springStep(-1), 0);
  assert.ok(springStep(0.2) > 0 && springStep(0.2) < 1);
  assert.ok(sceneMotion(0, 0, 2).opacity > 0.8);
  assert.deepEqual(sceneMotion(0.23, 0, 2), sceneMotion(0.23, 0, 2));
});

test('FFmpeg fallback exports MP4, alpha MOV, and frame PNG', { skip: !available }, async () => {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'reelcraft-test-'));
  try {
    await fsp.mkdir(path.join(dir, 'assets'));
    const image = path.join(dir, 'assets/product.png');
    const gen = spawnSync('ffmpeg', ['-loglevel', 'error', '-f', 'lavfi', '-i', 'color=red:s=64x64', '-frames:v', '1', '-y', image]);
    assert.equal(gen.status, 0, gen.stderr?.toString());
    const project = path.join(dir, 'project.json');
    await fsp.writeFile(project, JSON.stringify(fixture()));
    const mp4 = path.join(dir, 'out.mp4');
    const mov = path.join(dir, 'alpha.mov');
    const png = path.join(dir, 'frame.png');
    const opaque = await render({ project, format: '16x9', output: mp4, draft: true, engine: 'ffmpeg' });
    const alpha = await render({ project, format: '1x1', output: mov, draft: true, alpha: true, engine: 'ffmpeg' });
    const still = await render({ project, format: '16x9', output: png, draft: true, frame: '0.25', engine: 'ffmpeg' });
    assert.equal(opaque.frames, 2);
    assert.equal(alpha.engine, 'ffmpeg');
    assert.equal(still.frames, 1);
    for (const file of [mp4, mov, png, `${mp4}.render.json`]) assert.ok(fs.statSync(file).size > 0, file);
    const probe = (file) => JSON.parse(spawnSync('ffprobe', ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=codec_name,pix_fmt,width,height', '-of', 'json', file], { encoding: 'utf8' }).stdout).streams[0];
    assert.deepEqual([probe(mp4).codec_name, probe(mp4).width, probe(mp4).height], ['h264', 960, 540]);
    assert.equal(probe(mov).codec_name, 'prores');
    assert.equal(probe(mov).pix_fmt, 'yuva444p12le');
    const mask = path.join(dir, 'alpha-mask.png');
    const extracted = spawnSync('ffmpeg', ['-loglevel', 'error', '-y', '-i', mov, '-vf', 'alphaextract', '-frames:v', '1', mask]);
    assert.equal(extracted.status, 0, extracted.stderr?.toString());
    const corner = spawnSync('convert', [mask, '-format', '%[pixel:p{0,0}]', 'info:'], { encoding: 'utf8' });
    if (corner.status === 0) assert.match(corner.stdout, /gray\(0\)|gray\(0,0,0\)|gray\(0\.0?\)/);
  } finally { await fsp.rm(dir, { recursive: true, force: true }); }
});

test('alpha export retains every frame and all draft formats encode', { skip: !available }, async () => {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'reelcraft-regression-'));
  try {
    const project = path.join(dir, 'project.json');
    const value = { version: 1, duration: 2, fps: 30, background: '#112233',
      scenes: [{ id: 'panel', type: 'panel', start: 0, end: 2, text: 'Visible',
        style: { x: .2, y: .2, w: .6, h: .6, background: '#ff0000' } }] };
    await fsp.writeFile(project, JSON.stringify(value));
    const alpha = await render({ project, format: '16x9', output: path.join(dir, 'full.mov'), draft: true, alpha: true, engine: 'ffmpeg' });
    assert.equal(alpha.checkedFrames, 60);
    for (const format of ['16x9', '1x1', '4x5', '9x16']) {
      const media = await render({ project, format, output: path.join(dir, `${format}.mp4`), draft: true, engine: 'ffmpeg' });
      assert.equal(media.width % 2, 0);
      assert.equal(media.height % 2, 0);
      assert.equal(media.checkedFrames, 60);
    }
    await assert.rejects(render({ project, format: '16x9', output: path.join(dir, 'bad.png'), frame: '2', engine: 'ffmpeg' }), /earlier/);
    assert.ok(!fs.existsSync(path.join(dir, 'bad.png')));
  } finally { await fsp.rm(dir, { recursive: true, force: true }); }
});

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {spawnSync} from 'node:child_process';

// Script behavior under a minimal DOM. This is not browser layout/visual QA.
class Element {
  constructor(tag='div') { this.tag=tag; this.children=[]; this.value=''; this.textContent=''; this.dataset={}; this.style={}; }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this.children=children; this.textContent=''; }
  get options() { return this.children; }
  setAttribute(name,value) { this[name]=value; }
  focus() { this.focused=true; }
}
const contents = element => [element.textContent,...element.children.map(contents)].join(' ');
function room(token=null) {
  const result=spawnSync(process.platform==='win32'?'python':'python3',['-c',"import json;from studio.project import new_project;print(json.dumps(new_project('Room test')))"],{cwd:new URL('../../',import.meta.url),encoding:'utf8'});
  assert.equal(result.status,0,result.stderr);
  const project=JSON.parse(result.stdout);
  project.jobs=[{id:'proof',state:'ready',attempt:0,error:null,artifacts:[]}];
  const template=fs.readFileSync(new URL('../../templates/project-room.html',import.meta.url),'utf8');
  const elements=new Map([...template.matchAll(/id="([^"]+)"/g)].map(match=>[match[1],new Element()]));
  elements.get('project-data').textContent=JSON.stringify({project,compiled:{moments:[]},presets:[project.preset],token});
  const context=vm.createContext({document:{getElementById:id=>elements.get(id),createElement:tag=>new Element(tag)},matchMedia:()=>({matches:true}),crypto:{randomUUID:()=> 'fixture-command'},performance:{now:()=>0},requestAnimationFrame:()=>{},setInterval:()=>{},setTimeout:()=>{},console});
  // Connected fetch intentionally omitted: test portable projection behavior.
  const script=[...template.matchAll(/<script>([\s\S]*?)<\/script>/g)][0][1];
  vm.runInContext(script,context);
  return {context,elements};
}

test('portable room displays work and preserves draft objective during refresh render',()=>{
  const {context,elements}=room();
  assert.match(contents(elements.get('jobs')),/proof ready/);
  elements.get('objective').value='Unsaved intent';
  elements.get('objective').oninput();
  vm.runInContext("project.revision=2;project.mission.objective='Different saved intent';render();",context);
  assert.equal(elements.get('objective').value,'Unsaved intent');
  assert.match(elements.get('revision').textContent,/2/);
});

test('result integrity state is visible and changing state refreshes the result',()=>{
  const {context,elements}=room();
  vm.runInContext("project.jobs[0].state='verified';project.jobs[0].artifacts=[{path:'artifacts-v2/proof.png',media_type:'image/png'}];render();",context);
  assert.match(contents(elements.get('results')),/content review pending/);
  vm.runInContext("project.jobs[0].state='stale';render();",context);
  assert.match(contents(elements.get('results')),/Out of date/);
  assert.doesNotMatch(contents(elements.get('results')),/content review pending/);
});

test('recipe conflicts offer explicit choices and never apply a proposal automatically',async()=>{
  const {context,elements}=room();
  const requests=[];
  context.fetch=async(path,options)=>{
    requests.push({path,body:JSON.parse(options.body)});
    const resolved=requests.at(-1).body.resolutions.truth==='secondary';
    return {ok:true,json:async()=>resolved?{state:'proposal',recipe:{id:'combined',label:'Combined',controls:{truth:{mode:'fixed',value:'Evidence'}}}}:{state:'needs-choice',recipe:null,conflicts:[{group:'truth',primary:{value:'Current'},secondary:{value:'Evidence'}}]}};
  };
  vm.runInContext("initial.token='test';byId('preset-choice').value=initial.presets[0].id",context);
  await vm.runInContext('combineRecipe({})',context);
  const select=elements.get('compose-controls').children.find(e=>e.tag==='select');
  assert.equal(select.options.length,4);
  assert.equal(elements.get('compose-apply').textContent,'Prepare combined recipe');
  select.value='secondary';select.onchange();
  await vm.runInContext('combineRecipe(combinationResolutions)',context);
  assert.equal(elements.get('compose-apply').textContent,'Use combined recipe');
  assert.equal(requests.at(-1).body.resolutions.truth,'secondary');
  assert.ok(requests.every(request=>request.path==='/api/compose'));
  vm.runInContext('render()',context);
  assert.match(contents(elements.get('preset-controls')),/Evidence/);
});

import fs from 'node:fs';
import path from 'node:path';

export const FORMATS = Object.freeze({
  '16x9': [1920, 1080],
  '1x1': [1080, 1080],
  '4x5': [1080, 1350],
  '9x16': [1080, 1920],
});

const TYPES = new Set(['title', 'panel', 'image']);
const HEX = /^#[0-9a-fA-F]{6}$/;
const LAYOUT = ['x', 'y', 'w', 'h'];
const STYLE_KEYS = new Set([...LAYOUT, 'color', 'background', 'fontFamily', 'fontSize', 'fontWeight', 'align', 'radius', 'fit']);

function fail(message) { throw new Error(`Invalid project: ${message}`); }
function finite(v) { return typeof v === 'number' && Number.isFinite(v); }

function validateStyle(style, context) {
  if (!style || typeof style !== 'object' || Array.isArray(style)) fail(`${context}.style must be an object`);
  for (const [key, value] of Object.entries(style)) {
    if (!STYLE_KEYS.has(key)) fail(`${context}.style.${key} is not supported`);
    if (LAYOUT.includes(key) && (!finite(value) || value < (['w', 'h'].includes(key) ? 0.001 : 0) || value > 1)) fail(`${context}.style.${key} must fit the normalized frame`);
    if (['color', 'background'].includes(key) && !HEX.test(value)) fail(`${context}.style.${key} must be #RRGGBB`);
    if (key === 'fontSize' && (!finite(value) || value < 8 || value > 500)) fail(`${context}.style.fontSize must be 8–500`);
    if (key === 'fontWeight' && (!Number.isInteger(value) || value < 100 || value > 900)) fail(`${context}.style.fontWeight must be 100–900`);
    if (key === 'radius' && (!finite(value) || value < 0 || value > 200)) fail(`${context}.style.radius must be 0–200`);
    if (key === 'align' && !['left', 'center', 'right'].includes(value)) fail(`${context}.style.align is unsupported`);
    if (key === 'fit' && !['contain', 'cover'].includes(value)) fail(`${context}.style.fit is unsupported`);
    if (key === 'fontFamily' && (typeof value !== 'string' || value.length > 100)) fail(`${context}.style.fontFamily is invalid`);
  }
  if ('w' in style && 'x' in style && style.x + style.w > 1.000001) fail(`${context} extends beyond frame width`);
  if ('h' in style && 'y' in style && style.y + style.h > 1.000001) fail(`${context} extends beyond frame height`);
}

export function validateProject(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) fail('root must be an object');
  if (data.version !== 1) fail('version must be 1');
  if (!finite(data.duration) || data.duration <= 0 || data.duration > 900) fail('duration must be >0 and <=900 seconds');
  if (!finite(data.fps) || data.fps < 1 || data.fps > 120) fail('fps must be a number from 1 to 120');
  if (!HEX.test(data.background)) fail('background must be #RRGGBB');
  if (!Array.isArray(data.scenes) || !data.scenes.length || data.scenes.length > 128) fail('scenes must contain 1–128 entries');
  const ids = new Set();
  const scenes = data.scenes.map((raw, index) => {
    const label = `scenes[${index}]`;
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) fail(`${label} must be an object`);
    if (typeof raw.id !== 'string' || !/^[a-zA-Z0-9_-]{1,64}$/.test(raw.id) || ids.has(raw.id)) fail(`${label}.id must be unique, 1–64 safe characters`);
    ids.add(raw.id);
    if (!TYPES.has(raw.type)) fail(`${label}.type must be title, panel, or image`);
    if (!finite(raw.start) || !finite(raw.end) || raw.start < 0 || raw.start >= raw.end || raw.end > data.duration) fail(`${label} has invalid start/end`);
    if (raw.type === 'image') {
      if (typeof raw.image !== 'string' || !raw.image.trim()) fail(`${label}.image is required`);
    } else if (typeof raw.text !== 'string' || !raw.text.trim() || raw.text.length > 600) fail(`${label}.text must contain 1–600 characters`);
    const defaults = raw.type === 'image' ? { x: 0.08, y: 0.08, w: 0.84, h: 0.84 } : { x: 0.08, y: 0.22, w: 0.84, h: 0.56 };
    const style = { ...defaults, ...(raw.style || {}) };
    validateStyle(style, label);
    const styleByFormat = {};
    for (const [format, override] of Object.entries(raw.styleByFormat || {})) {
      if (!(format in FORMATS)) fail(`${label}.styleByFormat.${format} is unsupported`);
      styleByFormat[format] = { ...style, ...override };
      validateStyle(styleByFormat[format], `${label}.styleByFormat.${format}`);
    }
    return { ...raw, style, styleByFormat };
  });
  return { ...data, scenes };
}

export function loadProject(projectPath) {
  const file = path.resolve(projectPath);
  const project = validateProject(JSON.parse(fs.readFileSync(file, 'utf8')));
  return { file, root: path.dirname(file), project };
}

export function resolveImage(root, image) {
  if (path.isAbsolute(image)) fail('image path must be relative to project');
  const file = path.resolve(root, image);
  const relative = path.relative(root, file);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) fail(`image path escapes project: ${image}`);
  const realRoot = fs.realpathSync(root), real = fs.realpathSync(file);
  const safe = path.relative(realRoot, real);
  if (!safe || safe.startsWith('..') || path.isAbsolute(safe)) fail(`image symlink escapes project: ${image}`);
  if (!/\.(png|jpg|jpeg|webp)$/i.test(real)) fail(`image must be PNG, JPEG, or WebP: ${image}`);
  if (fs.statSync(real).size > 20 * 1024 * 1024) fail(`image is larger than 20 MiB: ${image}`);
  return real;
}

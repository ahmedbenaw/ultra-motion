"""Small, read-only session hint for a Reelcraft project at the current cwd.

Both supported hook hosts provide a JSON object on stdin with ``cwd``. Plain
stdout becomes context for SessionStart; all other cases stay silent.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except (ValueError, OSError):
        return 0
    if not isinstance(event, dict):
        return 0
    cwd = event.get("cwd")
    if not isinstance(cwd, str) or not cwd:
        return 0
    modern = Path(cwd) / "project-v2.json"
    if modern.is_file():
        print("Portable project detected. Read engagement_plan, show its current evidence and Moments, and record explicit user approval of its digest before starting work. Inspect work_status for recovery; never infer completion from a worker-start response.")
        return 0
    project = Path(cwd) / "project.json"
    try:
        if not project.is_file() or project.stat().st_size > 1024 * 1024:
            return 0
        data = json.loads(project.read_text(encoding="utf-8"))
    except (OSError, ValueError, UnicodeError):
        return 0
    if not isinstance(data, dict) or data.get("schema_version") != 1:
        return 0
    approval = data.get("approval")
    if isinstance(approval, dict) and approval.get("approved") is False:
        print(
            "Reelcraft project detected in the current directory. Its shot plan "
            "is not approved. Show the plan, obtain the user's explicit approval, "
            "then record it with `studio.py approve` before any render."
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

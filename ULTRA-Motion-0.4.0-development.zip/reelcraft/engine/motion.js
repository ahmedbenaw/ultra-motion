/* Reelcraft's deterministic, stateless motion primitives. */
(function (root) {
  'use strict';

  function clamp(value, low = 0, high = 1) {
    return Math.min(high, Math.max(low, value));
  }

  // Critically damped second-order step response. No frame history is needed.
  function springStep(elapsed, speed = 12) {
    if (elapsed <= 0) return 0;
    const u = elapsed * speed;
    return 1 - (1 + u) * Math.exp(-u);
  }

  function sceneMotion(time, start, end) {
    // A scene beginning at zero is already readable on the opening frame.
    const enter = springStep(time - start + (start === 0 ? 0.28 : 0), 13);
    const leave = springStep(time - (end - 0.27), 16);
    const visible = clamp(enter * (1 - leave));
    return {
      opacity: visible,
      offset: (1 - enter) * 42 - leave * 30,
      scale: 0.94 + 0.06 * enter - 0.025 * leave,
    };
  }

  const api = Object.freeze({ clamp, springStep, sceneMotion });
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ReelcraftMotion = api;
})(typeof window === 'undefined' ? globalThis : window);

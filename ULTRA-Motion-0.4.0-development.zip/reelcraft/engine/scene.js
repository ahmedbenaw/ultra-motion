/* The frame at t is computed entirely from the validated project and t. */
(function () {
  'use strict';
  let items = [];
  let size = { width: 1920, height: 1080 };

  function init(project, dimensions, images, alpha, format) {
    size = dimensions;
    const stage = document.getElementById('stage');
    stage.replaceChildren();
    stage.style.width = `${size.width}px`;
    stage.style.height = `${size.height}px`;
    stage.style.background = alpha ? 'transparent' : project.background;
    const scale = Math.min(size.width / 1920, size.height / 1080);

    items = project.scenes.map((scene) => {
      const s = { ...scene.style, ...(scene.styleByFormat?.[format] || {}) };
      const el = document.createElement('div');
      el.className = `scene ${scene.type}`;
      el.style.left = `${s.x * size.width}px`;
      el.style.top = `${s.y * size.height}px`;
      el.style.width = `${s.w * size.width}px`;
      el.style.height = `${s.h * size.height}px`;
      el.style.color = s.color || '#ffffff';
      el.style.fontFamily = s.fontFamily || 'Arial, sans-serif';
      el.style.fontSize = `${(s.fontSize || (scene.type === 'title' ? 112 : 68)) * scale}px`;
      el.style.fontWeight = String(s.fontWeight || 700);
      el.style.lineHeight = '1.12';
      el.style.textAlign = s.align || 'left';
      el.style.justifyContent = s.align === 'center' ? 'center' : s.align === 'right' ? 'flex-end' : 'flex-start';
      el.style.padding = scene.type === 'panel' ? `${38 * scale}px` : '0';
      if (scene.type === 'panel') {
        el.style.background = s.background || '#202832';
        el.style.borderRadius = `${(s.radius ?? 28) * scale}px`;
      }
      if (scene.type === 'image') {
        const img = document.createElement('img');
        img.src = images[scene.id];
        img.alt = scene.alt || '';
        img.style.objectFit = s.fit || 'contain';
        el.appendChild(img);
      } else {
        el.textContent = scene.text;
      }
      stage.appendChild(el);
      return { scene, el };
    });
    seek(0);
    return true;
  }

  function seek(time) {
    for (const { scene, el } of items) {
      const m = ReelcraftMotion.sceneMotion(time, scene.start, scene.end);
      el.style.opacity = m.opacity.toFixed(6);
      el.style.transform = `translateY(${m.offset.toFixed(4)}px) scale(${m.scale.toFixed(6)})`;
      el.style.visibility = m.opacity < 0.0001 ? 'hidden' : 'visible';
    }
    return true;
  }

  window.Reelcraft = { init, seek };
})();

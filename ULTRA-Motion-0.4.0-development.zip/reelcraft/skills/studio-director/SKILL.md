---
name: studio-director
description: Coordinate a motion project from intake through an approved timeline, rendering, audio, review and editor handoff. Use for a complete automated reel or B-roll workflow, including synchronous or background jobs.
---

# Studio director

Route the requested outcome to `motion-reel` or `motion-broll`. Maintain one
project directory and one scene plan throughout the chain.

1. Use `brand-intake` to collect missing inputs and verified assets. Ask only
   for choices that materially affect the story, text, formats, sound or rights.
2. Use `timeline-plan` to produce a spec and an exact shot table. Show the plan.
   Record the user's approval of its digest; never approve on their behalf.
3. Use `audio-design` when sound is requested. Confirm paid or external voice
   generation before calling a connected service. Local supplied narration and
   synthesized music need no service credentials.
4. Check runtime capabilities. Prefer the local MCP tools when connected;
   otherwise use `scripts/studio.py`. Start quick work synchronously, and use a
   detached job for longer renders. Return the project path and job state promptly.
5. Check status until a terminal state. On a failure, inspect the recorded
   error and retry only after fixing its cause. Each retry creates a new attempt.
6. Use `studio-review` on actual media and review images. Distinguish encoded
   checks from creative judgement. Changes to the plan require fresh approval.
7. Deliver playable exports, alpha assets when requested, placement data,
   review evidence and unresolved issues. Publishing requires user authorization.

Local background jobs require a running host. If the execution environment
ends, inspect the saved project and use `retry` for a stale worker. This is
recovery from recorded state, not a guarantee of rendering after host shutdown.

In a chat-only host, complete intake and the plan and identify the required
local runner. Never report media generation without an actual output file.

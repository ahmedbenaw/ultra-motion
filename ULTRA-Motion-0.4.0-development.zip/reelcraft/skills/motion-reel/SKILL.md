---
name: motion-reel
description: Plan and produce a short product launch reel, showreel, promo, sizzle, or social video from a brief or product URL. Use when the user wants a complete motion reel with a shot plan, animation, audio, review, and export.
---

# Motion reel

Build the reel in reviewable stages. The user's product, audience, goal, and supplied assets govern the creative direction. A reference video may guide pacing and visual grammar, never copied shots or identity.

1. **Intake.** Ask together for only the missing decisions: product and promise, audience, action to prompt, duration, aspect ratios, language, supplied assets, soundtrack choice, narration, and deadline. If a URL is provided, inspect it with an available authorized browser or capture tool; distinguish measured brand details from guesses. Do not fabricate assets, measurements, or rights.
2. **Plan.** Prepare a concise brief, visual direction, and shot table with time or beat ranges, exact screen text, action, transitions, audio cues, and vertical framing. Explain any external dependency or anticipated cost. Show this plan to the user and wait for explicit approval before generating or rendering the film. Revise the plan when requested.
3. **Build.** In an executable environment, make a v1 JSON spec with `workflow: reel`, `name`, `input`, `timeline` (duration, fps, and timed scenes), `formats`, and `audio`. Check `python3 scripts/studio.py --help` from the plugin root, run its environment check, and use `init --spec ... --project ...` and `plan --project ...`. After the user has approved the exact current plan, record its reported digest with `approve --project ... --hash ...`, then use `run --project ...`. Keep assets, timeline, and outputs in the project workspace. A deterministic frame should be reproducible from its timestamp.
4. **Review.** Use the `studio-review` skill on contact sheets, short clips, and final exports. Fix observable defects and repeat the checks affected by each fix. Record the evidence and remaining limitations; do not claim a numeric quality score without an actual review.
5. **Deliver.** Give the output locations and playable exports, duration, aspect ratios, soundtrack or narration status, review outcome, and any remaining issue. If the host cannot run the renderer, deliver the approved plan and project files and state the exact missing runtime dependency.

For a narrower sequence of supporting footage, use `motion-broll`. Preserve the user's approval gate even when a local runner supports detached jobs or a platform offers background execution.

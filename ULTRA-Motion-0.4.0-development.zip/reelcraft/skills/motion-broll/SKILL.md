---
name: motion-broll
description: Plan and produce timed B-roll or graphics over a supplied talking-head or source video, optionally aligned to SRT/VTT captions. Use for editor-ready cutaway timing, overlay clips, or a social excerpt rather than a complete launch reel.
---

# Motion B-roll

Plan cutaways and timed graphics around the supplied footage while preserving the original source.

1. **Intake.** Ask for the talking-head or other source video, target excerpt and formats, message, visual assets, and any SRT/VTT transcript. The local runner requires a readable local `input.source_video`; `input.captions` is optional. With captions, use cue times and spoken context to place visual moments. Without captions, inspect the footage and ask for or establish time anchors instead of inventing speech or timestamps.
2. **Editor plan.** List each cutaway or overlay with exact in/out time, what remains visible of the source, graphic or image, on-screen text, transition, and intended edit purpose. Keep the speaker and dialogue intelligible. Show the plan and wait for explicit user approval before render.
3. **Build.** Use only supplied or authorized media and factual product claims. In an executable environment, inspect `python3 scripts/studio.py --help` and run its environment check. Write a v1 spec with `workflow: broll`, `input.source_video`, optional `input.captions`, timed `timeline.scenes`, formats, and audio. Initialize and plan the project. After the user approves that exact plan, record the plan digest with `approve --project ... --hash ...`, then run it.
4. **Review.** Check the composite at intended size: speaker preservation, caption timing if present, readable overlays, transitions, cropping, and original audio. Review the output and objective report; fix and recheck defects.
5. **Handoff.** Deliver the rendered formats, timecoded placement list, project timeline, copied source and caption assets, and any transparent graphics intermediate produced by the renderer. Name missing intermediates honestly; the original video file remains untouched.

If the user asks for a full product film, use `motion-reel`. If the source file or runtime is unavailable, deliver the editor plan and the exact missing inputs.

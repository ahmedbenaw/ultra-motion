---
name: timeline-plan
description: Turn a motion brief or captioned video into an exact, validated scene timeline and reviewable shot plan. Use before rendering and when revising timings or on-screen text.
---

# Timeline plan

Use `templates/reel.spec.json` or `templates/broll.spec.json` as a structural
example. Define `workflow`, `name`, `input`, `timeline`, `formats`, `background`
and `audio`. Scene types are title, panel and image. Every scene has a unique
safe ID, start/end seconds and exact text or a permitted local image.

Keep claims traceable to supplied facts. Put unverified ideas in the planning
notes instead of asserting them on screen. Use source cue times for B-roll;
`scripts/timing.py captions FILE` reads SRT/VTT without inventing word timings.
Fractional source frame rates such as `30000/1001` are supported by the runner.

Write a shot table containing source evidence, exact screen text, start/end,
placement, motion, audio cues and each format's layout. Check phone legibility
and speaker coverage. Supply `styleByFormat` overrides where geometry differs.

Initialize an isolated project, run `plan`, show its scene content and digest
to the user, then use `approve --hash` only after approval. The runner binds
rendering to the plan and imported asset hashes. Edit the spec and create a new
project when source material changes.

---
name: studio-review
description: Critique and validate a motion reel, B-roll clip, contact sheet, storyboard, or export. Use when the user wants a concrete quality review, defects, prioritized fixes, or export readiness.
---

# Studio review

Review what is actually visible and audible. Separate evidence from recommendations.

1. Identify the artifact and target platform, aspect ratio, audience, duration, and approved brief or shot plan. If video cannot be inspected, ask for a playable file, frames, or contact sheet and make the review scope explicit.
2. Examine opening clarity, shot purpose, brand fidelity, text legibility at phone size, safe areas, continuity, pacing, animation behavior, audio timing, voice clarity where present, ending, and loop seam where relevant.
3. For each issue, record the timestamp or shot, observed evidence, severity, likely impact, and a specific fix. Avoid inventing measurements; run available inspection scripts or probes to substantiate claims about duration, frame consistency, loudness, or codec.
4. Prioritize the few changes that will improve the outcome most. After a fix, review the affected shots and export again. Keep earlier observations and their resolved status in the review log.
5. Return a concise verdict: ready, needs changes, or blocked by missing evidence. Include tested formats, remaining defects, and the location of reviewed artifacts.

An automated check can flag measurable defects, but a creative score requires direct viewing and an explicit rubric. Never certify a video that was not reviewed.

# Runtime contract

A v2 directory contains `project-v2.json`. Read `engagement_plan` before issuing commands. Commands have `id`, `expected_revision`, `action`, and `payload`. Reusing an identical command returns its original receipt. Reusing an ID with different content fails. A stale revision fails without replacing current state.

Supported actions are `set_mission`, `set_policy`, `set_brand`, `set_creative`, `set_narrative`, `replace_truth`, `replace_moments`, `replace_anchors`, `replace_outputs`, `replace_surfaces`, `choose_preset`, `save_preset`, `record_decision`, and `approve`. Read the current field shape before replacing a structure. A preset must resolve all ten control groups with automatic, choice, fixed or not-applicable modes. Automatic means recommendation pending, not permission granted.

A Moment includes `id`, `title`, `content`, `duration` and `anchor`. Anchor kinds are seconds, word, beat, event, and after. Seconds use `seconds`. Semantic anchors use `ref` and `index`, which point into the project's anchor registry. After references a Moment ID. Optional `offset` is a rational time adjustment. Compilation uses exact rational arithmetic and nearest-half-up rounding to frame/sample indices. Frame intervals are half-open. Missing references, cycles, negative start times and sub-frame durations fail.

Work definitions include `id`, `handler`, `depends_on`, and `inputs`. The runtime restricts handlers and required input fields. The approved plan includes the work definitions. The runtime writes a separate attempt directory, hashes outputs and records their provenance. A technical `verified` job state means generation and artifact integrity succeeded. It is not human acceptance or expert validation. Review those outputs before delivery.

The portable preview can be opened as an HTML file. Its command composer downloads proposals for the assistant/CLI to apply. `python3 scripts/project.py serve --project PATH` optionally runs a loopback-only preview with revision-checked actions and refreshed state. This is a local development option, not a hosted service or proof of ChatGPT/Claude native integration.

`render_proof` requires every content field as a declared input and an MP4, alpha MOV, PNG, WebM or GIF output request. It compiles Moments at an integer frame rate of 1–120, supports at most 128 Moments and 30 seconds, and writes draft media with a verified renderer manifest. `title`, `panel`, `image` and `none` are the supported visual kinds. Inputs for images are copied from the project directory after path and size checks. Audio-bearing Moments fail clearly; current proofs do not preserve source audio or composite source video. Open the media itself before treating it as visually approved.

`quantitative_check` requires `truth` input. A claim's optional `calculation` specifies `operation` (`sum`, `difference`, `ratio`, `percent_change`), `inputs` with labels, decimal values, compatible units and source IDs, plus optional precision 0–8. Results are recomputed and linked to existing claim sources. Independent verification of the original source values and conclusions is still required.

Branch commands: `branch-init --repo PATH` creates a local bare repository; `branch-save --repo PATH --project DIR [--expected-tip COMMIT]` writes the project branch only when storage policy is `github`; `branch-configure --repo PATH --origin GITHUB_URL` sets a selected remote without replacing another one; `branch-push --repo PATH --id PROJECT_ID` makes a non-force push; `branch-fetch --repo PATH --id PROJECT_ID` updates only a compatible local branch; `branch-restore --repo PATH --id PROJECT_ID --destination NEW_DIR` creates and verifies a fresh copy. The equivalent MCP tools use workspace-relative repository paths. Only `project-v2.json`, `assets/` and `artifacts-v2/` are snapshotted; files over 50 MiB or snapshots over 200 MiB fail until a media-storage strategy is configured. There is no automatic GitHub repository creation or implicit remote sync.


`export_outputs` generates requested SRT/VTT, JSON, restricted solid-panel Lottie, A4 PDF briefings and editable PPTX briefings. All content fields are required inputs. Install optional document dependencies with `python3 scripts/setup.py --exports`. PDF is currently printable ASCII only. PPTX honors the declared ratio. These are content/structure checks, not viewer or expert acceptance. Read `docs/exports.md`.

`assemble_audio` generates 16-bit stereo PCM WAV from optional Moment `audio.file` and `audio.gain` (0-1). Input is 16-bit PCM mono/stereo at the output sample rate. Placement uses exact semantic sample positions; overlaps that would clip fail instead of silently normalizing. Maximum 128 Moments and 30 seconds. Empty audio explicitly produces a silent WAV. Generated voice, mastering and mux into video are separate.

Approval and job digests include bytes of referenced image/audio/font inputs. Missing or replaced inputs make prior results stale. For branch snapshots, referenced inputs must live inside `assets/`; saving refuses to omit an input.


`work_propose` (CLI `propose-work`) returns a revision-labelled dependency proposal from requested output kinds and supplied evidence. It does not define work, execute it or approve it. Review its warnings, then use `work_define` with the current revision and obtain approval of the resulting plan.

---
name: audio-design
description: Plan and build a local soundtrack, timed sound effects and supplied narration for a motion project. Use for beat alignment, audio cues, mixing or music timing analysis.
---

# Audio design

Choose `audio.mode` as none, synth or file. A supplied `voice_file` is optional.
The original local synth provides a rhythmic bed, not a commissioned musical
composition. Its BPM and sound effects are explicit in the project spec.

Use `scripts/timing.py music FILE --bpm BPM` to inspect a supplied track.
The onset estimator reports confidence and may detect half/double tempo.
Listen and confirm the grid before assigning creative events. A known BPM
for a synthesized score is a planned grid, not an independently measured one.

Set click or impact cues with exact seconds. Keep speech readable in the mix.
The local audio pipeline normalizes toward -14 LUFS and limits true peak to
-1.5 dBTP; inspect the actual encoded mix before reporting achieved loudness.

Accept a local narration recording or use an explicitly configured external
voice service. Do not invent credentials, a voice clone, a cost estimate, or a
successful take. Preserve source audio in B-roll when no replacement mix is used.

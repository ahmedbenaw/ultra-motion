"""Fingerprint explicitly referenced local inputs without interpreting arbitrary text."""
import hashlib
from pathlib import Path, PureWindowsPath

from .core import ProjectError

MAX_ASSET_BYTES = 50 * 1024 * 1024


def _reference(value):
    if not isinstance(value, str) or not value or '\\' in value:
        raise ProjectError('asset reference must be a relative POSIX path')
    path = Path(value)
    if path.is_absolute() or PureWindowsPath(value).drive or '..' in path.parts or ':' in value:
        raise ProjectError('asset reference must be relative and cannot escape the project')
    if not path.parts:
        raise ProjectError('asset reference must name a file')
    return path


def _fingerprint(root, relative):
    source = root
    for component in relative.parts:
        source = source / component
        if source.is_symlink():
            raise ProjectError('asset reference cannot use a symlink')
    try:
        if not source.resolve().is_relative_to(root) or not source.is_file():
            raise ProjectError('referenced asset is missing or escapes the project')
        before = source.stat()
        if before.st_size > MAX_ASSET_BYTES:
            raise ProjectError('referenced asset exceeds 50 MiB')
        checksum = hashlib.sha256()
        count = 0
        with source.open('rb') as stream:
            while block := stream.read(1024 * 1024):
                count += len(block)
                if count > MAX_ASSET_BYTES:
                    raise ProjectError('referenced asset exceeds 50 MiB')
                checksum.update(block)
        after = source.stat()
        if source.is_symlink() or (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns) or count != after.st_size:
            raise ProjectError('referenced asset changed while being fingerprinted')
        return {'path': relative.as_posix(), 'sha256': checksum.hexdigest()}
    except OSError as exc:
        raise ProjectError(f'referenced asset cannot be read: {relative.as_posix()}') from exc


def asset_fingerprint(project, root, fields):
    """Return sorted unique hashes for local asset references in selected fields.

    Only Moment visual.image, audio.file/audio.voice_file, and
    extensions.export_font are interpreted as paths. This does not assert that
    any particular renderer supports those assets.
    """
    selected = set(fields)
    references = []
    if 'moments' in selected:
        for moment in project.get('moments', []):
            visual = moment.get('visual', {})
            audio = moment.get('audio', {})
            for mapping, key in ((visual, 'image'), (audio, 'file'), (audio, 'voice_file')):
                if key in mapping:
                    references.append(mapping[key])
    if 'extensions' in selected and 'export_font' in project.get('extensions', {}):
        references.append(project['extensions']['export_font'])
    paths = {_reference(value).as_posix() for value in references}
    root = Path(root).resolve()
    return [_fingerprint(root, Path(value)) for value in sorted(paths)]

"""Bounded, opt-in public HTTPS brand metadata capture.

The network fetch pins the vetted DNS answer to the TLS connection. Redirects
are vetted afresh. Only the requested HTML is fetched; linked resources are
recorded as metadata and never downloaded.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import datetime as dt
import hashlib
from html.parser import HTMLParser
import http.client
import ipaddress
import json
import os
from pathlib import Path
import queue
import re
import socket
import ssl
import tempfile
import threading
import time
from urllib.parse import quote, urljoin, urlsplit, urlunsplit


MAX_BYTES = 2 * 1024 * 1024
MAX_REDIRECTS = 3
TIMEOUT_SECONDS = 12
HEX_COLOR = re.compile(r"(?<![\w#])#(?:[0-9a-fA-F]{6}|[0-9a-fA-F]{3})(?![0-9a-fA-F])")
CSS_COLOR = re.compile(r"(?i)(?:color|background(?:-color)?|border-color)\s*:\s*(#[0-9a-f]{3,8})\b")


class CaptureError(ValueError):
    """A rejected URL, network failure, or malformed page."""


def _public_ip(value: str) -> bool:
    address = ipaddress.ip_address(value)
    return (address.is_global and not address.is_multicast and
            not address.is_reserved and not address.is_unspecified)


@dataclass(frozen=True)
class Response:
    url: str
    status: int
    headers: dict[str, str]
    body: bytes
    peer_ip: str


def _url(raw: str) -> tuple[str, str, str]:
    if not isinstance(raw, str) or len(raw) > 4096 or any(ord(c) < 33 or ord(c) == 127 for c in raw):
        raise CaptureError("URL must be a compact HTTPS URL without whitespace or controls")
    try:
        parsed = urlsplit(raw)
        port = parsed.port
    except ValueError as exc:
        raise CaptureError(f"Malformed URL: {exc}") from exc
    if parsed.scheme.lower() != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise CaptureError("Only public HTTPS URLs without credentials are accepted")
    if port not in (None, 443):
        raise CaptureError("Only the standard HTTPS port (443) is accepted")
    try:
        host = parsed.hostname.encode("idna").decode("ascii").lower().rstrip(".")
    except UnicodeError as exc:
        raise CaptureError("Invalid hostname") from exc
    if not host or host in {"localhost", "localhost.localdomain"} or host.endswith((".local", ".internal")):
        raise CaptureError("A public hostname or globally routable IP is required")
    if "%" in host or "\\" in raw:
        raise CaptureError("Ambiguous host or path encoding is not accepted")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        if len(host) > 253 or not all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", part)
                                       for part in host.split(".")):
            raise CaptureError("Invalid public hostname")
    else:
        if not _public_ip(str(address)):
            raise CaptureError("Private, reserved, and local IP addresses are blocked")
    authority = f"[{host}]" if ":" in host else host
    path = quote(parsed.path or "/", safe="/%:@!$&'()*+,;=-._~")
    query = quote(parsed.query, safe="/%?:@!$&'()*+,;=-._~")
    clean = urlunsplit(("https", authority, path, query, ""))
    return clean, host, path + ("?" + query if query else "")


def _public_addresses(host: str) -> list[str]:
    try:
        results = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise CaptureError(f"Cannot resolve hostname: {exc}") from exc
    addresses = list(dict.fromkeys(item[4][0] for item in results))
    if not addresses or any(not _public_ip(ip) for ip in addresses):
        raise CaptureError("DNS returned a private, reserved, or local address")
    return addresses


def _resolve_with_deadline(host: str, deadline: float) -> list[str]:
    """Bound OS resolver calls without leaving a non-daemon worker behind."""
    results: queue.Queue = queue.Queue(maxsize=1)

    def resolve():
        try:
            results.put(_public_addresses(host))
        except Exception as exc:
            results.put(exc)

    threading.Thread(target=resolve, daemon=True, name="reelcraft-dns").start()
    try:
        value = results.get(timeout=max(0, deadline - time.monotonic()))
    except queue.Empty as exc:
        raise CaptureError("DNS lookup timed out") from exc
    if isinstance(value, Exception):
        raise value
    return value


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(self, hostname: str, ip: str, timeout: float):
        super().__init__(hostname, port=443, timeout=timeout, context=ssl.create_default_context())
        self._vetted_ip = ip

    def connect(self):
        sock = socket.create_connection((self._vetted_ip, 443), self.timeout)
        try:
            self.sock = self._context.wrap_socket(sock, server_hostname=self.host)
        except BaseException:
            sock.close()
            raise


def _fetch_once(raw: str, deadline: float, max_bytes: int) -> Response:
    url, host, target = _url(raw)
    addresses = _resolve_with_deadline(host, deadline)
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise CaptureError("Capture timed out")
    connection = _PinnedHTTPSConnection(host, addresses[0], min(remaining, 5))
    try:
        connection.request("GET", target, headers={
            "Host": f"[{host}]" if ":" in host else host,
            "User-Agent": "ReelcraftBrandCapture/1.0 (+metadata-only)",
            "Accept": "text/html,application/xhtml+xml",
            "Accept-Encoding": "identity",
            "Connection": "close",
        })
        response = connection.getresponse()
        headers = {key.lower(): value for key, value in response.getheaders()}
        if response.status in (301, 302, 303, 307, 308):
            return Response(url, response.status, headers, b"", addresses[0])
        if response.status != 200:
            raise CaptureError(f"Site returned HTTP {response.status}")
        content_type = headers.get("content-type", "").split(";", 1)[0].strip().lower()
        if content_type not in {"text/html", "application/xhtml+xml"}:
            raise CaptureError(f"Expected HTML, received {content_type or 'unknown content type'}")
        if headers.get("content-encoding", "identity").lower() != "identity":
            raise CaptureError("Compressed response is unsupported for bounded capture")
        try:
            length = int(headers.get("content-length", "0"))
        except ValueError:
            raise CaptureError("Invalid Content-Length")
        if length > max_bytes:
            raise CaptureError(f"Page exceeds {max_bytes} byte limit")
        chunks = []
        total = 0
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise CaptureError("Capture timed out")
            # A slow peer cannot extend the overall deadline with repeated chunks.
            if connection.sock is not None:
                connection.sock.settimeout(min(remaining, 2))
            chunk = response.read(min(65536, max_bytes + 1 - total))
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise CaptureError(f"Page exceeds {max_bytes} byte limit")
            chunks.append(chunk)
        return Response(url, 200, headers, b"".join(chunks), addresses[0])
    except (OSError, ssl.SSLError, http.client.HTTPException) as exc:
        raise CaptureError(f"HTTPS capture failed: {exc}") from exc
    finally:
        connection.close()


def _retrieve(url: str, *, max_bytes: int, timeout: float) -> tuple[Response, list[dict]]:
    deadline = time.monotonic() + timeout
    current, _, _ = _url(url)
    hops: list[dict] = []
    seen = set()
    for _ in range(MAX_REDIRECTS + 1):
        if current in seen:
            raise CaptureError("Redirect loop")
        seen.add(current)
        response = _fetch_once(current, deadline, max_bytes)
        hops.append({"url": response.url, "status": response.status, "peer_ip": response.peer_ip})
        if response.status == 200:
            return response, hops
        location = response.headers.get("location")
        if not location:
            raise CaptureError("Redirect is missing Location")
        current, _, _ = _url(urljoin(response.url, location))
    raise CaptureError(f"More than {MAX_REDIRECTS} redirects")


class _Metadata(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title = ""
        self.description = ""
        self.og: dict[str, str] = {}
        self.theme_color = ""
        self.styles: list[str] = []
        self._in_title = False
        self._in_style = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "title":
            self._in_title = True
        elif tag == "style":
            self._in_style = True
        elif tag == "meta":
            key = (attrs.get("property") or attrs.get("name") or "").lower()
            value = (attrs.get("content") or "").strip()[:1000]
            if key == "description":
                self.description = value
            elif key == "theme-color":
                self.theme_color = value
            elif key.startswith("og:") and len(self.og) < 30:
                self.og[key] = value
        if attrs.get("style"):
            self.styles.append(attrs["style"][:2000])

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
        elif tag == "style":
            self._in_style = False

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        elif self._in_style and sum(map(len, self.styles)) < 200_000:
            self.styles.append(data)


def _metadata(body: bytes, headers: dict[str, str], url: str) -> dict:
    match = re.search(r"charset\s*=\s*([^;\s]+)", headers.get("content-type", ""), re.I)
    charset = match.group(1).strip('"\'') if match else "utf-8"
    try:
        html = body.decode(charset, errors="replace")
    except LookupError as exc:
        raise CaptureError(f"Unknown page charset: {charset}") from exc
    parser = _Metadata()
    parser.feed(html)
    colors = Counter()
    for style in parser.styles:
        for found in CSS_COLOR.findall(style):
            value = found.lower()
            if len(value) in (4, 7):
                colors[value] += 1
    if HEX_COLOR.fullmatch(parser.theme_color):
        colors[parser.theme_color.lower()] += 1
    og = dict(parser.og)
    if og.get("og:image"):
        og["og:image"] = urljoin(url, og["og:image"])
    return {"title": parser.title.strip()[:500], "description": parser.description,
            "theme_color": parser.theme_color, "colors": [{"hex": c, "count": n}
            for c, n in colors.most_common(12)], "open_graph": og, "charset": charset}


def _offline_screenshot(html: str, path: Path) -> None:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise CaptureError("Screenshot requested but Playwright is not installed") from exc
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            try:
                context = browser.new_context(viewport={"width": 1280, "height": 720},
                                              java_script_enabled=False)
                context.route("**/*", lambda route: route.abort())
                page = context.new_page()
                page.set_content(html, wait_until="domcontentloaded", timeout=5000)
                page.screenshot(path=str(path), full_page=False, timeout=5000)
            finally:
                browser.close()
    except Exception as exc:
        raise CaptureError(f"Offline screenshot failed (check Chromium): {exc}") from exc


def capture(url: str, output: Path | str, *, screenshot: bool = False,
            max_bytes: int = MAX_BYTES, timeout: float = TIMEOUT_SECONDS) -> dict:
    """Capture public HTML metadata in a new directory; optionally render it offline."""
    if not 1024 <= max_bytes <= MAX_BYTES or not 1 <= timeout <= TIMEOUT_SECONDS:
        raise CaptureError("Capture limits are outside the supported bounds")
    target = Path(output).expanduser().resolve()
    if target.exists():
        if not target.is_dir():
            raise CaptureError("Output path must be a directory")
        if any(target.iterdir()):
            raise CaptureError("Output directory is not empty; choose a new directory")
    response, hops = _retrieve(url, max_bytes=max_bytes, timeout=timeout)
    details = _metadata(response.body, response.headers, response.url)
    target.mkdir(parents=True, exist_ok=True)
    if screenshot:
        charset = details["charset"]
        _offline_screenshot(response.body.decode(charset, errors="replace"), target / "page-offline.png")
    manifest = {"schema_version": 1, "requested_url": _url(url)[0],
                "final_url": response.url, "captured_at": dt.datetime.now(dt.timezone.utc).isoformat(),
                "fetch": {"redirects": hops, "content_type": response.headers.get("content-type"),
                          "bytes": len(response.body), "sha256": hashlib.sha256(response.body).hexdigest()},
                "brand": details,
                "assets": ([{"path": "page-offline.png", "kind": "offline_html_screenshot",
                             "note": "External CSS, fonts, images and scripts were blocked."}]
                           if screenshot else []),
                "limitations": ["Colors are sampled from HTML inline/style declarations only.",
                                "Linked logos, images, stylesheets and fonts were not downloaded."]}
    fd, temp = tempfile.mkstemp(prefix=".capture-", suffix=".json", dir=target)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(manifest, stream, indent=2, ensure_ascii=False)
            stream.write("\n")
        os.replace(temp, target / "provenance.json")
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return manifest

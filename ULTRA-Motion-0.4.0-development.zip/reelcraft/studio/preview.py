"""Self-contained native-file projection, optionally connected to a local preview."""
import json
from pathlib import Path

from .project import compile_moments


def write_preview(project, path, token=None):
    from .presets import project_recipes, work_proposal
    template = (Path(__file__).resolve().parents[1] / 'templates' / 'project-room.html').read_text(encoding='utf-8')
    data = {'project': project, 'compiled': compile_moments(project), 'token': token, 'presets': project_recipes(project), 'work_proposal': work_proposal(project)}
    encoded = json.dumps(data, ensure_ascii=False).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    Path(path).write_text(template.replace('__PROJECT_DATA__', encoded), encoding='utf-8')
    return str(path)

"""Portable local job coordinator for reels and narrated B-roll.

Python standard library only. Rendering is delegated to renderer/render.mjs;
ffmpeg handles source-video composition and optional audio muxing.
"""

from __future__ import annotations

import contextlib
import datetime as dt
import hashlib
from fractions import Fraction
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from typing import Any
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
RENDERER = ROOT / "renderer" / "render.mjs"
FORMATS = {"16x9": (1920, 1080), "1x1": (1080, 1080),
           "4x5": (1080, 1350), "9x16": (1080, 1920)}
SCENE_TYPES = {"title", "panel", "image"}
STATES = {"planned", "queued", "running", "completed", "failed", "cancelled"}
CURRENT_CHILD: subprocess.Popen | None = None
CURRENT_PROJECT: Path | None = None
WORKERS: dict[str, subprocess.Popen] = {}


class ProjectError(ValueError):
    pass


class ApprovalRequired(ProjectError):
    pass


class JobCancelled(ProjectError):
    pass


def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def _object(value: Any, label: str) -> dict:
    if not isinstance(value, dict):
        raise ProjectError(f"{label} must be an object")
    return value


def _string(value: Any, label: str, required: bool = True) -> str:
    if value is None and not required:
        return ""
    if not isinstance(value, str) or (required and not value.strip()):
        raise ProjectError(f"{label} must be a nonempty string")
    if any(ord(ch) < 32 and ch not in "\n\t" for ch in value):
        raise ProjectError(f"{label} contains a control character")
    return value.strip()


def _number(value: Any, label: str, low: float, high: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ProjectError(f"{label} must be a number")
    n = float(value)
    if not (low <= n <= high):
        raise ProjectError(f"{label} must be between {low:g} and {high:g}")
    return n


def _source(value: Any, label: str, base_dir: Path | None = None) -> str:
    """Resolve local media, never treating a user string as a shell fragment."""
    name = _string(value, label)
    if name.startswith(("http:", "https:", "file:")):
        raise ProjectError(f"{label} requires a local file, not a URL")
    candidate = Path(name).expanduser()
    path = ((base_dir or Path.cwd()) / candidate).resolve(strict=True)
    if not path.is_file():
        raise ProjectError(f"{label} must be a regular file")
    if path.stat().st_size > 4 * 1024 ** 3:
        raise ProjectError(f"{label} is over the 4 GiB local-job limit")
    return str(path)


def _validate_style(style: dict, label: str) -> None:
    allowed = {"color", "background", "x", "y", "w", "h", "fontSize", "fontFamily", "fontWeight", "radius", "align", "fit"}
    if set(style) - allowed:
        raise ProjectError(f"{label}.style has unknown fields: {sorted(set(style)-allowed)}")
    for key in ("x", "y", "w", "h"):
        if key in style:
            _number(style[key], f"{label}.style.{key}", 0.001 if key in {"w", "h"} else 0, 1)
    if "fontSize" in style:
        _number(style["fontSize"], f"{label}.style.fontSize", 8, 500)
    if "fontWeight" in style:
        weight = _number(style["fontWeight"], f"{label}.style.fontWeight", 100, 900)
        if int(weight) != weight:
            raise ProjectError(f"{label}.style.fontWeight must be an integer")
    if "radius" in style:
        _number(style["radius"], f"{label}.style.radius", 0, 200)
    if "fontFamily" in style and len(_string(style["fontFamily"], f"{label}.style.fontFamily")) > 100:
        raise ProjectError(f"{label}.style.fontFamily is too long")
    for key in ("color", "background"):
        if key in style and not re.fullmatch(r"#[0-9a-fA-F]{6}", _string(style[key], key)):
            raise ProjectError(f"{label}.style.{key} must be a six-digit hex color")
    if "align" in style and style["align"] not in {"left", "center", "right"}:
        raise ProjectError(f"{label}.style.align is invalid")
    if "fit" in style and style["fit"] not in {"cover", "contain"}:
        raise ProjectError(f"{label}.style.fit is invalid")
    if style.get("x", 0) + style.get("w", 0) > 1.000001 or style.get("y", 0) + style.get("h", 0) > 1.000001:
        raise ProjectError(f"{label}.style must fit within normalized frame")


def validate(spec: dict, base_dir: Path | None = None) -> dict:
    spec = _object(spec, "spec")
    workflow = _string(spec.get("workflow"), "workflow")
    if workflow not in {"reel", "broll"}:
        raise ProjectError("workflow must be reel or broll")
    name = _string(spec.get("name"), "name")
    if len(name) > 160:
        raise ProjectError("name is too long")
    background = _string(spec.get("background", "#111111"), "background")
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", background):
        raise ProjectError("background must be a six-digit hex color")
    inp = _object(spec.get("input", {}), "input")
    clean_input: dict[str, Any] = {}
    if inp.get("product") is not None:
        clean_input["product"] = _string(inp["product"], "input.product")
    if inp.get("url"):
        u = urlparse(_string(inp["url"], "input.url"))
        if u.scheme != "https" or not u.hostname or u.username or u.password:
            raise ProjectError("input.url must be an https URL without credentials")
        clean_input["url"] = u.geturl()
    if workflow == "broll":
        clean_input["source_video"] = _source(inp.get("source_video"), "input.source_video", base_dir)
        if inp.get("captions"):
            cap = _source(inp["captions"], "input.captions", base_dir)
            if Path(cap).suffix.lower() not in {".srt", ".vtt"}:
                raise ProjectError("input.captions must be SRT or VTT")
            clean_input["captions"] = cap
    timeline = _object(spec.get("timeline"), "timeline")
    dur = _number(timeline.get("duration"), "timeline.duration", 0.25, 600)
    raw_fps = timeline.get("fps", 30)
    if workflow == "broll":
        media = _probe(Path(clean_input["source_video"]))
        visual = next((stream for stream in media.get("streams", []) if stream.get("codec_type") == "video"), None)
        if not visual:
            raise ProjectError("source_video has no video stream")
        if "fps" not in timeline:
            raw_fps = visual.get("avg_frame_rate", "30")
        if dur > float(media.get("format", {}).get("duration", 0)) + .1:
            raise ProjectError("timeline extends beyond source_video duration")
        if clean_input.get("captions"):
            caption_path = Path(clean_input["captions"])
            if caption_path.stat().st_size > 2_000_000:
                raise ProjectError("caption file exceeds 2 MB")
            from studio.timing import parse_captions
            cues = parse_captions(caption_path)
            if cues[-1]["end"] > dur + .1:
                raise ProjectError("caption timing extends beyond the project duration")
    try:
        fps = _number(float(Fraction(raw_fps)) if isinstance(raw_fps, str) else raw_fps, "timeline.fps", 1, 120)
    except (ValueError, ZeroDivisionError):
        raise ProjectError("timeline.fps must be a rate such as 30 or 30000/1001")
    scenes = timeline.get("scenes")
    if not isinstance(scenes, list) or not scenes or len(scenes) > 128:
        raise ProjectError("timeline.scenes must contain 1 to 128 scenes")
    clean_scenes = []
    ids = set()
    for i, scene in enumerate(scenes):
        scene = _object(scene, f"scene {i}")
        sid = _string(scene.get("id"), f"scene {i}.id")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", sid) or sid in ids:
            raise ProjectError(f"scene {i}.id must be a unique safe identifier")
        ids.add(sid)
        start = _number(scene.get("start"), f"scene {sid}.start", 0, dur)
        end = _number(scene.get("end"), f"scene {sid}.end", 0, dur)
        if end <= start:
            raise ProjectError(f"scene {sid}.end must be after start")
        kind = _string(scene.get("type"), f"scene {sid}.type")
        if kind not in SCENE_TYPES:
            raise ProjectError(f"scene {sid}.type must be title, panel or image")
        c = {"id": sid, "start": start, "end": end, "type": kind}
        if kind == "image":
            c["image"] = _source(scene.get("image"), f"scene {sid}.image", base_dir)
            if Path(c["image"]).suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"} or Path(c["image"]).stat().st_size > 20 * 1024 * 1024:
                raise ProjectError(f"scene {sid}.image must be PNG/JPEG/WebP at most 20 MiB")
        else:
            c["text"] = _string(scene.get("text"), f"scene {sid}.text")
            if len(c["text"]) > 600:
                raise ProjectError(f"scene {sid}.text exceeds 600 characters")
        style = _object(scene.get("style", {}), f"scene {sid}.style")
        defaults = {"x": .08, "y": .08 if kind == "image" else .22, "w": .84, "h": .84 if kind == "image" else .56}
        _validate_style({**defaults, **style}, f"scene {sid}")
        c["style"] = dict(style)
        if "styleByFormat" in scene:
            variants = _object(scene["styleByFormat"], f"scene {sid}.styleByFormat")
            if any(fmt not in FORMATS for fmt in variants):
                raise ProjectError(f"scene {sid}.styleByFormat has an unknown format")
            c["styleByFormat"] = {}
            for fmt, override in variants.items():
                merged = {**style, **_object(override, f"scene {sid}.styleByFormat.{fmt}")}
                _validate_style({**defaults, **merged}, f"scene {sid}.{fmt}")
                c["styleByFormat"][fmt] = dict(override)
        clean_scenes.append(c)
    formats = spec.get("formats", ["16x9"])
    if not isinstance(formats, list) or not formats or len(formats) != len(set(map(str, formats))):
        raise ProjectError("formats must be a nonempty list of unique formats")
    if any(fmt not in FORMATS for fmt in formats):
        raise ProjectError(f"formats must be drawn from {', '.join(FORMATS)}")
    audio = _object(spec.get("audio", {}), "audio")
    if set(audio) - {"mode", "file", "voice_file", "bpm", "sfx"}:
        raise ProjectError("audio contains an unknown field")
    mode = audio.get("mode", "none")
    if mode not in {"none", "synth", "file"}:
        raise ProjectError("audio.mode must be none, synth or file")
    clean_audio = {"mode": mode}
    if mode == "file":
        clean_audio["file"] = _source(audio.get("file"), "audio.file", base_dir)
    elif audio.get("file"):
        raise ProjectError("audio.file requires audio.mode=file")
    if audio.get("voice_file"):
        clean_audio["voice_file"] = _source(audio["voice_file"], "audio.voice_file", base_dir)
    if audio.get("bpm") is not None:
        clean_audio["bpm"] = _number(audio["bpm"], "audio.bpm", 40, 240)
    effects = audio.get("sfx", [])
    if not isinstance(effects, list) or len(effects) > 200:
        raise ProjectError("audio.sfx must be a list of at most 200 cues")
    clean_audio["sfx"] = []
    for i, cue in enumerate(effects):
        cue = _object(cue, f"audio.sfx[{i}]")
        if set(cue) - {"time", "kind"} or cue.get("kind") not in {"click", "impact"}:
            raise ProjectError(f"audio.sfx[{i}] has invalid keys or kind")
        clean_audio["sfx"].append({"time": _number(cue.get("time"), f"audio.sfx[{i}].time", 0, dur),
                                   "kind": cue["kind"]})
    return {"schema_version": 1, "workflow": workflow, "name": name,
            "input": clean_input, "timeline": {"duration": dur, "fps": fps,
                                                "scenes": clean_scenes},
            "formats": formats, "background": background, "audio": clean_audio}


def _plan_fields(project: dict) -> dict:
    fields = {k: project[k] for k in ("schema_version", "workflow", "name", "input", "timeline", "formats", "background", "audio")}
    if "asset_hashes" in project:
        fields["asset_hashes"] = project["asset_hashes"]
    return fields


def plan_digest(project: dict) -> str:
    raw = json.dumps(_plan_fields(project), sort_keys=True, ensure_ascii=False,
                     separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _project_path(directory: Path | str) -> Path:
    p = Path(directory).expanduser().resolve()
    return p if p.name == "project.json" else p / "project.json"


def _atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".writing-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as out:
            json.dump(value, out, indent=2, ensure_ascii=False)
            out.write("\n")
            out.flush()
            os.fsync(out.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def _load(directory: Path | str) -> tuple[Path, dict]:
    path = _project_path(directory)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ProjectError(f"cannot read project at {path}: {exc}") from exc
    if not isinstance(data, dict) or data.get("schema_version") != 1:
        raise ProjectError("unsupported project schema")
    return path, data


def _alive(pid: int | None) -> bool:
    if not isinstance(pid, int) or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


@contextlib.contextmanager
def _locked(path: Path):
    lock = path.with_suffix(".lock")
    for _ in range(100):
        try:
            fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(fd, "w") as out:
                out.write(f"{os.getpid()}\n")
            break
        except FileExistsError:
            try:
                pid = int(lock.read_text().strip())
                if not _alive(pid) and time.time() - lock.stat().st_mtime > 1:
                    lock.unlink(missing_ok=True)
                    continue
            except (OSError, ValueError):
                pass
            time.sleep(0.05)
    else:
        raise ProjectError("project state is busy; retry shortly")
    try:
        yield
    finally:
        lock.unlink(missing_ok=True)


def create(spec: dict, directory: Path | str, base_dir: Path | None = None) -> dict:
    fields = validate(spec, base_dir)
    path = _project_path(directory)
    if path.exists() or (path.parent.exists() and any(path.parent.iterdir())):
        raise ProjectError("project directory already has files; choose an empty directory")
    path.parent.mkdir(parents=True, exist_ok=True)
    provenance = []
    def import_asset(source_name: str, kind: str, limit: int) -> str:
        source = Path(source_name)
        if source.stat().st_size > limit:
            raise ProjectError(f"{kind} exceeds the asset size limit")
        digest = hashlib.sha256()
        with source.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        target = Path("assets") / f"{kind}-{digest.hexdigest()[:12]}{source.suffix.lower()}"
        (path.parent / "assets").mkdir(exist_ok=True)
        shutil.copyfile(source, path.parent / target)
        provenance.append({"kind": kind, "source": str(source),
                           "asset": target.as_posix(), "sha256": digest.hexdigest()})
        return target.as_posix()
    for key in ("file", "voice_file"):
        if key in fields["audio"]:
            fields["audio"][key] = import_asset(fields["audio"][key], key, 512 * 1024 * 1024)
    if fields["workflow"] == "broll":
        for key in ("source_video", "captions"):
            if key in fields["input"]:
                fields["input"][key] = import_asset(fields["input"][key], key, 4 * 1024 ** 3)
    for scene in fields["timeline"]["scenes"]:
        if scene["type"] == "image":
            scene["image"] = import_asset(scene["image"], "image", 20 * 1024 * 1024)
    if provenance:
        _atomic_json(path.parent / "provenance.json", {"assets": provenance})
    data = {**fields, "asset_hashes": {item["asset"]: item["sha256"] for item in provenance}, "approval": {"approved": False, "plan_sha256": None,
                                    "approved_at": None},
            "state": {"status": "planned", "attempt": 0, "pid": None,
                      "updated_at": _now(), "error": None}, "artifacts": []}
    _atomic_json(path, data)
    return {"project": str(path), "plan_sha256": plan_digest(data), "status": "planned"}


def plan(directory: Path | str) -> dict:
    path, data = _load(directory)
    validate(_plan_fields(data), path.parent)
    digest = plan_digest(data)
    return {"project": str(path), "workflow": data["workflow"],
            "name": data["name"], "duration": data["timeline"]["duration"],
            "formats": data["formats"], "scenes": len(data["timeline"]["scenes"]),
            "approval_required": not (data.get("approval", {}).get("approved")
                                      and data["approval"].get("plan_sha256") == digest),
            "plan_sha256": digest}


def approve(directory: Path | str, digest: str) -> dict:
    path, _ = _load(directory)
    with _locked(path):
        path, data = _load(path)
        current = plan(path)["plan_sha256"]
        if digest != current:
            raise ApprovalRequired("plan digest changed; inspect the current plan before approving")
        if data["state"]["status"] in {"queued", "running"}:
            raise ProjectError("cannot approve a running job")
        data["approval"] = {"approved": True, "plan_sha256": current,
                            "approved_at": _now()}
        _atomic_json(path, data)
    return {"approved": True, "plan_sha256": current, "project": str(path)}


def _assert_approved(data: dict, base_dir: Path) -> None:
    validate(_plan_fields(data), base_dir)
    for name, expected in data.get("asset_hashes", {}).items():
        asset = (base_dir / name).resolve(strict=True)
        if not asset.is_relative_to(base_dir.resolve()):
            raise ApprovalRequired("asset escaped project directory")
        digest = hashlib.sha256()
        with asset.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        if digest.hexdigest() != expected:
            raise ApprovalRequired("an approved asset changed; create and review a new project")
    if not data.get("approval", {}).get("approved") or data["approval"].get("plan_sha256") != plan_digest(data):
        raise ApprovalRequired("current scene plan needs approval; run plan, then approve with its SHA-256")


def status(directory: Path | str) -> dict:
    path, data = _load(directory)
    state = data["state"]
    worker = WORKERS.get(str(path))
    if worker and state["status"] in {"completed", "failed", "cancelled"}:
        try:
            worker.wait(timeout=2)
            WORKERS.pop(str(path), None)
        except subprocess.TimeoutExpired:
            pass
    stale = state["status"] in {"queued", "running"} and not _alive(state.get("pid"))
    return {"project": str(path), "state": state, "approval": data["approval"],
            "plan_sha256": plan_digest(data), "artifacts": data.get("artifacts", []),
            "stale_worker": stale}


def doctor() -> dict:
    """Report actual host capabilities without installing or changing anything."""
    commands = {}
    for name, flag in (("node", "--version"), ("ffmpeg", "-version"),
                       ("ffprobe", "-version")):
        exe = shutil.which(name)
        if not exe:
            commands[name] = {"available": False}
            continue
        try:
            result = subprocess.run([exe, flag], capture_output=True, text=True,
                                    timeout=10)
            commands[name] = {"available": result.returncode == 0,
                              "version": result.stdout.splitlines()[0] if result.stdout else "unknown"}
            if name == "node" and result.returncode == 0:
                commands[name]["available"] = int(result.stdout.lstrip("v").split(".")[0]) >= 22
        except (OSError, subprocess.TimeoutExpired):
            commands[name] = {"available": False}
    encoders = filters = ""
    if commands["ffmpeg"]["available"]:
        for flag, field in (("-encoders", "encoders"), ("-filters", "filters")):
            try:
                result = subprocess.run(["ffmpeg", "-hide_banner", flag],
                                        capture_output=True, text=True, timeout=10)
                if field == "encoders":
                    encoders = result.stdout
                else:
                    filters = result.stdout
            except (OSError, subprocess.TimeoutExpired):
                pass
    capabilities = {"h264": "libx264" in encoders,
                    "alpha_overlay": "prores_ks" in encoders and " overlay " in filters,
                    "captions": " subtitles " in filters,
                    "renderer": RENDERER.is_file()}
    browser = binary = False
    if commands["node"]["available"]:
        try:
            result = subprocess.run(["node", "-e", "require.resolve('playwright')"],
                                    cwd=ROOT, capture_output=True, text=True, timeout=10)
            browser = result.returncode == 0
            if browser:
                result = subprocess.run(["node", "-e", "const p=require('playwright').chromium.executablePath();process.exit(require('fs').existsSync(p)?0:1)"],
                                        cwd=ROOT, capture_output=True, text=True, timeout=10)
                binary = result.returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            pass
    capabilities["playwright_package"] = browser
    capabilities["chromium_binary"] = binary
    commands["python"] = {"available": sys.version_info >= (3, 10), "version": sys.version.split()[0]}
    return {"ready": all(commands[k]["available"] for k in commands)
            and capabilities["h264"] and capabilities["renderer"],
            "commands": commands, "capabilities": capabilities,
            "note": "Playwright improves motion fidelity; the renderer may use an explicitly reported native fallback."}


def _transition(path: Path, **changes) -> dict:
    with _locked(path):
        _, data = _load(path)
        data["state"].update(changes)
        data["state"]["updated_at"] = _now()
        _atomic_json(path, data)
        return data


def _command(args: list[str], log: Path) -> None:
    global CURRENT_CHILD
    with log.open("ab") as out:
        out.write(("$ " + " ".join(args[:4]) + " …\n").encode())
        out.flush()
        CURRENT_CHILD = subprocess.Popen(args, stdout=out, stderr=subprocess.STDOUT,
                                         start_new_session=True)
        try:
            while CURRENT_CHILD.poll() is None:
                if CURRENT_PROJECT and _load(CURRENT_PROJECT)[1]["state"]["status"] == "cancelled":
                    _signal_handler(signal.SIGTERM, None)
                time.sleep(0.1)
            code = CURRENT_CHILD.returncode
        finally:
            CURRENT_CHILD = None
    if code:
        raise ProjectError(f"process exited {code}; see {log}")


def _signal_handler(_signum, _frame):
    if CURRENT_CHILD and CURRENT_CHILD.poll() is None:
        if hasattr(os, "killpg"):
            os.killpg(CURRENT_CHILD.pid, signal.SIGTERM)
        else:
            CURRENT_CHILD.terminate()
    raise JobCancelled("job cancelled")


def _render_spec(data: dict, fmt: str, attempt: Path, project_dir: Path) -> dict:
    scenes = []
    for scene in data["timeline"]["scenes"]:
        item = dict(scene)
        if scene["type"] == "image":
            source = (project_dir / scene["image"]).resolve(strict=True)
            if not source.is_relative_to(project_dir.resolve()):
                raise ProjectError("image escaped project asset directory")
            target = attempt / "media" / source.name
            target.parent.mkdir(exist_ok=True)
            if not target.exists():
                shutil.copyfile(source, target)
            item["image"] = (Path("media") / source.name).as_posix()
        scenes.append(item)
    return {"version": 1, "duration": data["timeline"]["duration"],
            "fps": data["timeline"]["fps"], "background": data["background"],
            "scenes": scenes}


def _probe(path: Path) -> dict:
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                        "format=duration:stream=codec_name,codec_type,pix_fmt,width,height,avg_frame_rate", "-of", "json", str(path)],
                       capture_output=True, text=True, timeout=30)
    if r.returncode:
        raise ProjectError(f"ffprobe failed for {path}: {r.stderr[-300:]}")
    return json.loads(r.stdout)


def _verify_video(path: Path, expected: float) -> dict:
    if not path.is_file() or path.stat().st_size < 1000:
        raise ProjectError(f"empty or missing video: {path}")
    info = _probe(path)
    duration = float(info.get("format", {}).get("duration", 0))
    if abs(duration - expected) > max(0.3, expected * 0.02):
        raise ProjectError(f"video duration mismatch: {duration:.3f}s, expected {expected:.3f}s")
    if not any(s.get("codec_name") for s in info.get("streams", [])):
        raise ProjectError(f"video lacks a readable stream: {path}")
    digest = hashlib.sha256()
    with path.open("rb") as media:
        for chunk in iter(lambda: media.read(1024 * 1024), b""):
            digest.update(chunk)
    return {"duration": duration, "bytes": path.stat().st_size,
            "sha256": digest.hexdigest()}


def _verify_alpha(path: Path, expected: float, sample_time: float) -> None:
    """Refuse incomplete MOV files and opaque graphics tracks."""
    _verify_video(path, expected)
    info = _probe(path)
    visual = next((s for s in info.get("streams", []) if s.get("codec_type") == "video"), {})
    if visual.get("codec_name") != "prores" or not str(visual.get("pix_fmt", "")).startswith("yuva"):
        raise ProjectError("graphics track must be ProRes with an alpha pixel format")
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-ss", str(sample_time),
                        "-i", str(path), "-vf", "alphaextract,scale=160:90",
                        "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "gray", "-"],
                       capture_output=True, timeout=30)
    if r.returncode or not r.stdout or min(r.stdout) >= 250 or max(r.stdout) <= 5:
        raise ProjectError("graphics alpha check failed: expected visible content and transparency")


def _escape_filter_path(path: Path) -> str:
    # ffmpeg filtergraph path quoting, passed as one argv value (never through a shell).
    return str(path).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'").replace(",", "\\,").replace("[", "\\[").replace("]", "\\]")


def _broll(data: dict, fmt: str, out: Path, attempt: Path, log: Path) -> list[dict]:
    """Compose the supplied video and timed text/caption cues with ffmpeg."""
    project_dir = attempt.parents[1]
    source = (project_dir / data["input"]["source_video"]).resolve()
    if not source.exists():
        raise ProjectError(f"source video disappeared: {source}")
    w, h = FORMATS[fmt]
    vf = [f"scale={w}:{h}:force_original_aspect_ratio=increase",
          f"crop={w}:{h}", "setsar=1"]
    # Subtitle formats are delegated to libass; source path is escaped for the
    # filtergraph and encoded as an ordinary argument, never interpolated into shell.
    if data["input"].get("captions"):
        captions = (project_dir / data["input"]["captions"]).resolve()
        if not captions.is_relative_to(project_dir.resolve()):
            raise ProjectError("captions escaped project asset directory")
        vf.append(f"subtitles='{_escape_filter_path(captions)}'")
    # A per-format silent renderer pass draws planned graphics, then overlays it
    # onto the actual source. The shared scene timings are the single source.
    overlays = [s for s in data["timeline"]["scenes"] if s["type"] in SCENE_TYPES]
    extras: list[dict] = []
    if overlays:
        render_spec = attempt / f"render-{fmt}.json"
        _atomic_json(render_spec, _render_spec(data, fmt, attempt, attempt.parents[1]))
        graphics = attempt / f"graphics-{fmt}.mov"
        _command(["node", str(RENDERER), "--project", str(render_spec),
                  "--format", fmt, "--output", str(graphics), "--alpha"], log)
        _verify_alpha(graphics, data["timeline"]["duration"],
                      (overlays[0]["start"] + overlays[0]["end"]) / 2)
        extras.append({"kind": "alpha_track", "format": fmt, "path": str(graphics)})
        filtergraph = f"[0:v]{','.join(vf)}[base];[base][1:v]overlay=0:0:format=auto:shortest=1[v]"
        _command(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                  "-i", str(source), "-i", str(graphics), "-filter_complex", filtergraph,
                  "-map", "[v]", "-map", "0:a?", "-t", str(data["timeline"]["duration"]),
                  "-r", str(data["timeline"]["fps"]), "-c:v", "libx264", "-crf", "18",
                  "-pix_fmt", "yuv420p", "-c:a", "aac", "-movflags", "+faststart", str(out)], log)
        captions = []
        if data["input"].get("captions"):
            from studio.timing import parse_captions
            captions = parse_captions((project_dir / data["input"]["captions"]).resolve())
        placement = {"schema_version": 1, "format": fmt,
                     "source_video": data["input"]["source_video"],
                     "alpha_track": graphics.name, "scenes": []}
        for scene in overlays:
            cue_ids = [i + 1 for i, cue in enumerate(captions)
                       if cue["start"] < scene["end"] and cue["end"] > scene["start"]]
            # The track is complete, with each scene isolated by its in/out
            # times. Per-scene alpha exports make placement in an editor easy.
            clip = attempt / f"overlay-{fmt}-{scene['id']}.mov"
            _command(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                      "-ss", str(scene["start"]), "-i", str(graphics),
                      "-t", str(scene["end"] - scene["start"]),
                      "-an", "-c:v", "prores_ks", "-profile:v", "4",
                      "-pix_fmt", "yuva444p10le", str(clip)], log)
            extras.append({"kind": "alpha_scene", "format": fmt, "scene_id": scene["id"],
                           "path": str(clip), "in": scene["start"], "out": scene["end"]})
            placement["scenes"].append({"id": scene["id"], "in": scene["start"],
                                        "out": scene["end"], "clip": clip.name,
                                        "caption_cue_ids": cue_ids})
        placement_file = attempt / f"placement-{fmt}.json"
        _atomic_json(placement_file, placement)
        extras.append({"kind": "placement", "format": fmt, "path": str(placement_file)})
    else:
        _command(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(source),
                  "-vf", ",".join(vf), "-t", str(data["timeline"]["duration"]),
                  "-r", str(data["timeline"]["fps"]), "-c:v", "libx264", "-crf", "18",
                  "-pix_fmt", "yuv420p", "-c:a", "aac", "-movflags", "+faststart", str(out)], log)
    return extras


def _execute(directory: Path | str) -> dict:
    global CURRENT_PROJECT
    path, data = _load(directory)
    CURRENT_PROJECT = path
    _assert_approved(data, path.parent)
    signal.signal(signal.SIGTERM, _signal_handler)
    signal.signal(signal.SIGINT, _signal_handler)
    attempt = path.parent / "artifacts" / f"attempt-{data['state']['attempt']:03d}"
    attempt.mkdir(parents=True, exist_ok=False)
    log = attempt / "run.log"
    outputs = []
    try:
        if _load(path)[1]["state"]["status"] == "cancelled":
            raise JobCancelled("job cancelled before execution")
        _transition(path, status="running", pid=os.getpid())
        if not RENDERER.is_file():
            raise ProjectError(f"renderer is unavailable: {RENDERER}")
        # Audio is built once per attempt. Each final MP4 gets the same mix.
        from studio.audio import build_audio
        audio_spec = {**data, "_project_dir": str(path.parent)}
        mix = build_audio(audio_spec, attempt)
        extras = []
        for fmt in data["formats"]:
            _, latest = _load(path)
            if latest["state"]["status"] == "cancelled":
                raise JobCancelled("job cancelled")
            dest = attempt / f"{fmt}.mp4"
            if data["workflow"] == "broll":
                extras.extend(_broll(data, fmt, dest, attempt, log))
            else:
                render_spec = attempt / f"render-{fmt}.json"
                _atomic_json(render_spec, _render_spec(data, fmt, attempt, path.parent))
                _command(["node", str(RENDERER), "--project", str(render_spec),
                          "--format", fmt, "--output", str(dest)], log)
            if mix is not None:
                muxed = attempt / f"{fmt}.mux.mp4"
                _command(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                          "-i", str(dest), "-i", str(mix), "-map", "0:v:0",
                          "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac",
                          "-b:a", "256k", "-t", str(data["timeline"]["duration"]),
                          "-movflags", "+faststart", str(muxed)], log)
                os.replace(muxed, dest)
            metrics = _verify_video(dest, data["timeline"]["duration"])
            if data["workflow"] == "broll" and data["audio"]["mode"] == "none":
                source = (path.parent / data["input"]["source_video"]).resolve()
                source_audio = any(s.get("codec_type") == "audio" for s in _probe(source).get("streams", []))
                output_audio = any(s.get("codec_type") == "audio" for s in _probe(dest).get("streams", []))
                if source_audio and not output_audio:
                    raise ProjectError("B-roll source audio was lost during composition")
            outputs.append({"kind": "video", "format": fmt, "path": str(dest), **metrics})
        from studio.review import review_artifacts
        review = review_artifacts(data, outputs, attempt)
        if not review["checks_passed"]:
            raise ProjectError("encoded output failed review checks; see review/report.json")
        manifest = {"schema_version": 1, "plan_sha256": plan_digest(data),
                    "attempt": data["state"]["attempt"], "created_at": _now(),
                    "artifacts": outputs + extras, "review": review}
        _atomic_json(attempt / "manifest.json", manifest)
        with _locked(path):
            _, latest = _load(path)
            if latest["state"]["status"] == "cancelled":
                raise JobCancelled("job cancelled")
            latest["artifacts"] = outputs + extras + [{"kind": "manifest", "path": str(attempt / "manifest.json")},
                                                     {"kind": "review", "path": str(attempt / "review" / "index.html")}]
            latest["state"].update(status="completed", pid=None, error=None, updated_at=_now())
            _atomic_json(path, latest)
        return status(path)
    except JobCancelled:
        _transition(path, status="cancelled", pid=None, error="cancelled")
        raise
    except Exception as exc:
        _transition(path, status="failed", pid=None, error=str(exc))
        raise


def run(directory: Path | str, detach: bool = False) -> dict:
    path, _ = _load(directory)
    with _locked(path):
        _, data = _load(path)
        _assert_approved(data, path.parent)
        state = data["state"]
        if state["status"] in {"queued", "running", "cancelled"} and _alive(state.get("pid")):
            raise ProjectError("job is already running")
        if state["status"] == "completed":
            raise ProjectError("job already completed; create a new project for a new render")
        state.update(status="queued", attempt=state["attempt"] + 1, pid=None,
                     error=None, updated_at=_now())
        _atomic_json(path, data)
    if detach:
        log = path.parent / "worker.log"
        with log.open("ab") as out:
            worker = subprocess.Popen([sys.executable, str(ROOT / "scripts" / "studio.py"),
                                       "_worker", "--project", str(path)],
                                      stdin=subprocess.DEVNULL, stdout=out, stderr=subprocess.STDOUT,
                                      start_new_session=True)
        WORKERS[str(path)] = worker
        _transition(path, pid=worker.pid)
        return status(path)
    return _execute(path)


def retry(directory: Path | str, detach: bool = False) -> dict:
    _, data = _load(directory)
    if data["state"]["status"] not in {"failed", "cancelled"} and not status(directory)["stale_worker"]:
        raise ProjectError("retry requires a failed, cancelled, or stale job")
    return run(directory, detach=detach)


def cancel(directory: Path | str) -> dict:
    path, _ = _load(directory)
    with _locked(path):
        _, data = _load(path)
        state = data["state"]
        if state["status"] not in {"queued", "running"}:
            raise ProjectError("only queued or running jobs can be cancelled")
        pid = state.get("pid")
        state.update(status="cancelled", updated_at=_now(), error="cancelled")
        _atomic_json(path, data)
    # The owned worker observes the cancellation state and terminates its own
    # child. Do not signal a persisted PID: OS reuse could target another app.
    return status(path)

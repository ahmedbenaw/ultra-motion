"""Transcript cues and an inspectable music timing estimate.

The beat estimator measures energy rises in decoded audio. It reports a
confidence value; a user-supplied BPM is preferred when the estimate is weak.
"""

from __future__ import annotations

from array import array
from pathlib import Path
import math
import re
import subprocess


STAMP = re.compile(r"(?:(\d+):)?(\d{2}):(\d{2})[,.](\d{1,3})")


def _seconds(value: str) -> float:
    match = STAMP.fullmatch(value.strip())
    if not match:
        raise ValueError(f"Invalid timestamp: {value}")
    hours, minutes, seconds, fraction = match.groups()
    if int(minutes) >= 60 or int(seconds) >= 60:
        raise ValueError("Timestamp minutes and seconds must be below 60")
    return int(hours or 0) * 3600 + int(minutes) * 60 + int(seconds) + int(fraction.ljust(3, "0")) / 1000


def parse_captions(path: Path) -> list[dict]:
    data = path.read_text(encoding="utf-8-sig").replace("\r\n", "\n")
    if data.lstrip().startswith("WEBVTT"):
        data = data.split("\n", 1)[1]
    cues = []
    for block in re.split(r"\n\s*\n", data.strip()):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        line_index = next((i for i, line in enumerate(lines) if "-->" in line), None)
        if line_index is None:
            continue
        left, right = lines[line_index].split("-->", 1)
        start = _seconds(left)
        end = _seconds(right.strip().split()[0])
        text = " ".join(lines[line_index + 1:]).strip()
        if not (0 <= start < end) or not text:
            raise ValueError("Caption cue needs positive duration and text")
        if cues and start < cues[-1]["start"]:
            raise ValueError("Caption cues are out of order")
        cues.append({"start": start, "end": end, "text": text})
    if not cues:
        raise ValueError("No caption cues found")
    return cues


def beat_grid(duration: float, bpm: float, offset: float = 0.0) -> list[float]:
    if not (0 < duration <= 3600 and 40 <= bpm <= 240 and 0 <= offset < duration):
        raise ValueError("Invalid duration, BPM, or offset")
    step = 60 / bpm
    return [round(offset + i * step, 4) for i in range(math.ceil((duration - offset) / step))
            if offset + i * step < duration]


def analyze_music(path: Path, bpm_hint: float | None = None, max_seconds: int = 180) -> dict:
    if not path.is_file() or path.stat().st_size > 500_000_000:
        raise ValueError("Music file missing or exceeds 500 MB")
    if bpm_hint is not None and not 40 <= bpm_hint <= 240:
        raise ValueError("BPM hint must be 40 to 240")
    proc = subprocess.run(
        ["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(path), "-t", str(max_seconds),
         "-ac", "1", "-ar", "8000", "-f", "s16le", "-"],
        check=True, capture_output=True, timeout=max(30, max_seconds * 2),
    )
    pcm = array("h")
    pcm.frombytes(proc.stdout[:len(proc.stdout) - len(proc.stdout) % 2])
    hop = 80  # 10 ms at 8 kHz
    energy = [sum(abs(v) for v in pcm[i:i + hop]) / (32768 * hop)
              for i in range(0, len(pcm) - hop + 1, hop)]
    duration = len(pcm) / 8000
    if len(energy) < 100 or max(energy, default=0) < .001:
        if bpm_hint is None:
            raise ValueError("Audio is silent or too short to measure a beat; supply BPM")
        return {"bpm": bpm_hint, "beats": beat_grid(duration, bpm_hint), "confidence": 0,
                "method": "supplied-bpm; insufficient audio onset data"}
    novelty = [max(0.0, energy[i] - energy[i - 1]) for i in range(1, len(energy))]
    mean = sum(novelty) / len(novelty)
    onset = [max(0.0, value - mean * 1.25) for value in novelty]
    norm = sum(value * value for value in onset)
    if norm < 1e-9:
        if bpm_hint is None:
            raise ValueError("No clear onset pattern; supply BPM")
        return {"bpm": bpm_hint, "beats": beat_grid(duration, bpm_hint), "confidence": 0,
                "method": "supplied-bpm; no clear onsets"}
    candidates = []
    for bpm in range(60, 201):
        lag = round(6000 / bpm)
        correlation = sum(onset[i] * onset[i - lag] for i in range(lag, len(onset))) / norm
        candidates.append((correlation, bpm, lag))
    confidence, estimated, lag = max(candidates)
    bpm = float(bpm_hint if bpm_hint is not None else estimated)
    if confidence < .04 and bpm_hint is None:
        raise ValueError("Beat estimate is too weak; supply BPM")
    period = round(6000 / bpm)
    phase = max(range(period), key=lambda offset: sum(onset[i] for i in range(offset, len(onset), period)))
    offset = (phase + 1) / 100
    return {"bpm": round(bpm, 2), "beats": beat_grid(duration, bpm, offset),
            "confidence": round(min(1.0, confidence), 3),
            "method": "energy-onset autocorrelation" + (" with supplied BPM" if bpm_hint else "")}

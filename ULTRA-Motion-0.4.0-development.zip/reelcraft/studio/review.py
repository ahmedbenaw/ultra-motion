"""Objective video checks and safe, local review pages.

Creative scores belong to a human or a critic with visual access. This module
checks encoded facts and prepares evidence; it never invents aesthetic scores.
"""

from __future__ import annotations

from fractions import Fraction
import html
import json
import re
from pathlib import Path
import subprocess


SIZES = {"16x9": (1920, 1080), "1x1": (1080, 1080), "4x5": (1080, 1350), "9x16": (1080, 1920)}


def _probe(video: Path) -> dict:
    run = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(video)],
        check=True, capture_output=True, text=True, timeout=30,
    )
    return json.loads(run.stdout)


def review_artifacts(project: dict, artifacts: list[dict], attempt_dir: Path) -> dict:
    duration = float(project["timeline"]["duration"])
    fps = Fraction(str(project["timeline"].get("fps", 30)))
    folder = attempt_dir / "review"
    folder.mkdir(parents=True, exist_ok=True)
    entries = []
    issues = []
    for artifact in artifacts:
        video = Path(artifact["path"]).resolve()
        fmt = artifact.get("format")
        if not video.is_file():
            issues.append({"format": fmt, "code": "missing-file", "message": "Render is missing"})
            continue
        info = _probe(video)
        streams = info.get("streams", [])
        visual = next((stream for stream in streams if stream.get("codec_type") == "video"), None)
        if visual is None:
            issues.append({"format": fmt, "code": "no-video", "message": "No video stream"})
            continue
        actual_duration = float(info.get("format", {}).get("duration", 0))
        dimensions = [visual.get("width"), visual.get("height")]
        actual_fps = Fraction(visual.get("avg_frame_rate", "0/1"))
        target = SIZES.get(fmt)
        if target and dimensions != list(target):
            issues.append({"format": fmt, "code": "dimensions", "expected": target, "actual": dimensions})
        if abs(actual_duration - duration) > max(.12, 2 / float(fps)):
            issues.append({"format": fmt, "code": "duration", "expected": duration, "actual": actual_duration})
        if abs(float(actual_fps) - float(fps)) > .05:
            issues.append({"format": fmt, "code": "fps", "expected": str(fps), "actual": str(actual_fps)})
        sheet = folder / f"{fmt or 'output'}-sheet.jpg"
        tile_rate = max(.25, 8 / max(.1, actual_duration))
        subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(video),
             "-vf", f"fps={tile_rate},scale=320:-1,tile=4x2:nb_frames=8:padding=8:margin=8:color=0x18202c",
             "-frames:v", "1", str(sheet)],
            capture_output=True, text=True, timeout=120, check=True,
        )
        phone = folder / f"{fmt or 'output'}-phone.jpg"
        guide = ",drawbox=x=iw*0.06:y=ih*0.08:w=iw*0.88:h=ih*0.72:color=0x67d8dd@0.8:t=2" if fmt == "9x16" else ""
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
                        "-ss", str(actual_duration / 2), "-i", str(video),
                        "-vf", "scale=360:-2" + guide, "-frames:v", "1", str(phone)],
                       capture_output=True, text=True, timeout=60, check=True)
        has_audio = any(stream.get("codec_type") == "audio" for stream in streams)
        loudness = None
        if has_audio:
            measured = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(video),
                "-af", "loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"],
                capture_output=True, text=True, timeout=120, check=True)
            match = re.search(r'\{\s*"input_i".*?\}', measured.stderr, re.S)
            if match:
                values = json.loads(match.group())
                loudness = {"integrated_lufs": values["input_i"], "true_peak_dbtp": values["input_tp"]}
        entries.append({"format": fmt, "path": str(video), "contact_sheet": str(sheet),
                        "phone_view": str(phone), "loudness": loudness,
                        "duration": actual_duration, "fps": str(actual_fps),
                        "dimensions": dimensions,
                        "audio": has_audio})
    report = {"checks_passed": not issues, "issues": issues, "outputs": entries,
              "creative_review": "pending human review"}
    (folder / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    cards = []
    for entry in entries:
        label = html.escape(str(entry["format"]))
        image = html.escape(Path(entry["contact_sheet"]).name, quote=True)
        phone = html.escape(Path(entry["phone_view"]).name, quote=True)
        video = html.escape(Path(entry["path"]).relative_to(attempt_dir.resolve()).as_posix(), quote=True)
        cards.append(f'<section><h2>{label}</h2><a href="../{video}">Open video</a>'
                     f'<img src="{image}" alt="Contact sheet for {label}">'
                     f'<img style="max-width:360px" src="{phone}" alt="Phone view for {label}"></section>')
    page = ('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" '
            'content="width=device-width,initial-scale=1"><title>Reelcraft review</title>'
            '<style>body{font:16px system-ui;color:#f7f7fa;background:#121821;max-width:1100px;'
            'margin:auto;padding:2rem}section{margin:2rem 0;padding:1rem;background:#202a37;border-radius:1rem}'
            'img{width:100%;height:auto}a{color:#8cd5ff}</style><h1>Render review</h1>'
            '<p>Check pacing, text legibility, visual accuracy, transitions, audio sync, and the loop seam. '
            'Vertical guides are a generic review aid, not a platform safe-area guarantee.</p>'
            + ''.join(cards) + '</html>')
    (folder / "index.html").write_text(page, encoding="utf-8")
    return report

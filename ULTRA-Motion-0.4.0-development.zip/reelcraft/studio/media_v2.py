"""A deliberately narrow, checked bridge from semantic Moments to video proofs."""
from fractions import Fraction
import json
from pathlib import Path
import re
import shutil
import subprocess

from .core import ProjectError
from .project import compile_moments

KINDS = {'mp4': '.mp4', 'mov-alpha': '.mov', 'png': '.png', 'webm': '.webm', 'gif': '.gif'}
FORMATS = {'16:9': '16x9', '9:16': '9x16', '1:1': '1x1', '4:5': '4x5'}
HEX = re.compile(r'#[0-9a-fA-F]{6}\Z')
SCENE_KEYS = {'type', 'style', 'styleByFormat', 'image'}


def media_profiles(project):
    return [output for output in project['outputs'] if output['kind'] in KINDS]


def _safe_image(root, image, destination):
    if not isinstance(image, str) or not image or Path(image).is_absolute():
        raise ProjectError('image must be a relative path inside the project')
    real_root = root.resolve()
    source = (real_root / image).resolve()
    if not source.is_relative_to(real_root) or not source.is_file():
        raise ProjectError('image is missing or escapes the project')
    if source.suffix.lower() not in {'.png', '.jpg', '.jpeg', '.webp'} or source.stat().st_size > 20*1024*1024:
        raise ProjectError('image must be PNG, JPEG or WebP, at most 20 MiB')
    target = destination / 'images' / (str(len(list((destination / 'images').glob('*'))) if (destination / 'images').exists() else 0) + source.suffix.lower())
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    return target.relative_to(destination).as_posix()


def compile_video(project, root, directory, output):
    if output['kind'] not in KINDS:
        raise ProjectError('video proof supports MP4, alpha MOV, PNG, WebM and GIF only')
    fps = Fraction(str(output['fps']))
    if fps.denominator != 1 or not 1 <= fps <= 120:
        raise ProjectError('video proof currently requires an integer frame rate from 1 to 120')
    if output['kind'] == 'gif' and int(fps) not in {1, 2, 4, 5, 10, 20, 25, 50, 100}:
        raise ProjectError('GIF timing needs an exact centisecond frame rate; choose 10, 20 or 25 fps')
    compiled = compile_moments(project, output['id'])['moments']
    if not compiled:
        raise ProjectError('a video proof needs at least one Moment with a defined duration')
    if len(compiled) > 128:
        raise ProjectError('video proof supports at most 128 Moments')
    background = project['creative']['visual'].get('background', '#101820')
    if not isinstance(background, str) or not HEX.fullmatch(background):
        raise ProjectError('video proof background must be a #RRGGBB color')
    scenes = []
    for index, moment in enumerate(compiled):
        visual = moment['visual']
        if not isinstance(visual, dict) or set(visual) - SCENE_KEYS:
            raise ProjectError('unsupported visual fields for video proof')
        if moment['audio']:
            raise ProjectError('audio is not connected to the video proof renderer')
        kind = visual.get('type', 'title')
        if kind == 'none':
            continue
        if kind not in {'title', 'panel', 'image'}:
            raise ProjectError('video proof supports title, panel, image and no-graphic Moments')
        scene = {'id': f'moment_{index}', 'type': kind, 'start': moment['start_frame']/int(fps),
                 'end': moment['end_frame']/int(fps), 'style': visual.get('style', {}),
                 'styleByFormat': visual.get('styleByFormat', {})}
        if kind == 'image':
            scene['image'] = _safe_image(root, visual.get('image'), directory)
        else:
            scene['text'] = moment['content'] or moment['title']
        scenes.append(scene)
    duration = max(moment['end_frame'] for moment in compiled)/int(fps)
    if duration > 30:
        raise ProjectError('video proof is limited to 30 seconds; split or shorten the review')
    bridge = {'version': 1, 'duration': duration, 'fps': int(fps), 'background': background, 'scenes': scenes}
    path = directory / f'bridge-{output["id"]}.json'
    path.write_text(json.dumps(bridge, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return path


def _render_blank(bridge, media, output):
    source = json.loads(bridge.read_text())
    width, height = {'16:9': (960, 540), '9:16': (540, 960), '1:1': (540, 540), '4:5': (540, 674)}[output['ratio']]
    frames = round(source['duration']*source['fps'])
    alpha = output['kind'] == 'mov-alpha'
    command = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'lavfi', '-i',
               f'color=c={"black@0.0" if alpha else source["background"]}:s={width}x{height}:r={source["fps"]},format=rgba',
               '-frames:v', str(1 if output['kind'] == 'png' else frames)]
    if alpha:
        command += ['-vf', 'format=yuva444p10le', '-c:v', 'prores_ks', '-profile:v', '4', '-pix_fmt', 'yuva444p10le']
    elif output['kind'] == 'mp4':
        command += ['-c:v', 'libx264', '-pix_fmt', 'yuv420p']
    command.append(str(media))
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=120, check=False)
        if result.returncode:
            raise ProjectError('no-graphic proof failed: '+result.stderr[-800:])
        probe = subprocess.run(['ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0',
                                '-show_entries', 'stream=width,height,pix_fmt,nb_read_frames', '-of', 'json', str(media)],
                               capture_output=True, text=True, timeout=30, check=True)
    except (OSError, subprocess.TimeoutExpired, subprocess.CalledProcessError) as exc:
        raise ProjectError(f'no-graphic proof could not be checked: {exc}') from exc
    stream = json.loads(probe.stdout)['streams'][0]
    if (stream['width'], stream['height']) != (width, height) or int(stream['nb_read_frames']) != (1 if output['kind'] == 'png' else frames):
        raise ProjectError('no-graphic proof failed frame or size verification')
    if alpha and not stream['pix_fmt'].startswith('yuva'):
        raise ProjectError('transparent proof lost alpha')
    if output['kind'] != 'png':
        sidecar = Path(str(media)+'.render.json')
        sidecar.write_text(json.dumps({'output': str(media), 'engine': 'ffmpeg', 'no_graphic': True,
                                       'source_media': 'none', 'checkedFrames': frames, 'width': width,
                                       'height': height, 'alpha': alpha, 'draft': True}, indent=2)+'\n')


def render_proofs(project, root, directory):
    profiles = media_profiles(project)
    if not profiles:
        raise ProjectError('request MP4, alpha MOV, PNG, WebM or GIF to render a video proof')
    renderer = Path(__file__).resolve().parents[1] / 'renderer' / 'render.mjs'
    products = []
    for output in profiles:
        bridge = compile_video(project, root, directory, output)
        suffix = KINDS[output['kind']]
        media = directory / f'proof-{output["id"]}{suffix}'
        transcode = output['kind'] in {'webm', 'gif'}
        rendered = directory / f'encoded-{output["id"]}.mp4' if transcode else media
        command = ['node', str(renderer), '--project', str(bridge), '--format', FORMATS[output['ratio']],
                   '--output', str(rendered), '--draft', '--engine', 'ffmpeg']
        if output['kind'] == 'mov-alpha':
            command.append('--alpha')
        if output['kind'] == 'png':
            command += ['--frame', '0']
        if not json.loads(bridge.read_text())['scenes']:
            _render_blank(bridge, rendered, {**output, 'kind': 'mp4'} if transcode else output)
        else:
            try:
                result = subprocess.run(command, cwd=directory, capture_output=True, text=True, timeout=120, check=False)
            except (OSError, subprocess.TimeoutExpired) as exc:
                raise ProjectError(f'video proof renderer unavailable: {exc}') from exc
            if result.returncode:
                raise ProjectError('video proof failed: '+result.stderr[-800:])
            manifest = json.loads(result.stdout)
            if manifest.get('engine') != 'ffmpeg' or not rendered.is_file():
                raise ProjectError('video proof has no verified media result')
        if transcode:
            _transcode(rendered, media, output)
            rendered.unlink()
            Path(str(rendered)+'.render.json').unlink()
        products.append(media)
        if output['kind'] != 'png':
            products.append(Path(str(media)+'.render.json'))
    return products


def _transcode(source, destination, output):
    args = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', str(source)]
    if output['kind'] == 'webm':
        args += ['-c:v', 'libvpx-vp9', '-crf', '35', '-b:v', '0', '-pix_fmt', 'yuv420p', '-an']
    else:
        args += ['-filter_complex_threads', '1', '-filter_complex', '[0:v]split[a][b];[a]palettegen[p];[b][p]paletteuse', '-loop', '0']
    try:
        subprocess.run(args+[str(destination)], capture_output=True, text=True, timeout=120, check=True)
        probes = []
        for path in (source, destination):
            result = subprocess.run(['ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0',
                                     '-show_entries', 'stream=width,height,codec_name,nb_read_frames:format=duration',
                                     '-of', 'json', str(path)], capture_output=True, text=True, timeout=30, check=True)
            probes.append(json.loads(result.stdout))
    except (OSError, subprocess.TimeoutExpired, subprocess.CalledProcessError) as exc:
        raise ProjectError(f'{output["kind"]} proof encoding or verification failed: {exc}') from exc
    before, after = probes[0]['streams'][0], probes[1]['streams'][0]
    if any(before[key] != after[key] for key in ('width', 'height', 'nb_read_frames')):
        raise ProjectError('transcoded proof changed dimensions or frame count')
    if abs(float(probes[0]['format']['duration'])-float(probes[1]['format']['duration'])) > .02:
        raise ProjectError('transcoded proof changed duration')
    expected = 'vp9' if output['kind'] == 'webm' else 'gif'
    if after['codec_name'] != expected:
        raise ProjectError('transcoded proof has the wrong codec')
    manifest = {'engine': 'ffmpeg', 'draft': True, 'kind': output['kind'], 'codec': expected,
                'width': after['width'], 'height': after['height'], 'checkedFrames': int(after['nb_read_frames']),
                'duration': probes[1]['format']['duration'], 'alpha': False,
                'limitation': 'Timed static draft. Source video, sound and final motion are not included.'}
    Path(str(destination)+'.render.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')

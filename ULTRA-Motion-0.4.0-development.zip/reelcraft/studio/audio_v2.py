"""Exact-sample PCM WAV assembly, with explicit rejection of clipping or conversion."""
from array import array
from fractions import Fraction
import json
from pathlib import Path
import sys
import wave

from .assets_v2 import asset_fingerprint
from .core import ProjectError
from .project import compile_moments


def _sample(value, rate):
    exact = Fraction(value)*rate
    return (exact.numerator*2+exact.denominator)//(2*exact.denominator)


def render_audio(project, root, directory):
    profiles = [o for o in project['outputs'] if o['kind'] == 'wav']
    if not profiles:
        raise ProjectError('request a WAV output before audio assembly')
    hashes = asset_fingerprint(project, root, ['moments'])
    prepared = []
    for output in profiles:
        rate = output['sample_rate']
        moments = compile_moments(project, output['id'])['moments']
        frames = max((_sample(m['end'], rate) for m in moments), default=0)
        if not 0 < frames <= rate*30 or len(moments) > 128:
            raise ProjectError('WAV assembly requires 1 to 128 Moments and at most 30 seconds')
        mix = [0.0]*(frames*2)
        cues = []
        for moment in moments:
            audio = moment['audio']
            if not audio:
                continue
            if set(audio)-{'file', 'gain'} or 'file' not in audio:
                raise ProjectError('WAV assembly accepts audio.file and optional audio.gain only')
            gain = audio.get('gain', 1)
            if type(gain) not in {int, float} or not 0 <= gain <= 1:
                raise ProjectError('audio gain must be a finite number from 0 to 1')
            try:
                with wave.open(str(Path(root)/audio['file']), 'rb') as source:
                    channels = source.getnchannels()
                    if source.getsampwidth() != 2 or channels not in {1, 2} or source.getframerate() != rate or source.getcomptype() != 'NONE':
                        raise ProjectError('WAV input must be 16-bit PCM mono/stereo at the requested sample rate; resampling is not implicit')
                    begin, end = _sample(moment['start'], rate), _sample(moment['end'], rate)
                    count = min(end-begin, source.getnframes())
                    samples = array('h', source.readframes(count))
                    if sys.byteorder != 'little':
                        samples.byteswap()
                    if len(samples) != count*channels:
                        raise ProjectError('WAV input is truncated')
            except (OSError, wave.Error, EOFError) as exc:
                raise ProjectError('WAV input cannot be decoded') from exc
            for index in range(count):
                for channel in range(2):
                    mix[(begin+index)*2+channel] += samples[index*channels+(channel if channels==2 else 0)]*gain
            cues.append({'moment': moment['id'], 'start_sample': begin, 'end_sample': begin+count, 'file': audio['file'], 'gain': gain})
        peak = max(abs(sample) for sample in mix)
        if any(sample < -32768 or sample > 32767 for sample in mix):
            raise ProjectError('audio overlaps would clip; lower explicit gains before approval')
        encoded = array('h', (round(sample) for sample in mix))
        if sys.byteorder != 'little':
            encoded.byteswap()
        prepared.append((output, frames, encoded.tobytes(), peak, cues))
    paths = []
    for output, frames, data, peak, cues in prepared:
        path = Path(directory)/(output['id']+'.wav')
        with wave.open(str(path), 'wb') as destination:
            destination.setparams((2, 2, output['sample_rate'], frames, 'NONE', 'not compressed'))
            destination.writeframes(data)
        with wave.open(str(path), 'rb') as check:
            if check.getnframes()!=frames or check.readframes(frames)!=data:
                raise ProjectError('WAV failed sample verification')
        manifest = path.with_suffix('.audio.json')
        manifest.write_text(json.dumps({'sample_rate': output['sample_rate'], 'frames': frames, 'channels': 2,
            'peak_pcm': peak, 'silent': not cues or peak == 0, 'cues': cues, 'assets': hashes,
            'scope': 'PCM assembly only; voice generation, loudness mastering and video mux are separate checks.'}, indent=2)+'\n')
        paths += [path, manifest]
    return paths

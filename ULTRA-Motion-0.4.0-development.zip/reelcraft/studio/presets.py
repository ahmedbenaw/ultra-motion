"""Use-case recipes with explicit coverage of every project control group."""
from copy import deepcopy

from .core import ProjectError

CONTROL_GROUPS = ('mission', 'sources', 'truth', 'creative', 'narrative', 'scene', 'accessibility', 'outputs', 'execution', 'privacy')
FAMILIES = {
    'client-engagement': 'Client product and strategy engagement',
    'product-launch': 'Own-product launch',
    'consulting-decision': 'Consulting recommendation',
    'company-profile': 'Company profile and proposition',
    'web-experience': 'Responsive website and landing page',
    'mobile-demo': 'Mobile and cross-platform demo',
    'data-story': 'Dashboard and data narrative',
    'terminal-walkthrough': 'Terminal and developer workflow',
    'speaker-explainer': 'Speaker-led explainer and B-roll',
    'workshop': 'Workshop, training and onboarding',
    'discovery': 'Discovery, requirements and roadmap',
    'ux-prototype': 'UX concept and interactive prototype',
    'desktop-workflow': 'Desktop and cross-platform workflow',
    'feature-release': 'Feature release and update',
    'case-study': 'Case study',
    'investor-story': 'Investor and funding story',
    'market-analysis': 'Market and opportunity analysis',
    'operating-model': 'Business and operating model',
    'kpi-readout': 'KPI readout and metric diagnosis',
    'scenario-comparison': 'Scenario and option comparison',
    'sales-pitch': 'Sales and procurement pitch',
    'website-audit': 'Website audit and redesign',
    'presentation-redesign': 'Presentation redesign',
    'research-synthesis': 'Research synthesis',
    'academic-explainer': 'Academic finding and explainer',
    'research-methods': 'Methods and reproducible figure',
    'conference-story': 'Conference and exhibition story',
    'social-cutdown': 'Social cutdown',
    'documentary': 'Documentary and data explainer',
}


def validate_preset(recipe):
    from .project import obj, identifier, text
    obj(recipe, {'id', 'label', 'origin', 'controls', 'rationale', 'work_packages'}, {'id', 'label', 'origin', 'controls'}, 'preset')
    identifier(recipe['id'])
    text(recipe['label'], 'preset.label')
    if not isinstance(recipe['origin'], str) or recipe['origin'] not in {'builtin', 'ai', 'personal'}:
        raise ProjectError('invalid preset origin')
    if not isinstance(recipe['controls'], dict) or set(recipe['controls']) != set(CONTROL_GROUPS):
        raise ProjectError('preset control coverage must include every control group')
    for name, control in recipe['controls'].items():
        obj(control, {'mode', 'value', 'reason'}, {'mode', 'value'}, f'preset.{name}')
        if not isinstance(control['mode'], str) or control['mode'] not in {'automatic', 'choice', 'fixed', 'not-applicable'}:
            raise ProjectError('unsupported preset control mode')
        if control['mode'] == 'fixed' and control['value'] is None:
            raise ProjectError('fixed preset control needs a value')
        if 'reason' in control:
            text(control['reason'], f'preset.{name}.reason')
    if 'rationale' in recipe:
        text(recipe['rationale'], 'preset.rationale')
    if 'work_packages' in recipe:
        from .jobs import validate_jobs
        validate_jobs(recipe['work_packages'])
    return recipe


def get_preset(name):
    if name not in FAMILIES:
        raise ProjectError('unknown preset')
    controls = {group: {'mode': 'automatic', 'value': None, 'reason': 'Recommend after inspecting the case; do not infer approval.'} for group in CONTROL_GROUPS}
    controls['execution'] = {'mode': 'choice', 'value': ['co-create', 'adaptive', 'autonomous']}
    controls['privacy'] = {'mode': 'choice', 'value': ['local', 'github']}
    controls['accessibility'] = {'mode': 'fixed', 'value': {'keyboard': True, 'reduced_motion': True, 'voice': 'capability-required'}}
    controls['mission'] = {'mode': 'choice', 'value': {'use_case': name, 'question': 'Who must understand or decide what?'}}
    if name in {'consulting-decision', 'investor-story', 'market-analysis', 'kpi-readout', 'academic-explainer', 'research-methods', 'data-story'}:
        controls['truth'] = {'mode': 'fixed', 'value': {'claims': 'source-linked', 'numbers': 'recompute', 'uncertainty': 'visible'}}
        controls['narrative'] = {'mode': 'automatic', 'value': ['question', 'evidence', 'options', 'recommendation']}
    elif name == 'speaker-explainer':
        controls['scene'] = {'mode': 'choice', 'value': ['cutaway', 'panel', 'no-graphic']}
        controls['sources'] = {'mode': 'fixed', 'value': {'preserve_source_audio': True, 'preserve_source_fps': True}}
    else:
        controls['narrative'] = {'mode': 'automatic', 'value': ['problem', 'interaction', 'proof', 'next-action']}
    return deepcopy(validate_preset({'id': name, 'label': FAMILIES[name], 'origin': 'builtin', 'controls': controls, 'rationale': 'Starting recipe; output feasibility and all acceptance checks remain required.'}))


def catalog():
    return [get_preset(name) for name in FAMILIES]


def compose(primary, secondary, resolutions=None):
    """Return explicit conflicts; never silently overwrite a selected control."""
    from .project import digest
    validate_preset(primary)
    validate_preset(secondary)
    resolutions = {} if resolutions is None else resolutions
    if not isinstance(resolutions, dict) or set(resolutions) - set(CONTROL_GROUPS):
        raise ProjectError('recipe resolutions must name supported control groups')
    if any(not isinstance(value, str) or value not in {'primary', 'secondary', 'automatic'} for value in resolutions.values()):
        raise ProjectError('choose primary, secondary or automatic for each conflict')
    controls, conflicts = {}, []
    for group in CONTROL_GROUPS:
        left, right = primary['controls'][group], secondary['controls'][group]
        if left == right:
            controls[group] = deepcopy(left)
        elif group not in resolutions:
            conflicts.append({'group': group, 'primary': deepcopy(left), 'secondary': deepcopy(right)})
        elif resolutions[group] == 'automatic':
            controls[group] = {'mode': 'automatic', 'value': None, 'reason': 'Owner requested a case-specific recommendation for this combined control.'}
        else:
            controls[group] = deepcopy(left if resolutions[group] == 'primary' else right)
    if conflicts:
        return {'state': 'needs-choice', 'conflicts': conflicts, 'recipe': None}
    recipe = {'id': 'combined-'+digest([primary, secondary, resolutions])[:16],
              'label': primary['label']+' + '+secondary['label'], 'origin': 'personal',
              'controls': controls, 'rationale': 'Combined by explicit control choices. Content and work packages still require review.'}
    # Work packages have separate approval semantics; do not silently compose graphs.
    return {'state': 'proposal', 'conflicts': [], 'recipe': validate_preset(recipe)}


def recommend(project):
    """Explain a deterministic recommendation; an assistant can propose alternatives."""
    evidence = len(project['truth']['claims']) + len(project['truth']['sources'])
    platforms = ' '.join(project['mission'].get('platforms', [])).lower()
    if project['mission'].get('decision') and evidence:
        family, reason = 'consulting-decision', 'The project contains a decision question and supplied evidence.'
    elif any(word in platforms for word in ('mobile', 'android', 'ios')):
        family, reason = 'mobile-demo', 'The declared target includes a mobile platform.'
    elif evidence:
        family, reason = 'data-story', 'The supplied sources or claims call for an evidence-led story.'
    else:
        family, reason = project['preset']['id'], 'No evidence or platform signal justifies replacing the current starting direction.'
    recipe = get_preset(family) if family in FAMILIES else deepcopy(project['preset'])
    recipe.update(id='case-'+project['id'][:16], origin='personal', label='For this case: '+recipe['label'], rationale=reason+' This is a rule-based proposal, not an AI-generated or approved plan.')
    recipe['controls']['mission'] = {'mode': 'choice', 'value': deepcopy(project['mission']), 'reason': 'Review the actual mission before adopting this proposal.'}
    recipe['controls']['outputs'] = {'mode': 'choice', 'value': deepcopy(project['outputs']), 'reason': 'Preserve requested outputs; feasibility checks still apply.'}
    return validate_preset(recipe)


def project_recipes(project):
    options = catalog()+project['extensions'].get('personal_presets', [])+[project['preset'], recommend(project)]
    return list({option['id']: deepcopy(option) for option in options}.values())


def work_proposal(project):
    """Prepare an executable dependency proposal without modifying or approving it."""
    from .project import CONTENT_FIELDS, validate, compile_moments
    from .jobs import validate_jobs
    from .media_v2 import KINDS
    from .exports_v2 import SUPPORTED
    validate(project)
    compile_moments(project)
    definitions = []
    def add(name, dependencies, inputs):
        definitions.append({'id': name, 'handler': name, 'depends_on': dependencies, 'inputs': sorted(inputs)})
    evidence = bool(project['truth']['claims'] or project['truth']['sources'])
    if evidence:
        add('evidence_inventory', [], {'truth'})
    if any(claim.get('calculation') for claim in project['truth']['claims']):
        add('quantitative_check', ['evidence_inventory'], {'truth'})
    analysis = [d['id'] for d in definitions]
    add('compile_moments', [], {'moments', 'anchors', 'outputs', 'truth'})
    if project['mission'].get('decision'):
        add('executive_brief', analysis, {'name', 'mission', 'truth'})
    add('preview', [d['id'] for d in definitions], CONTENT_FIELDS)
    kinds = {output['kind'] for output in project['outputs']}
    if kinds & set(KINDS):
        add('render_proof', ['compile_moments'], CONTENT_FIELDS)
    if kinds & SUPPORTED:
        add('export_outputs', ['compile_moments', *analysis], CONTENT_FIELDS)
    if 'wav' in kinds:
        add('assemble_audio', ['compile_moments'], CONTENT_FIELDS)
    validate_jobs(definitions)
    warnings = ['This is a work proposal. Defining it changes the plan; current owner approval is required before execution.',
                'Format constraints and source/creative acceptance remain required; a proposal is not a render pass.']
    if not project['moments'] and kinds & (set(KINDS)|{'wav','lottie'}):
        warnings.append('Add Moments before requesting time-based outputs.')
    if kinds & set(KINDS) and any(m.get('audio') for m in project['moments']):
        warnings.append('The draft video renderer rejects audio-bearing Moments. Video/audio integration requires a separate workflow.')
    return {'state': 'proposal', 'revision': project['revision'], 'jobs': definitions, 'warnings': warnings}

"""One project per branch, with compare-and-swap writes and fresh restore checks.

The repository may be local or a user-configured private GitHub remote. This
module never creates a public repository or pushes without an explicit command.
"""
import os
from pathlib import Path
import re
import subprocess
import tempfile

from .core import ProjectError
from .project import CONTENT_FIELDS, ProjectStore, identifier
from . import jobs

INCLUDED = ('project-v2.json', 'assets', 'artifacts-v2')
MAX_FILE = 50*1024*1024
MAX_TOTAL = 200*1024*1024
ZERO = '0'*40
GITHUB_URL = re.compile(r'(?:https://github\.com/|git@github\.com:)[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(?:\.git)?\Z')


def _git(repo, *args, work_tree=None, env=None, input=None, raw=False):
    command = ['git', f'--git-dir={repo}']
    if work_tree:
        command.append(f'--work-tree={work_tree}')
    command.extend(args)
    try:
        result = subprocess.run(command, input=input, capture_output=True, env=env, timeout=60, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ProjectError(f'Git unavailable: {exc}') from exc
    if result.returncode:
        raise ProjectError('Git operation failed: '+result.stderr.decode(errors='replace')[-800:])
    return result.stdout if raw else result.stdout.strip().decode(errors='replace')


def initialize(repo):
    repo = Path(repo).resolve()
    if repo.exists():
        raise ProjectError('repository already exists; refusing to initialize over it')
    repo.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(['git', 'init', '--bare', str(repo)], capture_output=True, text=True, timeout=30)
    if result.returncode:
        raise ProjectError('cannot initialize project repository: '+result.stderr[-400:])
    return {'repository': str(repo), 'type': 'local bare repository', 'remote_sync': 'not configured'}


def _ref(project_id):
    return 'refs/heads/project/'+identifier(project_id)


def tip(repo, project_id):
    result = subprocess.run(['git', f'--git-dir={repo}', 'rev-parse', '--verify', _ref(project_id)],
                            capture_output=True, text=True, timeout=15)
    return result.stdout.strip() if result.returncode == 0 else None


def _files(root):
    files = []
    for item in INCLUDED:
        path = root / item
        if path.is_symlink():
            raise ProjectError('project snapshot cannot contain symlinked directories')
        if path.is_file() or path.is_symlink():
            files.append(path)
        elif path.is_dir():
            files.extend(p for p in path.rglob('*') if p.is_file() or p.is_symlink())
    total = 0
    for path in files:
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
            raise ProjectError('project snapshot cannot contain symlinks or escaping files')
        size = path.stat().st_size
        if size > MAX_FILE:
            raise ProjectError('file exceeds 50 MiB; configure media storage before saving')
        total += size
    if total > MAX_TOTAL:
        raise ProjectError('project snapshot exceeds 200 MiB; configure media storage before saving')
    return sorted(path.relative_to(root).as_posix() for path in files)


def save(repo, store, expected_tip=None):
    repo = Path(repo).resolve()
    project = store.read()
    if project['policy']['storage'] != 'github':
        raise ProjectError('choose GitHub storage in project policy before branch saving')
    current = tip(repo, project['id'])
    if expected_tip is not None and expected_tip != (current or ZERO):
        raise ProjectError('project branch changed; inspect and resolve before saving')
    names = _files(store.directory)
    from .assets_v2 import asset_fingerprint
    referenced = asset_fingerprint(project, store.directory, CONTENT_FIELDS)
    if any(asset['path'] not in names for asset in referenced):
        raise ProjectError('branch snapshots require referenced inputs in assets/; move inputs there and review the updated plan')
    with tempfile.TemporaryDirectory() as folder:
        environment = os.environ.copy()
        environment.update(GIT_INDEX_FILE=str(Path(folder)/'index'), GIT_AUTHOR_NAME='ULTRA Motion Project',
                           GIT_AUTHOR_EMAIL='studio@local.invalid', GIT_COMMITTER_NAME='ULTRA Motion Project',
                           GIT_COMMITTER_EMAIL='studio@local.invalid')
        _git(repo, 'add', '--force', '--', *names, work_tree=store.directory, env=environment)
        tree = _git(repo, 'write-tree', env=environment)
        commit_args = ['commit-tree', tree, '-m', f'Project {project["id"]} revision {project["revision"]}']
        if current:
            commit_args += ['-p', current]
        commit = _git(repo, *commit_args, env=environment)
        _git(repo, 'update-ref', _ref(project['id']), commit, current or ZERO)
    return {'branch': 'project/'+project['id'], 'commit': commit, 'previous': current,
            'files': len(names), 'revision': project['revision'], 'location': 'local Git repository'}


def restore(repo, project_id, destination):
    identifier(project_id)
    repo = Path(repo).resolve()
    commit = tip(repo, project_id)
    if not commit:
        raise ProjectError('project branch does not exist')
    destination = Path(destination).resolve()
    if destination.exists():
        raise ProjectError('restore destination already exists')
    names, total = [], 0
    try:
        listing = _git(repo, 'ls-tree', '-r', '-l', '-z', commit, raw=True)
        for record in listing.split(b'\0'):
            if not record:
                continue
            header, name = record.split(b'\t', 1)
            mode, kind, checksum, size = header.split()
            if mode not in {b'100644', b'100755'} or kind != b'blob':
                raise ProjectError('branch must contain ordinary files only')
            size = int(size)
            total += size
            if size > MAX_FILE or total > MAX_TOTAL or len(names) >= 10000:
                raise ProjectError('branch exceeds supported restore limits')
            names.append(name.decode('utf-8'))
    except (UnicodeDecodeError, ValueError) as exc:
        raise ProjectError('branch filenames must be UTF-8') from exc
    if 'project-v2.json' not in names:
        raise ProjectError('branch has no project state')
    with tempfile.TemporaryDirectory(dir=destination.parent) as folder:
        root = Path(folder)
        for name in names:
            path = Path(name)
            if path.is_absolute() or '..' in path.parts or not any(name == prefix or name.startswith(prefix+'/') for prefix in INCLUDED):
                raise ProjectError('branch contains an unexpected path')
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(subprocess.run(['git', f'--git-dir={repo}', 'show', f'{commit}:{name}'],
                                              capture_output=True, check=True, timeout=30).stdout)
        store = ProjectStore(root)
        project = store.read()
        if project['id'] != project_id:
            raise ProjectError('branch project identity mismatch')
        # A changed plan legitimately makes old output stale. Verify bytes
        # independently so a saved draft can still be restored for further work.
        for job in project['jobs']:
            for artifact in job['artifacts']:
                relative = Path(artifact['path'])
                path = root / relative
                if relative.is_absolute() or '..' in relative.parts or '\\' in artifact['path'] or ':' in artifact['path'] or not artifact['path'].startswith('artifacts-v2/') or not path.is_file() or jobs.digest_file(path) != artifact['sha256']:
                    raise ProjectError('restored job artifacts do not match recorded hashes')
        root.rename(destination)
    return {'project': str(destination), 'branch': 'project/'+project_id,
            'commit': commit, 'files': len(names), 'revision': project['revision']}


def push(repo, project_id):
    repo = Path(repo).resolve()
    remote = _github_origin(repo)
    commit = tip(repo, project_id)
    if not commit:
        raise ProjectError('save this project branch locally first')
    _git(repo, 'push', 'origin', _ref(project_id)+':'+_ref(project_id))
    return {'branch': 'project/'+project_id, 'commit': commit, 'remote': remote, 'state': 'pushed'}


def _github_origin(repo):
    remote = _git(repo, 'remote', 'get-url', 'origin')
    if not GITHUB_URL.fullmatch(remote):
        raise ProjectError('origin must be the user-selected GitHub project repository')
    return remote


def configure_origin(repo, url):
    if not isinstance(url, str) or not GITHUB_URL.fullmatch(url):
        raise ProjectError('origin must be a GitHub repository URL')
    repository = Path(repo).resolve()
    existing = subprocess.run(['git', f'--git-dir={repository}', 'remote', 'get-url', 'origin'],
                              capture_output=True, text=True, timeout=15)
    if existing.returncode == 0:
        if existing.stdout.strip() != url:
            raise ProjectError('origin is already configured to a different repository')
        return {'repository': str(repository), 'origin': url, 'state': 'unchanged'}
    _git(repository, 'remote', 'add', 'origin', url)
    return {'repository': str(repository), 'origin': url, 'state': 'configured'}


def fetch(repo, project_id):
    repository = Path(repo).resolve()
    remote = _github_origin(repository)
    local_ref = _ref(project_id)
    remote_ref = 'refs/remotes/origin/project/'+identifier(project_id)
    _git(repository, 'fetch', '--no-tags', 'origin', local_ref+':'+remote_ref)
    fetched = _git(repository, 'rev-parse', '--verify', remote_ref)
    current = tip(repository, project_id)
    if current:
        _git(repository, 'merge-base', '--is-ancestor', current, fetched)
    _git(repository, 'update-ref', local_ref, fetched, current or ZERO)
    return {'branch': 'project/'+project_id, 'commit': fetched, 'origin': remote,
            'state': 'fetched' if not current else 'fast-forwarded'}

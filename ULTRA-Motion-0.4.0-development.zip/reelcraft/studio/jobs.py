"""Cooperative, recoverable work-package execution with scoped input digests."""
from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import subprocess
import uuid

from .core import ProjectError
from .project import CONTENT_FIELDS, compile_moments, digest, identifier, now, obj, plan_digest, rows, atomic_write

REQUIRED_INPUTS = {'compile_moments': {'moments', 'anchors', 'outputs', 'truth'}, 'evidence_inventory': {'truth'}, 'quantitative_check': {'truth'}, 'executive_brief': {'name', 'mission', 'truth'}, 'preview': set(CONTENT_FIELDS), 'render_proof': set(CONTENT_FIELDS), 'export_outputs': set(CONTENT_FIELDS)}
HANDLERS = set(REQUIRED_INPUTS)
REQUIRED_INPUTS['assemble_audio'] = set(CONTENT_FIELDS)
HANDLERS.add('assemble_audio')
WORKERS = {}


def input_digest(project, fields, root):
    from .assets_v2 import asset_fingerprint
    content = {key: project[key] for key in fields}
    assets = asset_fingerprint(project, root, fields)
    if assets:
        content['asset_sha256s'] = assets
    return digest(content)


def validate_jobs(jobs):
    rows(jobs, 'jobs')
    indexed = {}
    for job in jobs:
        obj(job, {'id', 'handler', 'depends_on', 'inputs'}, {'id', 'handler', 'depends_on', 'inputs'}, 'job definition')
        identifier(job['id'])
        if job['id'] in indexed:
            raise ProjectError('duplicate job identifier')
        if not isinstance(job['handler'], str) or job['handler'] not in HANDLERS:
            raise ProjectError('unsupported job handler')
        if not job['inputs'] or any(not isinstance(key, str) or key not in CONTENT_FIELDS for key in rows(job['inputs'], 'job inputs')):
            raise ProjectError('job inputs must name supported project content fields')
        if len(job['inputs']) != len(set(job['inputs'])):
            raise ProjectError('duplicate job input')
        if not REQUIRED_INPUTS[job['handler']] <= set(job['inputs']):
            raise ProjectError('job inputs omit required handler content fields')
        rows(job['depends_on'], 'job dependencies')
        for dependency in job['depends_on']:
            identifier(dependency)
        if len(job['depends_on']) != len(set(job['depends_on'])):
            raise ProjectError('duplicate job dependency')
        indexed[job['id']] = job
    seen, active = set(), set()
    def visit(key):
        if key not in indexed:
            raise ProjectError('missing job dependency')
        if key in active:
            raise ProjectError('job dependency cycle')
        if key in seen:
            return
        active.add(key)
        for parent in indexed[key]['depends_on']:
            visit(parent)
        active.remove(key)
        seen.add(key)
    for key in indexed:
        visit(key)
    return jobs


def define(store, definitions, expected_revision):
    validate_jobs(definitions)
    with store.transaction() as project:
        if type(expected_revision) is not int or expected_revision != project['revision']:
            raise ProjectError('stale project revision')
        if any(job['state'] in {'running', 'pause-requested', 'cancel-requested'} and _alive(job['owner']) for job in project['jobs']):
            raise ProjectError('cannot replace active work packages')
        project['jobs'] = [{**deepcopy(job), 'state': 'ready', 'attempt': 0, 'owner': None, 'artifacts': [], 'error': None, 'input_digest': None} for job in definitions]
        project['revision'] += 1
        project['events'].append({'id': uuid.uuid4().hex, 'action': 'define_jobs', 'revision': project['revision'], 'at': now()})
    return status(store)


def _alive(pid):
    if not pid:
        return False
    if os.name == 'nt':
        # os.kill(pid, 0) can terminate a Windows process. Query it instead.
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.GetExitCodeProcess.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return ctypes.get_last_error() == 5  # Access denied: conservatively occupied.
        try:
            code = wintypes.DWORD()
            return not kernel.GetExitCodeProcess(handle, ctypes.byref(code)) or code.value == 259
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def status(store):
    for pid, worker in list(WORKERS.items()):
        if worker.poll() is not None:
            del WORKERS[pid]
    project = store.read()
    jobs = []
    for job in project['jobs']:
        state = job['state']
        if state == 'verified':
            try:
                current_input = input_digest(project, job['inputs'], store.directory)
            except ProjectError:
                current_input = None
            if job['input_digest'] != current_input:
                state = 'stale'
            elif any(not (store.directory / a['path']).is_file() or digest_file(store.directory / a['path']) != a['sha256'] for a in job['artifacts']):
                state = 'stale'
        if state == 'running' and not _alive(job['owner']):
            state = 'interrupted'
        jobs.append({**job, 'state': state})
    changed = True
    while changed:
        changed = False
        current = {job['id']: job['state'] for job in jobs}
        for job in jobs:
            if job['state'] == 'verified' and any(current.get(parent) != 'verified' for parent in job['depends_on']):
                job['state'] = 'stale'
                changed = True
    return {'revision': project['revision'], 'jobs': jobs}


def digest_file(path):
    import hashlib
    return hashlib.sha256(path.read_bytes()).hexdigest()


def control(store, job_id, action):
    with store.transaction() as project:
        job = next((j for j in project['jobs'] if j['id'] == job_id), None)
        if job is None:
            raise ProjectError('job not found')
        if action == 'cancel':
            job['state'] = 'cancel-requested' if job['state'] == 'running' else 'cancelled'
        elif action == 'pause':
            if job['state'] not in {'running', 'ready'}:
                raise ProjectError('only ready or running jobs can pause')
            job['state'] = 'pause-requested' if job['state'] == 'running' else 'paused'
        elif action in {'resume', 'retry'}:
            if job['state'] in {'running', 'pause-requested', 'cancel-requested'} and _alive(job['owner']):
                raise ProjectError('worker is still active')
            job.update(state='ready', owner=None, error=None)
        else:
            raise ProjectError('unsupported job control')
        project['events'].append({'id': uuid.uuid4().hex, 'action': action, 'job': job_id, 'at': now(), 'revision': project['revision']})
    return status(store)


def _execute(project, handler, directory, root):
    directory.mkdir(parents=True, exist_ok=False)
    if handler == 'compile_moments':
        path = directory / 'moments.json'
        atomic_write(path, compile_moments(project))
    elif handler == 'evidence_inventory':
        path = directory / 'evidence.json'
        atomic_write(path, {'status': 'inventory-only', 'sources': project['truth']['sources'], 'claims': project['truth']['claims'], 'unresolved': [c['id'] for c in project['truth']['claims'] if c['status'] in {'assumption', 'illustrative'}], 'numerical_validation': 'not-performed'})
    elif handler == 'quantitative_check':
        from .analysis_v2 import recompute
        path = directory / 'calculations.json'
        atomic_write(path, recompute(project['truth']))
    elif handler == 'executive_brief':
        path = directory / 'brief.md'
        mission = project['mission']
        paragraphs = ['# '+project['name'], '## Decision', mission.get('decision') or 'Decision question not yet specified.', '## Objective', mission.get('objective') or 'Objective not yet specified.', '## Evidence']
        paragraphs.extend(f"- {claim['text']} [{claim['status']}; sources: {', '.join(claim['sources']) or 'none'}]" for claim in project['truth']['claims'])
        paragraphs.extend(['## Open assumptions', *[str(value) for value in project['truth']['assumptions']]])
        path.write_text('\n\n'.join(paragraphs)+'\n', encoding='utf-8')
    elif handler == 'render_proof':
        from .media_v2 import render_proofs
        return render_proofs(project, root, directory)
    elif handler == 'export_outputs':
        from .exports_v2 import export_outputs
        return export_outputs(project, root, directory)
    elif handler == 'assemble_audio':
        from .audio_v2 import render_audio
        return render_audio(project, root, directory)
    else:
        from .preview import write_preview
        path = directory / 'preview.html'
        write_preview(project, path)
    return [path]


def run(store):
    with store.transaction() as project:
        if not any(a['digest'] == plan_digest(project, store.directory) for a in project['approvals']):
            raise ProjectError('approve the exact current plan before running work packages')
    while True:
        state = status(store)
        invalid = {j['id'] for j in state['jobs'] if j['state'] in {'stale', 'interrupted'}}
        with store.transaction() as project:
            for job in project['jobs']:
                if job['id'] in invalid and not _alive(job['owner']):
                    job.update(state='ready', owner=None)
            complete = {j['id'] for j in project['jobs'] if j['state'] == 'verified'}
            job = next((j for j in project['jobs'] if j['state'] == 'ready' and set(j['depends_on']) <= complete), None)
            if job is None:
                break
            if not any(a['digest'] == plan_digest(project, store.directory) for a in project['approvals']):
                break
            job.update(state='running', owner=os.getpid(), attempt=job['attempt']+1, error=None, input_digest=input_digest(project, job['inputs'], store.directory))
            job_id, token = job['id'], job['attempt']
            snapshot = deepcopy(project)
        directory = store.directory / 'artifacts-v2' / job_id / f'attempt-{token}-{uuid.uuid4().hex[:8]}'
        try:
            paths = _execute(snapshot, job['handler'], directory, store.directory)
            from .exports_v2 import MIME_TYPES
            artifacts = [{'path': str(path.relative_to(store.directory)), 'sha256': digest_file(path),
                          'media_type': MIME_TYPES[path.suffix]}
                         for path in paths]
            with store.transaction() as project:
                current = next(j for j in project['jobs'] if j['id'] == job_id)
                if current['state'] in {'cancel-requested', 'pause-requested'}:
                    current['state'] = 'cancelled' if current['state'] == 'cancel-requested' else 'paused'
                elif current['input_digest'] != input_digest(project, current['inputs'], store.directory):
                    current.update(state='stale', error='Inputs changed during execution; result held for review.')
                else:
                    current.update(state='verified', artifacts=artifacts)
                current['owner'] = None
                project['events'].append({'id': uuid.uuid4().hex, 'action': 'job_result', 'job': job_id, 'state': current['state'], 'at': now(), 'revision': project['revision']})
            if current['state'] == 'stale':
                break
        except Exception as exc:
            with store.transaction() as project:
                current = next(j for j in project['jobs'] if j['id'] == job_id)
                current.update(state='failed', owner=None, error=str(exc))
            break
    return status(store)


def start_background(store):
    project = store.read()
    if not any(a['digest'] == plan_digest(project, store.directory) for a in project['approvals']):
        raise ProjectError('approval required before starting a background worker')
    script = Path(__file__).resolve().parents[1] / 'scripts' / 'project.py'
    with (store.directory / 'worker.log').open('ab') as log:
        worker = subprocess.Popen([sys.executable, str(script), 'run', '--project', str(store.directory)], stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
    WORKERS[worker.pid] = worker
    return {'state': 'started', 'pid': worker.pid, 'completion': 'read job status; starting is not completion'}

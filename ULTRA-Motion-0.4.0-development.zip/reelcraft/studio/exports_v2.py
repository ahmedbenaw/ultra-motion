"""Bounded, verified document exports; no claim of unrestricted design fidelity."""
from fractions import Fraction
import html
import importlib
import json
import re
from pathlib import Path

from .core import ProjectError
from .project import compile_moments, validate

MIME_TYPES = {'.html': 'text/html', '.md': 'text/markdown', '.json': 'application/json',
              '.mp4': 'video/mp4', '.mov': 'video/quicktime', '.png': 'image/png',
              '.webm': 'video/webm', '.gif': 'image/gif', '.wav': 'audio/wav',
              '.srt': 'application/x-subrip', '.vtt': 'text/vtt', '.pdf': 'application/pdf',
              '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'}
SUPPORTED = {'srt', 'vtt', 'json', 'lottie', 'pdf', 'pptx'}
SIZES = {'16:9': (960, 540), '9:16': (540, 960), '1:1': (540, 540), '4:5': (540, 675)}


def _dependency(name, package):
    try:
        return importlib.import_module(name)
    except ImportError as exc:
        raise ProjectError(f'{package} is required for this export; install requirements-exports.txt') from exc


def _ms(value):
    exact = Fraction(value)*1000
    return (exact.numerator*2+exact.denominator)//(2*exact.denominator)


def _stamp(milliseconds, separator):
    seconds, ms = divmod(milliseconds, 1000)
    minutes, sec = divmod(seconds, 60)
    hours, minute = divmod(minutes, 60)
    return f'{hours:02}:{minute:02}:{sec:02}{separator}{ms:03}'


def _cues(moments):
    cues = []
    previous = 0
    for moment in sorted(moments, key=lambda m: Fraction(m['start'])):
        content = moment['content']
        if not content.strip():
            continue
        if any(ord(c) < 32 and c != '\n' for c in content) or '\n\n' in content or '-->' in content:
            raise ProjectError('subtitle text contains unsupported cue delimiters or controls')
        begin, end = _ms(moment['start']), _ms(moment['end'])
        if begin < previous or end <= begin:
            raise ProjectError('subtitle cues overlap or collapse after millisecond rounding')
        previous = end
        cues.append((begin, end, content))
    return cues


def _brief(project, moments):
    blocks = [('Decision', project['mission'].get('decision') or 'Decision not specified.'),
              ('Objective', project['mission'].get('objective') or 'Objective not specified.')]
    blocks += [('Evidence', f"{c['text']}\nStatus: {c['status']}\nSources: {', '.join(c['sources']) or 'none'}")
               for c in project['truth']['claims']]
    blocks += [('Source', json.dumps(source, ensure_ascii=False, sort_keys=True))
               for source in project['truth']['sources']]
    blocks += [('Assumption', str(value)) for value in project['truth']['assumptions']]
    blocks += [('Scene: '+m['title'], f"{m['start']}-{m['end']} seconds\n{m['content']}\nSources: {', '.join(m['sources']) or 'none'}; claims: {', '.join(m['claims']) or 'none'}") for m in moments]
    # These are briefings, not automatically validated consulting conclusions.
    blocks.append(('Scope', 'Decision and scene briefing. Source accuracy and conclusions require review.'))
    return blocks


def _lottie(moments, output):
    width, height = SIZES[output['ratio']]
    total = max((m['end_frame'] for m in moments), default=0)
    if total <= 0:
        raise ProjectError('Lottie requires a positive duration')
    layers = []
    for index, moment in enumerate(moments):
        visual = moment['visual']
        if moment['audio'] or not isinstance(visual, dict) or set(visual)-{'type', 'style'}:
            raise ProjectError('restricted Lottie does not support audio, images or extra visual fields')
        kind = visual.get('type', 'none')
        if kind == 'none':
            if visual.get('style'):
                raise ProjectError('no-graphic Lottie Moment cannot carry styles')
            continue
        if kind != 'panel' or moment['content']:
            raise ProjectError('restricted Lottie supports empty-content solid panels and no-graphic Moments only')
        style = visual.get('style', {})
        if not isinstance(style, dict) or set(style)-{'background'}:
            raise ProjectError('restricted Lottie panel supports background color only; fonts and other styles are unsupported')
        color = style.get('background', '#101820')
        if not isinstance(color, str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', color):
            raise ProjectError('Lottie background must be #RRGGBB')
        layers.append({'ddd': 0, 'ind': index+1, 'ty': 1, 'nm': moment['id'], 'sr': 1,
                       'sw': width, 'sh': height, 'sc': color, 'ip': moment['start_frame'],
                       'op': moment['end_frame'], 'st': 0, 'bm': 0,
                       'ks': {'o': {'a': 0, 'k': 100}, 'r': {'a': 0, 'k': 0},
                              'p': {'a': 0, 'k': [width/2, height/2, 0]},
                              'a': {'a': 0, 'k': [width/2, height/2, 0]},
                              's': {'a': 0, 'k': [100, 100, 100]}}})
    return {'v': '5.7.4', 'fr': float(Fraction(output['fps'])), 'ip': 0, 'op': total,
            'w': width, 'h': height, 'nm': 'Restricted solid-panel proof', 'ddd': 0,
            'assets': [], 'layers': layers}


def _pdf(path, title, blocks):
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from pypdf import PdfReader
    styles = getSampleStyleSheet()
    flow = [Paragraph(html.escape(title), styles['Title'])]
    for heading, body in blocks:
        flow += [Paragraph(html.escape(heading), styles['Heading2']),
                 Paragraph(html.escape(body).replace('\n', '<br/>'), styles['BodyText']), Spacer(1, 12)]
    SimpleDocTemplate(str(path)).build(flow)
    reader = PdfReader(str(path))
    if not reader.pages or title not in '\n'.join(page.extract_text() for page in reader.pages):
        raise ProjectError('PDF failed content verification')


def _pptx(path, title, blocks, ratio):
    from pptx import Presentation
    from pptx.util import Inches, Pt
    presentation = Presentation()
    numerator, denominator = (int(part) for part in ratio.split(':'))
    short_axis = Inches(7.5)
    presentation.slide_width = short_axis*numerator//min(numerator, denominator)
    presentation.slide_height = short_axis*denominator//min(numerator, denominator)
    width = presentation.slide_width/Inches(1)
    height = presentation.slide_height/Inches(1)
    left, top, region_width = .5, .4, width-1
    body_top, body_height = 1.6, height-2.1
    # Conservative character budget, explicit line spacing, and zero paragraph
    # padding. Geometry is checked; installed-font visual metrics still need QA.
    wrap_width = max(1, int((region_width-.2)*72/(18*1.2)))
    capacity = max(1, int((body_height-.2)*72/24))
    heading_width = max(1, int((region_width-.2)*72/(24*1.2)))
    expected = []
    for heading, body in [('Project', title), *blocks]:
        import textwrap
        # Preserve long headings as editable body text rather than truncate them.
        if len(heading+' (continued)') > heading_width*2:
            body = heading+'\n'+body
            heading = 'Briefing'
        lines = [part for line in body.split('\n') for part in (textwrap.wrap(line, wrap_width) or [''])]
        for offset in range(0, len(lines), capacity):
            slide = presentation.slides.add_slide(presentation.slide_layouts[6])
            label = heading if offset == 0 else heading+' (continued)'
            head = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(region_width), Inches(1)).text_frame
            head.margin_left = head.margin_right = Inches(.1)
            head.margin_top = head.margin_bottom = 0
            head.text = '\n'.join(textwrap.wrap(label, heading_width))
            for paragraph in head.paragraphs:
                paragraph.font.size = Pt(24)
                paragraph.line_spacing = Pt(30)
                paragraph.space_before = paragraph.space_after = 0
            text = '\n'.join(lines[offset:offset+capacity])
            box = slide.shapes.add_textbox(Inches(left), Inches(body_top), Inches(region_width), Inches(body_height)).text_frame
            box.margin_left = box.margin_right = Inches(.1)
            box.margin_top = box.margin_bottom = Inches(.1)
            box.word_wrap = True
            box.text = text
            for paragraph in box.paragraphs:
                paragraph.font.size = Pt(18)
                paragraph.line_spacing = Pt(24)
                paragraph.space_before = paragraph.space_after = 0
            expected.append(text)
    presentation.save(str(path))
    reopened = Presentation(str(path))
    observed = [slide.shapes[1].text for slide in reopened.slides]
    if observed != expected:
        raise ProjectError('PPTX failed editable text verification')
    if reopened.slide_width != presentation.slide_width or reopened.slide_height != presentation.slide_height:
        raise ProjectError('PPTX failed slide geometry verification')
    if any(shape.left < 0 or shape.top < 0 or shape.left+shape.width > reopened.slide_width
           or shape.top+shape.height > reopened.slide_height for slide in reopened.slides for shape in slide.shapes):
        raise ProjectError('PPTX text region escapes the requested slide bounds')


def export_outputs(project, root, directory):
    """Export explicitly requested nonmedia profiles; media/HTML remain separate handlers."""
    validate(project)
    directory = Path(directory)
    if not directory.is_dir():
        raise ProjectError('export directory must already exist')
    prepared = []
    for output in project['outputs']:
        if output['kind'] not in SUPPORTED:
            continue
        moments = compile_moments(project, output['id'])['moments']
        if len(moments) > 512:
            raise ProjectError('document exports support at most 512 Moments')
        blocks = _brief(project, moments)
        if sum(len(h)+len(b) for h, b in blocks)+len(project['name']) > 250000:
            raise ProjectError('document briefing exceeds 250000 text characters')
        kind = output['kind']
        if kind in {'srt', 'vtt'}:
            data = _cues(moments)
        elif kind == 'lottie':
            data = _lottie(moments, output)
        else:
            data = None
        if kind == 'pdf':
            _dependency('reportlab', 'reportlab'); _dependency('pypdf', 'pypdf')
            # Standard PDF fonts cannot promise arbitrary Unicode glyphs.
            all_text = project['name']+'\n'+ '\n'.join(h+'\n'+b for h, b in blocks)
            if any(ord(c)>126 or (ord(c)<32 and c!='\n') for c in all_text):
                raise ProjectError('PDF standard-font export supports printable ASCII text only; use PPTX or JSON for Unicode')
        if kind == 'pptx':
            _dependency('pptx', 'python-pptx')
        prepared.append((output, moments, blocks, data))
    if not prepared:
        raise ProjectError('request SRT, VTT, JSON, restricted Lottie, PDF or PPTX')
    products = []
    for output, moments, blocks, data in prepared:
        kind = output['kind']
        path = directory / (output['id']+('.json' if kind=='lottie' else '.'+kind))
        if kind in {'srt', 'vtt'}:
            sep = ',' if kind=='srt' else '.'
            chunks = [('WEBVTT\n' if kind=='vtt' else '')]
            for number, (begin, end, content) in enumerate(data, 1):
                chunks.append(f'{number}\n{_stamp(begin, sep)} --> {_stamp(end, sep)}\n'+(html.escape(content, quote=False) if kind=='vtt' else content)+'\n')
            path.write_text('\n'.join(chunks), encoding='utf-8')
        elif kind in {'json', 'lottie'}:
            payload = data if kind=='lottie' else {'schema_version': 2, 'project': project, 'output': output, 'compiled_moments': moments}
            path.write_text(json.dumps(payload, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
            if json.loads(path.read_text(encoding='utf-8')) != payload:
                raise ProjectError('JSON failed round-trip verification')
        elif kind=='pdf':
            _pdf(path, project['name'], blocks)
        else:
            _pptx(path, project['name'], blocks, output['ratio'])
        products.append(path)
    return products

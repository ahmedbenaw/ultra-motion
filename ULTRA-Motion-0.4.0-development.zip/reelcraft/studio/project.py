"""Versioned project state, semantic timing, and atomic command transactions."""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time
import uuid

from .core import ProjectError


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def obj(value, allowed, required=(), label='object'):
    if not isinstance(value, dict):
        raise ProjectError(f'{label} must be an object')
    if set(value) - set(allowed):
        raise ProjectError(f'{label} has unknown fields: {sorted(set(value)-set(allowed))}')
    if set(required) - set(value):
        raise ProjectError(f'{label} is missing fields: {sorted(set(required)-set(value))}')
    return value


def text(value, label):
    if not isinstance(value, str) or not value.strip():
        raise ProjectError(f'{label} must be a nonempty string')
    return value


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,95}', value):
        raise ProjectError('identifier must contain only letters, numbers, dots, underscores or hyphens')
    return value


def rational(value, label, positive=False):
    try:
        if isinstance(value, bool) or not isinstance(value, (str, int, float)):
            raise ValueError()
        result = Fraction(str(value))
        if result < 0 or (positive and result == 0):
            raise ValueError()
        return result
    except (ValueError, ZeroDivisionError, OverflowError):
        raise ProjectError(f'{label} must be a finite nonnegative rational number') from None


def rows(value, label):
    if not isinstance(value, list):
        raise ProjectError(f'{label} must be a list')
    return value


def unique(items, label):
    ids = [identifier(item['id']) for item in items]
    if len(ids) != len(set(ids)):
        raise ProjectError(f'{label} has duplicate identifiers')
    return set(ids)


PROJECT_FIELDS = {'schema_version', 'id', 'name', 'revision', 'mission', 'brand', 'creative', 'narrative', 'surfaces', 'truth', 'anchors', 'moments', 'outputs', 'preset', 'policy', 'decisions', 'approvals', 'jobs', 'events', 'receipts', 'extensions'}
CONTENT_FIELDS = PROJECT_FIELDS - {'revision', 'approvals', 'jobs', 'events', 'receipts'}


def new_project(name, preset='client-engagement'):
    from .presets import get_preset
    project = {
        'schema_version': 2, 'id': uuid.uuid4().hex, 'name': text(name, 'name'), 'revision': 0,
        'mission': {'objective': '', 'audience': [], 'decision': '', 'platforms': [], 'success': []},
        'brand': {'name': '', 'assets': [], 'constraints': [], 'references': []},
        'creative': {'moodboard': [], 'visual': {}, 'motion': {}, 'sound': {}},
        'narrative': {'script': '', 'storyboard': [], 'animatic': None}, 'surfaces': [],
        'truth': {'sources': [], 'claims': [], 'assumptions': [], 'rights': []},
        'anchors': {'word': {}, 'beat': {}, 'event': {}}, 'moments': [],
        'outputs': [{'id': 'primary', 'kind': 'html', 'ratio': '16:9', 'fps': '30', 'sample_rate': 48000}],
        'preset': get_preset(preset),
        'policy': {'autonomy': 'adaptive', 'quality': 'rigorous', 'storage': 'local', 'delivery': 'hold'},
        'decisions': [], 'approvals': [], 'jobs': [], 'events': [], 'receipts': {}, 'extensions': {},
    }
    return validate(project)


def validate(project):
    obj(project, PROJECT_FIELDS, PROJECT_FIELDS, 'project')
    if type(project['schema_version']) is not int or project['schema_version'] != 2:
        raise ProjectError('unsupported project schema')
    identifier(project['id'])
    text(project['name'], 'name')
    if type(project['revision']) is not int or project['revision'] < 0:
        raise ProjectError('revision must be a nonnegative integer')
    obj(project['mission'], {'objective', 'audience', 'decision', 'platforms', 'success'}, label='mission')
    for key in ('objective', 'decision'):
        if not isinstance(project['mission'].get(key, ''), str):
            raise ProjectError(f'mission.{key} must be text')
    for key in ('audience', 'platforms', 'success'):
        for entry in rows(project['mission'].get(key, []), key):
            text(entry, key)
    obj(project['brand'], {'name', 'assets', 'constraints', 'references'}, label='brand')
    if not isinstance(project['brand'].get('name', ''), str):
        raise ProjectError('brand.name must be text')
    for field in ('assets', 'constraints', 'references'):
        rows(project['brand'].get(field, []), 'brand.'+field)
    obj(project['creative'], {'moodboard', 'visual', 'motion', 'sound'}, label='creative')
    rows(project['creative'].get('moodboard', []), 'creative.moodboard')
    for field in ('visual', 'motion', 'sound'):
        if not isinstance(project['creative'].get(field, {}), dict):
            raise ProjectError('creative.'+field+' must be an object')
    obj(project['narrative'], {'script', 'storyboard', 'animatic'}, label='narrative')
    if not isinstance(project['narrative'].get('script', ''), str):
        raise ProjectError('narrative.script must be text')
    rows(project['narrative'].get('storyboard', []), 'narrative.storyboard')
    for field in ('surfaces', 'decisions', 'approvals', 'jobs', 'events'):
        rows(project[field], field)
    for field in ('receipts', 'extensions'):
        if not isinstance(project[field], dict):
            raise ProjectError(f'{field} must be an object')
    obj(project['policy'], {'autonomy', 'quality', 'storage', 'delivery'}, label='policy')
    choices = {'autonomy': {'co-create', 'adaptive', 'autonomous'}, 'quality': {'rapid', 'rigorous'}, 'storage': {'local', 'github'}, 'delivery': {'hold', 'save-approved', 'distribute-approved'}}
    for field, allowed in choices.items():
        if not isinstance(project['policy'].get(field), str) or project['policy'].get(field) not in allowed:
            raise ProjectError(f'unsupported policy.{field}')
    obj(project['truth'], {'sources', 'claims', 'assumptions', 'rights'}, {'sources', 'claims', 'assumptions', 'rights'}, 'truth')
    sources = rows(project['truth']['sources'], 'sources')
    for source in sources:
        obj(source, {'id', 'title', 'uri', 'status', 'date', 'permission', 'sha256'}, {'id', 'title', 'uri', 'status'}, 'source')
        text(source['title'], 'source.title')
        text(source['uri'], 'source.uri')
        if not isinstance(source['status'], str) or source['status'] not in {'supplied', 'observed', 'proposed'}:
            raise ProjectError('invalid source status')
    source_ids = unique(sources, 'sources')
    claims = rows(project['truth']['claims'], 'claims')
    for claim in claims:
        obj(claim, {'id', 'text', 'status', 'sources', 'calculation', 'confidence'}, {'id', 'text', 'status', 'sources'}, 'claim')
        text(claim['text'], 'claim.text')
        if not isinstance(claim['status'], str) or claim['status'] not in {'observed', 'supplied', 'assumption', 'illustrative'}:
            raise ProjectError('invalid claim status')
        refs = rows(claim['sources'], 'claim.sources')
        if any(not isinstance(ref, str) or ref not in source_ids for ref in refs) or (claim['status'] == 'observed' and not refs):
            raise ProjectError('observed claims need valid source references')
    unique(claims, 'claims')
    if any(claim.get('calculation') is not None for claim in claims):
        from .analysis_v2 import recompute
        recompute(project['truth'])
    rows(project['truth']['assumptions'], 'assumptions')
    rows(project['truth']['rights'], 'rights')
    obj(project['anchors'], {'word', 'beat', 'event'}, {'word', 'beat', 'event'}, 'anchors')
    for kind, mapping in project['anchors'].items():
        if not isinstance(mapping, dict):
            raise ProjectError('anchor map must be an object')
        for ref, values in mapping.items():
            identifier(ref)
            for value in rows(values, 'anchor values'):
                rational(value, 'anchor')
    moments = rows(project['moments'], 'moments')
    for moment in moments:
        obj(moment, {'id', 'title', 'content', 'anchor', 'duration', 'visual', 'audio', 'sources', 'claims'}, {'id', 'title', 'content', 'anchor', 'duration'}, 'moment')
        text(moment['title'], 'moment.title')
        if not isinstance(moment['content'], str):
            raise ProjectError('moment.content must be text')
        rational(moment['duration'], 'duration', positive=True)
        for field in ('visual', 'audio'):
            if not isinstance(moment.get(field, {}), dict):
                raise ProjectError('moment.'+field+' must be an object')
        anchor = obj(moment['anchor'], {'kind', 'ref', 'index', 'offset', 'seconds'}, {'kind'}, 'anchor')
        if not isinstance(anchor['kind'], str) or anchor['kind'] not in {'seconds', 'word', 'beat', 'event', 'after'}:
            raise ProjectError('unsupported anchor kind')
        if anchor['kind'] != 'seconds':
            identifier(anchor.get('ref'))
        for field, valid in (('sources', source_ids), ('claims', {c['id'] for c in claims})):
            if any(not isinstance(ref, str) or ref not in valid for ref in rows(moment.get(field, []), field)):
                raise ProjectError(f'moment has missing {field}')
    unique(moments, 'moments')
    for output in rows(project['outputs'], 'outputs'):
        obj(output, {'id', 'kind', 'ratio', 'fps', 'sample_rate'}, {'id', 'kind', 'ratio', 'fps', 'sample_rate'}, 'output')
        if not isinstance(output['kind'], str) or output['kind'] not in {'mp4', 'mov-alpha', 'html', 'json', 'png', 'webm', 'gif', 'lottie', 'pdf', 'pptx', 'wav', 'srt', 'vtt'}:
            raise ProjectError('unknown output kind')
        if not isinstance(output['ratio'], str) or output['ratio'] not in {'16:9', '9:16', '1:1', '4:5'}:
            raise ProjectError('unsupported output ratio')
        if rational(output['fps'], 'fps', True) > 240:
            raise ProjectError('fps exceeds 240')
        if type(output['sample_rate']) is not int or not 8000 <= output['sample_rate'] <= 192000:
            raise ProjectError('invalid sample rate')
    if not project['outputs']:
        raise ProjectError('at least one output profile is required')
    unique(project['outputs'], 'outputs')
    from .presets import validate_preset
    validate_preset(project['preset'])
    saved = rows(project['extensions'].get('personal_presets', []), 'personal_presets')
    for recipe in saved:
        validate_preset(recipe)
        if recipe['origin'] != 'personal':
            raise ProjectError('saved personal recipe must have personal origin')
    unique(saved, 'personal_presets')
    from .jobs import validate_jobs
    if project['jobs']:
        for job in project['jobs']:
            obj(job, {'id', 'handler', 'depends_on', 'inputs', 'state', 'attempt', 'owner', 'artifacts', 'error', 'input_digest'},
                {'id', 'handler', 'depends_on', 'inputs', 'state', 'attempt', 'owner', 'artifacts', 'error', 'input_digest'}, 'job')
            if not isinstance(job['state'], str) or job['state'] not in {'ready', 'running', 'verified', 'failed', 'stale', 'paused', 'cancelled', 'pause-requested', 'cancel-requested', 'interrupted'}:
                raise ProjectError('invalid work state')
            if type(job['attempt']) is not int or job['attempt'] < 0 or (job['owner'] is not None and (type(job['owner']) is not int or job['owner'] <= 0)):
                raise ProjectError('invalid work attempt or owner')
            for field in ('error', 'input_digest'):
                if job[field] is not None and not isinstance(job[field], str):
                    raise ProjectError('invalid work '+field)
            for artifact in rows(job['artifacts'], 'job.artifacts'):
                obj(artifact, {'path', 'sha256', 'media_type'}, {'path', 'sha256', 'media_type'}, 'artifact')
                path = artifact['path']
                if not isinstance(path, str) or not path.startswith('artifacts-v2/') or '\\' in path or ':' in path or '..' in Path(path).parts:
                    raise ProjectError('artifact path must stay inside artifacts-v2/')
                if not isinstance(artifact['sha256'], str) or not re.fullmatch(r'[a-f0-9]{64}', artifact['sha256']):
                    raise ProjectError('invalid artifact checksum')
                text(artifact['media_type'], 'artifact.media_type')
        validate_jobs([{key: job[key] for key in ('id', 'handler', 'depends_on', 'inputs')} for job in project['jobs']])
    digest(project)
    return project


def _round(value):
    return (value.numerator * 2 + value.denominator) // (2 * value.denominator)


def compile_moments(project, output_id=None):
    validate(project)
    output = next((o for o in project['outputs'] if o['id'] == (output_id or project['outputs'][0]['id'])), None)
    if output is None:
        raise ProjectError('output profile not found')
    fps = rational(output['fps'], 'fps', True)
    moments = {m['id']: m for m in project['moments']}
    resolved, active = {}, set()
    def start(mid):
        if mid in resolved:
            return resolved[mid]
        if mid in active:
            raise ProjectError('Moment dependency cycle')
        if mid not in moments:
            raise ProjectError('missing Moment dependency')
        active.add(mid)
        anchor = moments[mid]['anchor']
        kind = anchor['kind']
        if kind == 'seconds':
            result = rational(anchor.get('seconds'), 'anchor.seconds')
        elif kind == 'after':
            ref = anchor.get('ref')
            result = start(ref) + rational(moments[ref]['duration'], 'duration', True)
        else:
            index = anchor.get('index', 0)
            if type(index) is not int or index < 0:
                raise ProjectError('anchor index must be a nonnegative integer')
            try:
                result = rational(project['anchors'][kind][anchor['ref']][index], 'anchor')
            except (KeyError, IndexError):
                raise ProjectError('missing semantic anchor') from None
        offset = anchor.get('offset', 0)
        try:
            result += Fraction(str(offset))
        except (ValueError, ZeroDivisionError):
            raise ProjectError('invalid anchor offset') from None
        if result < 0:
            raise ProjectError('Moment starts before zero')
        resolved[mid] = result
        active.remove(mid)
        return result
    result = []
    for mid, moment in moments.items():
        begin = start(mid)
        duration = rational(moment['duration'], 'duration', True)
        first, last = _round(begin*fps), _round((begin+duration)*fps)
        if last <= first:
            raise ProjectError('Moment duration is shorter than one output frame')
        result.append({'id': mid, 'title': moment['title'], 'content': moment['content'], 'start': str(begin), 'end': str(begin+duration), 'start_frame': first, 'end_frame': last, 'duration_frames': last-first, 'start_sample': _round(begin*output['sample_rate']), 'end_sample': _round((begin+duration)*output['sample_rate']), 'visual': moment.get('visual', {}), 'audio': moment.get('audio', {}), 'sources': moment.get('sources', []), 'claims': moment.get('claims', [])})
    return {'schema_version': 2, 'output': deepcopy(output), 'rounding': 'nearest-half-up; half-open frame intervals', 'moments': sorted(result, key=lambda m: (m['start_frame'], m['id']))}


def import_v1(original):
    if not isinstance(original, dict) or original.get('schema_version', 1) != 1:
        raise ProjectError('expected a v1 project')
    project = new_project(original.get('name', 'Imported project'), 'speaker-explainer' if original.get('workflow') == 'broll' else 'product-launch')
    project['extensions']['legacy_v1'] = deepcopy(original)
    timeline = original.get('timeline', {})
    project['outputs'][0]['fps'] = str(timeline.get('fps', 30))
    for scene in timeline.get('scenes', []):
        project['moments'].append({'id': scene['id'], 'title': scene.get('text', scene['id']) or scene['id'], 'content': scene.get('text', ''), 'anchor': {'kind': 'seconds', 'seconds': scene['start']}, 'duration': str(Fraction(str(scene['end']))-Fraction(str(scene['start']))), 'visual': deepcopy(scene)})
    return validate(project)


def plan_digest(project, root=None):
    content = {key: project[key] for key in sorted(CONTENT_FIELDS)}
    content['work_packages'] = [{key: job[key] for key in ('id', 'handler', 'depends_on', 'inputs')} for job in project['jobs']]
    if root is not None:
        from .assets_v2 import asset_fingerprint
        assets = asset_fingerprint(project, root, CONTENT_FIELDS)
        if assets:
            content['asset_sha256s'] = assets
    return digest(content)


def atomic_write(path, value):
    raw = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n'
    fd, name = tempfile.mkstemp(prefix='.state-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


class ProjectStore:
    def __init__(self, directory):
        self.directory = Path(directory).resolve()
        self.path = self.directory / 'project-v2.json'

    @classmethod
    def create(cls, directory, project):
        validate(project)
        compile_moments(project)
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=False)
        store = cls(directory)
        atomic_write(store.path, project)
        return store

    def read(self):
        return validate(json.loads(self.path.read_text(encoding='utf-8')))

    @contextmanager
    def transaction(self):
        lock = self.directory / '.project-lock'
        for _ in range(100):
            try:
                lock.mkdir()
                break
            except FileExistsError:
                time.sleep(.01)
        else:
            raise ProjectError('project is locked; inspect active writer before removing a stale lock')
        try:
            project = self.read()
            yield project
            validate(project)
            atomic_write(self.path, project)
        finally:
            lock.rmdir()

    def plan(self):
        project = self.read()
        value = plan_digest(project, self.directory)
        return {'id': project['id'], 'name': project['name'], 'revision': project['revision'], 'digest': value, 'approved': any(a['digest'] == value for a in project['approvals']), 'mission': project['mission'], 'truth': project['truth'], 'preset': project['preset'], 'moments': compile_moments(project), 'outputs': project['outputs'], 'decisions': project['decisions'], 'work_packages': [{key: job[key] for key in ('id', 'handler', 'depends_on', 'inputs')} for job in project['jobs']]}

    def apply(self, command):
        obj(command, {'id', 'expected_revision', 'action', 'payload'}, {'id', 'expected_revision', 'action', 'payload'}, 'command')
        cid = identifier(command['id'])
        fingerprint = digest(command)
        with self.transaction() as project:
            receipt = project['receipts'].get(cid)
            if receipt:
                if receipt['fingerprint'] != fingerprint:
                    raise ProjectError('command identifier reused with different content')
                return receipt['result']
            if type(command['expected_revision']) is not int or command['expected_revision'] != project['revision']:
                raise ProjectError('stale project revision; refresh before applying')
            action, payload = command['action'], command['payload']
            text(action, 'command.action')
            if action == 'approve':
                obj(payload, {'digest', 'actor'}, {'digest', 'actor'}, 'approval')
                text(payload['actor'], 'approval.actor')
                if payload['digest'] != plan_digest(project, self.directory):
                    raise ProjectError('approval does not match the current reviewed plan')
                project['approvals'].append({'digest': payload['digest'], 'actor': payload['actor'], 'at': now(), 'revision': project['revision']})
            elif action in {'set_mission', 'set_policy', 'set_brand', 'set_creative', 'set_narrative'}:
                field = action.removeprefix('set_')
                obj(payload, project[field].keys(), label=field)
                project[field].update(deepcopy(payload))
            elif action in {'replace_moments', 'replace_truth', 'replace_outputs', 'replace_anchors', 'replace_surfaces', 'choose_preset'}:
                field = {'choose_preset': 'preset'}.get(action, action.removeprefix('replace_'))
                project[field] = deepcopy(payload)
            elif action == 'record_decision':
                obj(payload, {'id', 'question', 'choice', 'actor'}, {'id', 'question', 'choice', 'actor'}, 'decision')
                for field in payload:
                    text(payload[field], field)
                project['decisions'].append({**payload, 'at': now()})
            elif action == 'save_preset':
                from .presets import validate_preset
                recipe = deepcopy(validate_preset(payload))
                recipe['origin'] = 'personal'
                saved = project['extensions'].setdefault('personal_presets', [])
                if any(item['id'] == recipe['id'] for item in saved):
                    raise ProjectError('personal recipe identifier already exists; use a new version identifier')
                saved.append(recipe)
            else:
                raise ProjectError('unsupported command action')
            validate(project)
            compile_moments(project)
            project['revision'] += 1
            result = {'status': 'applied', 'revision': project['revision'], 'digest': plan_digest(project, self.directory)}
            project['events'].append({'id': cid, 'action': action, 'revision': project['revision'], 'at': now(), 'payload_digest': digest(payload)})
            project['receipts'][cid] = {'fingerprint': fingerprint, 'result': result}
            return result

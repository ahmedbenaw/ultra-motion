"""Recompute explicitly supplied simple calculations with source provenance."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from .core import ProjectError
from .project import identifier, obj, rows, text

OPERATIONS = {'sum': 1, 'difference': 2, 'ratio': 2, 'percent_change': 2}


def _value(value):
    if isinstance(value, bool) or not isinstance(value, (int, float, str)):
        raise ProjectError('calculation value must be a finite decimal')
    try:
        result = Decimal(str(value))
    except InvalidOperation:
        raise ProjectError('calculation value must be a finite decimal') from None
    if not result.is_finite():
        raise ProjectError('calculation value must be finite')
    return result


def recompute(truth):
    sources = {source['id'] for source in truth['sources']}
    calculations = []
    for claim in truth['claims']:
        calc = claim.get('calculation')
        if calc is None:
            continue
        obj(calc, {'operation', 'inputs', 'precision'}, {'operation', 'inputs'}, 'calculation')
        operation = calc['operation']
        if not isinstance(operation, str) or operation not in OPERATIONS:
            raise ProjectError('unsupported calculation operation')
        inputs = rows(calc['inputs'], 'calculation.inputs')
        if len(inputs) < OPERATIONS[operation] or (operation != 'sum' and len(inputs) != 2):
            raise ProjectError('calculation has incorrect input count')
        precision = calc.get('precision', 2)
        if type(precision) is not int or not 0 <= precision <= 8:
            raise ProjectError('calculation precision must be 0–8')
        operands, units, refs = [], [], set()
        for item in inputs:
            obj(item, {'label', 'value', 'unit', 'source'}, {'label', 'value', 'unit', 'source'}, 'calculation input')
            text(item['label'], 'calculation input label')
            text(item['unit'], 'calculation input unit')
            identifier(item['source'])
            if item['source'] not in sources or item['source'] not in claim['sources']:
                raise ProjectError('calculation input source must exist and support its claim')
            operands.append(_value(item['value']))
            units.append(item['unit'])
            refs.add(item['source'])
        if operation in {'sum', 'difference', 'percent_change'} and len(set(units)) != 1:
            raise ProjectError('calculation inputs have incompatible units')
        if operation == 'sum':
            raw, unit = sum(operands, Decimal(0)), units[0]
        elif operation == 'difference':
            raw, unit = operands[0]-operands[1], units[0]
        elif operation == 'ratio':
            if operands[1] == 0:
                raise ProjectError('calculation divides by zero')
            raw, unit = operands[0]/operands[1], units[0]+'/'+units[1]
        else:
            if operands[0] == 0:
                raise ProjectError('percent change baseline is zero')
            raw, unit = (operands[1]-operands[0])/operands[0]*100, '%'
        rounded = raw.quantize(Decimal(1).scaleb(-precision), rounding=ROUND_HALF_UP)
        calculations.append({'claim': claim['id'], 'operation': operation, 'result': str(rounded),
                             'unit': unit, 'sources': sorted(refs), 'precision': precision,
                             'inputs': inputs, 'status': 'recomputed from supplied inputs; source values not independently verified'})
    return {'calculations': calculations, 'status': 'recomputed' if calculations else 'no-calculations',
            'interpretation': 'Results are arithmetic only. Source values and conclusions require separate review.'}

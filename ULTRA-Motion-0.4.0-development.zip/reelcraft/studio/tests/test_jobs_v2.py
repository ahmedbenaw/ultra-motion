import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
import shutil

from studio import jobs
from studio.project import CONTENT_FIELDS, ProjectStore, new_project, ProjectError


def definitions():
    return [
        {'id': 'evidence', 'handler': 'evidence_inventory', 'depends_on': [], 'inputs': ['truth']},
        {'id': 'brief', 'handler': 'executive_brief', 'depends_on': ['evidence'], 'inputs': ['name', 'mission', 'truth']},
        {'id': 'preview', 'handler': 'preview', 'depends_on': ['brief'], 'inputs': sorted(CONTENT_FIELDS)},
    ]


def approve(store):
    plan = store.plan()
    return store.apply({'id': 'approve-'+str(plan['revision']), 'expected_revision': plan['revision'], 'action': 'approve', 'payload': {'digest': plan['digest'], 'actor': 'Owner'}})


class WorkTests(unittest.TestCase):
    def test_pending_control_cannot_replace_a_live_workers_graph(self):
        import os
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'project', new_project('Worker boundary'))
            jobs.define(store, definitions(), 0)
            for state in ('pause-requested', 'cancel-requested'):
                with store.transaction() as project:
                    project['jobs'][0].update(state=state, owner=os.getpid())
                with self.assertRaisesRegex(ProjectError, 'active'):
                    jobs.define(store, definitions(), store.read()['revision'])

    def test_no_graphic_proof_rejects_unrendered_audio(self):
        from studio.media_v2 import compile_video
        with tempfile.TemporaryDirectory() as folder:
            project = new_project('Audio boundary')
            project['moments'] = [{'id': 'quiet', 'title': 'Hold', 'content': '',
                                   'anchor': {'kind': 'seconds', 'seconds': 0}, 'duration': 1,
                                   'visual': {'type': 'none'}, 'audio': {'kind': 'music'}}]
            project['outputs'] = [{'id': 'video', 'kind': 'mp4', 'ratio': '16:9', 'fps': '10', 'sample_rate': 48000}]
            with self.assertRaisesRegex(ProjectError, 'audio is not connected'):
                compile_video(project, Path(folder), Path(folder), project['outputs'][0])

    @unittest.skipUnless(shutil.which('node') and shutil.which('ffmpeg') and shutil.which('ffprobe'), 'media tools unavailable')
    def test_approved_moments_produce_real_media_proof_and_detect_tampering(self):
        with tempfile.TemporaryDirectory() as folder:
            project = new_project('Video proof')
            project['moments'] = [{'id': 'message', 'title': 'Message', 'content': 'A visible point',
                                   'anchor': {'kind': 'seconds', 'seconds': 0}, 'duration': 1,
                                   'visual': {'type': 'panel', 'style': {'x': .1, 'y': .2, 'w': .8, 'h': .5}}}]
            project['outputs'] = [{'id': 'video', 'kind': 'mp4', 'ratio': '16:9', 'fps': '10', 'sample_rate': 48000},
                                  {'id': 'still', 'kind': 'png', 'ratio': '1:1', 'fps': '10', 'sample_rate': 48000}]
            store = ProjectStore.create(Path(folder)/'project', project)
            jobs.define(store, [{'id': 'proof', 'handler': 'render_proof', 'depends_on': [], 'inputs': sorted(CONTENT_FIELDS)}], 0)
            with self.assertRaisesRegex(ProjectError, 'approve'):
                jobs.run(store)
            approve(store)
            result = jobs.run(store)['jobs'][0]
            self.assertEqual(result['state'], 'verified', result['error'])
            self.assertEqual({Path(a['path']).suffix for a in result['artifacts']}, {'.mp4', '.png', '.json'})
            video = store.directory / next(a['path'] for a in result['artifacts'] if a['path'].endswith('.mp4'))
            probe = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height,nb_frames', '-of', 'json', str(video)], capture_output=True, text=True, check=True)
            self.assertEqual(json.loads(probe.stdout)['streams'][0]['nb_frames'], '10')
            self.assertEqual(json.loads(probe.stdout)['streams'][0]['width'], 960)
            video.write_bytes(b'changed')
            self.assertEqual(jobs.status(store)['jobs'][0]['state'], 'stale')

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'media tools unavailable')
    def test_no_graphic_moment_produces_blank_video_with_real_alpha(self):
        with tempfile.TemporaryDirectory() as folder:
            project = new_project('No graphic overlay')
            project['moments'] = [{'id': 'quiet', 'title': 'Hold', 'content': '',
                                   'anchor': {'kind': 'seconds', 'seconds': 0}, 'duration': 1,
                                   'visual': {'type': 'none'}}]
            project['outputs'] = [{'id': 'alpha', 'kind': 'mov-alpha', 'ratio': '1:1', 'fps': '10', 'sample_rate': 48000}]
            store = ProjectStore.create(Path(folder)/'project', project)
            jobs.define(store, [{'id': 'proof', 'handler': 'render_proof', 'depends_on': [], 'inputs': sorted(CONTENT_FIELDS)}], 0)
            approve(store)
            result = jobs.run(store)['jobs'][0]
            self.assertEqual(result['state'], 'verified', result['error'])
            video = store.directory / next(a['path'] for a in result['artifacts'] if a['path'].endswith('.mov'))
            probe = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=pix_fmt', '-of', 'json', str(video)], capture_output=True, text=True, check=True)
            self.assertTrue(json.loads(probe.stdout)['streams'][0]['pix_fmt'].startswith('yuva'))

    def test_malformed_work_definitions_leave_project_unchanged(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'project', new_project('Boundary'))
            for field, value in [('handler', []), ('inputs', [{}]), ('depends_on', [{}]), ('inputs', ['truth', 'truth'])]:
                definition = {'id': 'evidence', 'handler': 'evidence_inventory', 'depends_on': [], 'inputs': ['truth']}
                definition[field] = value
                with self.assertRaises(ProjectError):
                    jobs.define(store, [definition], 0)
                self.assertEqual(store.read()['revision'], 0)
                self.assertEqual(store.read()['jobs'], [])
            with self.assertRaises(ProjectError):
                jobs.define(store, definitions(), False)

    def test_real_chain_and_scope_invalidation(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'project', new_project('Decision'))
            jobs.define(store, definitions(), 0)
            with self.assertRaisesRegex(ProjectError, 'approve'):
                jobs.run(store)
            approve(store)
            result = jobs.run(store)
            self.assertEqual([j['state'] for j in result['jobs']], ['verified']*3)
            brief = store.directory / result['jobs'][1]['artifacts'][0]['path']
            self.assertIn('Decision question not yet specified.', brief.read_text())
            store.apply({'id': 'change', 'expected_revision': store.read()['revision'], 'action': 'set_mission', 'payload': {'objective': 'New objective'}})
            self.assertEqual([j['state'] for j in jobs.status(store)['jobs']], ['verified', 'stale', 'stale'])
            approve(store)
            jobs.run(store)
            self.assertEqual([j['attempt'] for j in jobs.status(store)['jobs']], [1, 2, 2])
            self.assertIn('New objective', (store.directory / jobs.status(store)['jobs'][1]['artifacts'][0]['path']).read_text())

    def test_new_work_packages_require_fresh_approval(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'project', new_project('Scope'))
            approve(store)
            jobs.define(store, definitions(), 1)
            self.assertFalse(store.plan()['approved'])
            with self.assertRaisesRegex(ProjectError, 'approve'):
                jobs.run(store)

    def test_artifact_tampering_invalidates_dependent_outputs(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'project', new_project('Proof'))
            jobs.define(store, definitions(), 0)
            approve(store)
            jobs.run(store)
            state = jobs.status(store)
            (store.directory / state['jobs'][0]['artifacts'][0]['path']).write_text('{}')
            self.assertEqual([j['state'] for j in jobs.status(store)['jobs']], ['stale']*3)

    def test_job_boundaries_and_cooperative_controls(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'project', new_project('Pause'))
            jobs.define(store, definitions(), 0)
            jobs.control(store, 'evidence', 'pause')
            approve(store)
            self.assertEqual(jobs.run(store)['jobs'][0]['state'], 'paused')
            jobs.control(store, 'evidence', 'resume')
            self.assertTrue(all(j['state'] == 'verified' for j in jobs.run(store)['jobs']))
        with self.assertRaisesRegex(ProjectError, 'required'):
            jobs.validate_jobs([{'id': 'bad', 'handler': 'executive_brief', 'inputs': ['mission'], 'depends_on': []}])
        with self.assertRaisesRegex(ProjectError, 'cycle'):
            jobs.validate_jobs([{'id': 'a', 'handler': 'evidence_inventory', 'inputs': ['truth'], 'depends_on': ['a']}])

    def test_real_background_worker_reaches_verified_state(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'project', new_project('Background'))
            jobs.define(store, definitions(), 0)
            approve(store)
            result = jobs.start_background(store)
            self.assertEqual(result['state'], 'started')
            deadline = time.monotonic()+10
            while time.monotonic() < deadline:
                state = jobs.status(store)
                if all(j['state'] == 'verified' for j in state['jobs']):
                    break
                time.sleep(.05)
            self.assertEqual([j['state'] for j in state['jobs']], ['verified']*3)

    def test_portable_preview_does_not_embed_executable_user_text(self):
        from studio.preview import write_preview
        with tempfile.TemporaryDirectory() as folder:
            project = new_project('</script><script>alert(1)</script>')
            path = Path(folder)/'preview.html'
            write_preview(project, path)
            self.assertNotIn('</script><script>alert(1)</script>', path.read_text())
            self.assertIn('Commands are proposals', path.read_text())

    def test_two_process_writers_cannot_overwrite_a_revision(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'project', new_project('Concurrent'))
            processes = []
            script = Path(__file__).resolve().parents[2]/'scripts/project.py'
            for index in range(2):
                path = Path(folder)/f'command-{index}.json'
                path.write_text(json.dumps({'id': f'edit-{index}', 'expected_revision': 0, 'action': 'set_mission', 'payload': {'objective': f'Writer {index}'}}))
                processes.append(subprocess.Popen([sys.executable, str(script), 'apply', '--project', str(store.directory), '--file', str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True))
            results = [p.communicate(timeout=10) for p in processes]
            self.assertEqual(sorted(p.returncode for p in processes), [0, 1])
            self.assertEqual(store.read()['revision'], 1)
            self.assertTrue(any('stale project revision' in err for _, err in results))


if __name__ == '__main__':
    unittest.main()

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class MCPIntegrationTests(unittest.TestCase):
    def test_plan_approval_and_work_run_through_real_protocol(self):
        with tempfile.TemporaryDirectory() as folder:
            script=Path(__file__).resolve().parents[2]/'scripts/mcp_server.py'
            server=subprocess.Popen([sys.executable,str(script)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env={**os.environ,'REELCRAFT_WORKSPACE':folder})
            index=0
            def call(name,arguments):
                nonlocal index
                index+=1
                server.stdin.write(json.dumps({'jsonrpc':'2.0','id':index,'method':'tools/call','params':{'name':name,'arguments':arguments}})+'\n')
                server.stdin.flush()
                response=json.loads(server.stdout.readline())
                self.assertEqual(response['id'],index)
                return response['result']
            try:
                result=call('engagement_create',{'project':'decision','name':'Decision fixture','preset':'consulting-decision'})
                self.assertFalse(result['isError'])
                recommendation=call('recipe_recommend',{'project':'decision'})
                self.assertFalse(recommendation['isError'])
                self.assertEqual(recommendation['structuredContent']['state'],'proposal')
                self.assertEqual(call('engagement_plan',{'project':'decision'})['structuredContent']['revision'],0)
                jobs=[{'id':'inventory','handler':'evidence_inventory','depends_on':[],'inputs':['truth']}]
                self.assertFalse(call('work_define',{'project':'decision','jobs':jobs,'revision':0})['isError'])
                self.assertTrue(call('work_start',{'project':'decision','wait':True})['isError'])
                plan=call('engagement_plan',{'project':'decision'})['structuredContent']
                command={'id':'owner-approval','expected_revision':plan['revision'],'action':'approve','payload':{'actor':'Synthetic test owner','digest':plan['digest']}}
                self.assertFalse(call('engagement_command',{'project':'decision','command':command})['isError'])
                work=call('work_start',{'project':'decision','wait':True})['structuredContent']
                self.assertEqual(work['jobs'][0]['state'],'verified')
                artifact=Path(folder)/'decision'/work['jobs'][0]['artifacts'][0]['path']
                self.assertEqual(json.loads(artifact.read_text())['numerical_validation'],'not-performed')
                revision=call('engagement_plan',{'project':'decision'})['structuredContent']['revision']
                self.assertFalse(call('engagement_command',{'project':'decision','command':{
                    'id':'select-storage','expected_revision':revision,'action':'set_policy',
                    'payload':{'storage':'github'}}})['isError'])
                self.assertFalse(call('branch_repository_init',{'repository':'private.git'})['isError'])
                snapshot=call('branch_save',{'project':'decision','repository':'private.git'})['structuredContent']
                self.assertEqual(snapshot['files'],2)
                recovered=call('branch_restore',{'repository':'private.git','project_id':plan['id'],
                                                  'destination':'restored'})['structuredContent']
                self.assertEqual(recovered['commit'],snapshot['commit'])
                self.assertTrue(call('branch_push',{'repository':'private.git','project_id':plan['id']})['isError'])
                self.assertTrue(call('engagement_plan',{'project':'../outside'})['isError'])
                self.assertTrue(call('work_start',{'project':'decision','wait':'false'})['isError'])
            finally:
                server.stdin.close()
                server.wait(timeout=5)
                server.stdout.close()
                server.stderr.close()


if __name__=='__main__':
    unittest.main()

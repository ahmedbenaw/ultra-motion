from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

from studio.presets import compose, get_preset, recommend, work_proposal
from studio.project import ProjectError, ProjectStore, new_project


class RecipeTests(unittest.TestCase):
    def test_case_work_is_proposed_without_approval_or_scope_mutation(self):
        project = new_project('Requested outputs')
        project['outputs'] = [{'id': kind, 'kind': kind, 'ratio': '1:1', 'fps': '10', 'sample_rate': 8000} for kind in ('webm','vtt','wav')]
        before = deepcopy(project)
        proposal = work_proposal(project)
        self.assertEqual(proposal['state'], 'proposal')
        self.assertEqual({job['handler'] for job in proposal['jobs']}, {'compile_moments','preview','render_proof','export_outputs','assemble_audio'})
        self.assertIn('Add Moments', proposal['warnings'][-1])
        self.assertEqual(project, before)
    def test_combination_requires_every_real_conflict_choice(self):
        left, right = get_preset('product-launch'), get_preset('consulting-decision')
        before = deepcopy(left)
        result = compose(left, right)
        self.assertEqual(result['state'], 'needs-choice')
        self.assertIsNone(result['recipe'])
        self.assertIn('truth', [c['group'] for c in result['conflicts']])
        resolved = compose(left, right, {c['group']: 'secondary' for c in result['conflicts']})
        self.assertEqual(resolved['state'], 'proposal')
        self.assertEqual(resolved['recipe']['controls']['truth'], right['controls']['truth'])
        self.assertEqual(left, before)
        with self.assertRaises(ProjectError):
            compose(left, right, {'truth': []})
        with self.assertRaises(ProjectError):
            compose(left, right, [])

    def test_case_proposal_uses_declared_context_without_mutating_approval(self):
        project = new_project('Mobile')
        project['mission']['platforms'] = ['iOS mobile']
        before = deepcopy(project)
        recipe = recommend(project)
        self.assertIn('Mobile', recipe['label'])
        self.assertIn('rule-based', recipe['rationale'])
        self.assertEqual(project, before)

    def test_personal_recipe_round_trip_and_duplicate_rejection(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'project', new_project('Own recipe'))
            recipe = get_preset('product-launch')
            store.apply({'id': 'save', 'expected_revision': 0, 'action': 'save_preset', 'payload': recipe})
            saved = store.read()['extensions']['personal_presets'][0]
            self.assertEqual(saved['origin'], 'personal')
            with self.assertRaisesRegex(ProjectError, 'already exists'):
                store.apply({'id': 'again', 'expected_revision': 1, 'action': 'save_preset', 'payload': recipe})
            self.assertEqual(store.read()['revision'], 1)


if __name__ == '__main__':
    unittest.main()

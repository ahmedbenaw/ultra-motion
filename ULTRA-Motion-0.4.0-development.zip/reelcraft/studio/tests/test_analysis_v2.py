import json
from pathlib import Path
import tempfile
import unittest

from studio.analysis_v2 import recompute
from studio import jobs
from studio.project import ProjectError, ProjectStore, new_project


class QuantitativeTests(unittest.TestCase):
    def test_recomputed_change_is_source_linked_and_stales_after_edit(self):
        with tempfile.TemporaryDirectory() as folder:
            project = new_project('Metric decision')
            project['truth']['sources'] = [{'id': 'sheet', 'title': 'Supplied dataset', 'uri': 'local:metrics.csv', 'status': 'supplied'}]
            project['truth']['claims'] = [{'id': 'growth', 'text': 'Growth requires interpretation', 'status': 'supplied',
                                            'sources': ['sheet'], 'calculation': {'operation': 'percent_change', 'precision': 1,
                                            'inputs': [{'label': 'Before', 'value': '120', 'unit': 'users', 'source': 'sheet'},
                                                       {'label': 'After', 'value': '150', 'unit': 'users', 'source': 'sheet'}]}}]
            store = ProjectStore.create(Path(folder)/'project', project)
            jobs.define(store, [{'id': 'numbers', 'handler': 'quantitative_check', 'inputs': ['truth'], 'depends_on': []}], 0)
            plan = store.plan()
            store.apply({'id': 'approved', 'expected_revision': plan['revision'], 'action': 'approve',
                         'payload': {'digest': plan['digest'], 'actor': 'Synthetic owner'}})
            job = jobs.run(store)['jobs'][0]
            self.assertEqual(job['state'], 'verified', job['error'])
            data = json.loads((store.directory/job['artifacts'][0]['path']).read_text())
            self.assertEqual(data['calculations'][0]['result'], '25.0')
            self.assertEqual(data['calculations'][0]['sources'], ['sheet'])
            self.assertIn('not independently verified', data['calculations'][0]['status'])
            changed = store.read()['truth']
            changed['claims'][0]['calculation']['inputs'][1]['value'] = '180'
            store.apply({'id': 'new-source-value', 'expected_revision': store.read()['revision'],
                         'action': 'replace_truth', 'payload': changed})
            self.assertEqual(jobs.status(store)['jobs'][0]['state'], 'stale')

    def test_invalid_arithmetic_and_provenance_fail(self):
        truth = {'sources': [{'id': 's'}], 'claims': [{'id': 'c', 'sources': ['s'],
                  'calculation': {'operation': 'ratio', 'inputs': [
                      {'label': 'A', 'value': 2, 'unit': 'users', 'source': 's'},
                      {'label': 'B', 'value': 0, 'unit': 'users', 'source': 's'}]}}]}
        with self.assertRaisesRegex(ProjectError, 'zero'):
            recompute(truth)
        truth['claims'][0]['calculation']['inputs'][1]['source'] = 'other'
        with self.assertRaisesRegex(ProjectError, 'source'):
            recompute(truth)


if __name__ == '__main__':
    unittest.main()

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import time
import unittest

from studio import create, approve, run, status, cancel, retry
from studio.tests.test_core import spec


MEDIA = all(shutil.which(name) for name in ("ffmpeg", "ffprobe", "node"))


@unittest.skipUnless(MEDIA, "media runtime unavailable")
class PipelineTests(unittest.TestCase):
    def test_reel_audio_and_background_status(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "job"
            value = spec()
            value["timeline"]["duration"] = 1
            value["timeline"]["fps"] = 10
            value["timeline"]["scenes"][0]["end"] = 1
            value["audio"] = {"mode": "synth", "bpm": 120}
            result = create(value, path)
            approve(path, result["plan_sha256"])
            run(path, detach=True)
            deadline = time.monotonic() + 45
            while time.monotonic() < deadline:
                result = status(path)
                if result["state"]["status"] in {"completed", "failed", "cancelled"}:
                    break
                time.sleep(.1)
            self.assertEqual(result["state"]["status"], "completed", result)
            report = json.loads((path / "artifacts/attempt-001/review/report.json").read_text())
            self.assertTrue(report["checks_passed"])
            self.assertTrue(report["outputs"][0]["audio"])
            self.assertIsNotNone(report["outputs"][0]["loudness"])

    def test_broll_visible_alpha_and_source_preserved(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "source.mp4"
            subprocess.run(["ffmpeg", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=0x101820:s=320x180:r=10:d=1",
                "-f", "lavfi", "-i", "sine=frequency=440:duration=1", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", str(source)], check=True)
            original = hashlib.sha256(source.read_bytes()).hexdigest()
            value = spec()
            value.update(workflow="broll", input={"source_video": str(source)})
            value["timeline"] = {"duration": 1, "fps": 10, "scenes": [{"id": "panel", "type": "panel", "start": 0, "end": 1,
                "text": "Visible", "style": {"x": .58, "y": .2, "w": .35, "h": .4, "background": "#f2b84b", "color": "#101820"}}]}
            path = Path(folder) / "job"
            result = create(value, path)
            approve(path, result["plan_sha256"])
            result = run(path)
            self.assertEqual(result["state"]["status"], "completed")
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), original)
            track = next(Path(item["path"]) for item in result["artifacts"] if item["kind"] == "alpha_track")
            mask = subprocess.run(["ffmpeg", "-loglevel", "error", "-ss", "0.4", "-i", str(track), "-vf", "alphaextract,scale=16:9",
                "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "gray", "-"], capture_output=True, check=True).stdout
            self.assertLess(min(mask), 10)
            self.assertGreater(max(mask), 240)
            report = json.loads((path / "artifacts/attempt-001/review/report.json").read_text())
            self.assertTrue(report["outputs"][0]["audio"])


if __name__ == "__main__":
    unittest.main()

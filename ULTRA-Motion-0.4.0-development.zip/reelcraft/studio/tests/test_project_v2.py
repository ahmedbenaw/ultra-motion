import json
from pathlib import Path
import tempfile
import unittest

from studio.project import ProjectStore, ProjectError, compile_moments, import_v1, new_project, validate


class ProtocolTests(unittest.TestCase):
    def test_malformed_enum_and_reference_types_fail_without_traceback_or_write(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'project', new_project('Types'))
            for action, payload in [('set_policy', {'autonomy': []}), ('replace_outputs', [{'id': 'output', 'kind': [], 'ratio': '1:1', 'fps': '10', 'sample_rate': 8000}]), ('replace_moments', [{'id': 'point', 'title': 'Point', 'content': '', 'duration': 1, 'anchor': {'kind': 'after', 'ref': []}}])]:
                with self.assertRaises(ProjectError):
                    store.apply({'id': 'malformed', 'expected_revision': 0, 'action': action, 'payload': payload})
                self.assertEqual(store.read()['revision'], 0)
    def test_unknown_fields_are_rejected_without_losing_input(self):
        project = new_project('Client engagement', 'client-engagement')
        project['surprise'] = 'valuable content'
        with self.assertRaisesRegex(ProjectError, 'unknown'):
            validate(project)
        self.assertEqual(project['surprise'], 'valuable content')

    def test_legacy_import_preserves_original_and_allows_no_graphic(self):
        original = {'name': 'Speaker', 'workflow': 'broll', 'timeline': {'duration': 4, 'fps': '30000/1001', 'scenes': []}, 'extra': {'keep': True}}
        project = import_v1(original)
        self.assertEqual(project['extensions']['legacy_v1'], original)
        self.assertEqual(project['moments'], [])
        self.assertEqual(compile_moments(project)['moments'], [])

    def test_semantic_anchors_compile_to_exact_frames_and_samples(self):
        project = new_project('Timed explanation')
        project['outputs'][0]['fps'] = '30000/1001'
        project['anchors'] = {'word': {'intro': ['0.20', '0.65']}, 'beat': {}, 'event': {}}
        project['moments'] = [
            {'id': 'proof', 'title': 'Proof', 'anchor': {'kind': 'word', 'ref': 'intro', 'index': 1}, 'duration': '1.001', 'content': 'Observed'},
            {'id': 'result', 'title': 'Result', 'anchor': {'kind': 'after', 'ref': 'proof'}, 'duration': '0.5', 'content': 'Next'},
        ]
        result = compile_moments(project)
        self.assertEqual(result['moments'][0]['start_frame'], 19)
        self.assertEqual(result['moments'][0]['start_sample'], 31200)
        self.assertEqual(result['moments'][0]['duration_frames'], 30)
        self.assertEqual(result['moments'][1]['start_sample'], 79248)

    def test_cyclic_moments_and_missing_evidence_are_rejected(self):
        project = new_project('Invalid')
        project['moments'] = [
            {'id': 'a', 'title': 'A', 'content': '', 'duration': 1, 'anchor': {'kind': 'after', 'ref': 'b'}},
            {'id': 'b', 'title': 'B', 'content': '', 'duration': 1, 'anchor': {'kind': 'after', 'ref': 'a'}},
        ]
        with self.assertRaisesRegex(ProjectError, 'cycle'):
            compile_moments(project)
        project['moments'] = []
        project['truth']['claims'] = [{'id': 'claim', 'text': '20%', 'status': 'observed', 'sources': ['missing']}]
        with self.assertRaisesRegex(ProjectError, 'source'):
            validate(project)

    def test_idempotency_and_stale_changes(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'case', new_project('Before'))
            command = {'id': 'edit', 'expected_revision': 0, 'action': 'set_mission', 'payload': {'objective': 'After'}}
            first = store.apply(command)
            self.assertEqual(store.apply(command), first)
            self.assertEqual(store.read()['revision'], 1)
            with self.assertRaisesRegex(ProjectError, 'revision'):
                store.apply({**command, 'id': 'stale'})
            with self.assertRaisesRegex(ProjectError, 'reused'):
                store.apply({**command, 'payload': {'objective': 'Different'}})

    def test_approval_requires_exact_plan_and_actor(self):
        with tempfile.TemporaryDirectory() as folder:
            store = ProjectStore.create(Path(folder)/'case', new_project('Review'))
            digest = store.plan()['digest']
            store.apply({'id': 'approve', 'expected_revision': 0, 'action': 'approve', 'payload': {'digest': digest, 'actor': 'Owner'}})
            self.assertTrue(store.plan()['approved'])
            store.apply({'id': 'edit', 'expected_revision': 1, 'action': 'set_mission', 'payload': {'objective': 'Changed'}})
            self.assertFalse(store.plan()['approved'])
            self.assertEqual(store.read()['events'][0]['action'], 'approve')

    def test_dynamic_preset_covers_every_control(self):
        from studio.presets import CONTROL_GROUPS, validate_preset
        recipe = {'id': 'custom', 'label': 'Custom', 'origin': 'ai', 'controls': {key: {'mode': 'automatic', 'value': None} for key in CONTROL_GROUPS}}
        validate_preset(recipe)
        del recipe['controls']['truth']
        with self.assertRaisesRegex(ProjectError, 'coverage'):
            validate_preset(recipe)


if __name__ == '__main__':
    unittest.main()

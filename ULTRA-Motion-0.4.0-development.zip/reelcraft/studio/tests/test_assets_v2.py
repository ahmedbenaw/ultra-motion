import hashlib
from pathlib import Path
import tempfile
import unittest

from studio.assets_v2 import MAX_ASSET_BYTES, asset_fingerprint
from studio.core import ProjectError


class AssetFingerprintTests(unittest.TestCase):
    def test_bytes_replacement_dedup_and_order(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root/'image.png').write_bytes(b'image')
            (root/'audio.wav').write_bytes(b'audio')
            project = {'moments': [
                {'visual': {'image': './image.png'}, 'audio': {'file': 'audio.wav'}},
                {'visual': {'image': 'image.png'}, 'content': 'https://ignored.example'}]}
            before = asset_fingerprint(project, root, ['moments'])
            self.assertEqual([row['path'] for row in before], ['audio.wav', 'image.png'])
            self.assertEqual(before[1]['sha256'], hashlib.sha256(b'image').hexdigest())
            (root/'image.png').write_bytes(b'new image')
            self.assertNotEqual(before, asset_fingerprint(project, root, ['moments']))

    def test_selected_fields_and_explicit_keys_only(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root/'font.ttf').write_bytes(b'font')
            project = {'moments': [{'visual': {'image': 'missing.png'}, 'content': '/private/file'}],
                       'extensions': {'export_font': 'font.ttf', 'note': 'missing.txt'},
                       'truth': {'sources': [{'uri': 'local:missing.csv'}]}}
            self.assertEqual(asset_fingerprint(project, root, ['truth']), [])
            self.assertEqual(asset_fingerprint(project, root, ['extensions'])[0]['path'], 'font.ttf')
            with self.assertRaisesRegex(ProjectError, 'missing'):
                asset_fingerprint(project, root, ['moments'])

    def test_unsafe_missing_and_oversized_paths(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for value in ('../outside.png', '/tmp/outside.png', 'C:/outside.png', 'https://host/image.png', 'a\\image.png', ''):
                with self.subTest(value=value), self.assertRaises(ProjectError):
                    asset_fingerprint({'moments': [{'visual': {'image': value}}]}, root, ['moments'])
            with self.assertRaisesRegex(ProjectError, 'missing'):
                asset_fingerprint({'moments': [{'audio': {'file': 'missing.wav'}}]}, root, ['moments'])
            with (root/'large.wav').open('wb') as stream:
                stream.truncate(MAX_ASSET_BYTES+1)
            with self.assertRaisesRegex(ProjectError, '50 MiB'):
                asset_fingerprint({'moments': [{'audio': {'file': 'large.wav'}}]}, root, ['moments'])

    def test_symlink_file_and_directory_are_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root/'real').mkdir()
            (root/'real'/'image.png').write_bytes(b'image')
            try:
                (root/'link.png').symlink_to(root/'real'/'image.png')
                (root/'alias').symlink_to(root/'real', target_is_directory=True)
            except (OSError, NotImplementedError):
                self.skipTest('symlink creation unavailable')
            for value in ('link.png', 'alias/image.png'):
                with self.subTest(value=value), self.assertRaisesRegex(ProjectError, 'symlink'):
                    asset_fingerprint({'moments': [{'visual': {'image': value}}]}, root, ['moments'])


if __name__ == '__main__':
    unittest.main()

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from studio import create, approve, plan, run, ProjectError


def spec():
    return {"workflow": "reel", "name": "Fixture", "timeline": {"duration": .5, "fps": 4,
            "scenes": [{"id": "intro", "type": "title", "start": 0, "end": .5, "text": "Verified"}]},
            "formats": ["16x9"], "audio": {"mode": "none"}}


class ProjectTests(unittest.TestCase):
    def test_approval_is_bound_to_plan(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "job"
            result = create(spec(), path)
            with self.assertRaises(ProjectError):
                run(path)
            approve(path, result["plan_sha256"])
            data = json.loads((path / "project.json").read_text())
            data["timeline"]["scenes"][0]["text"] = "Changed"
            (path / "project.json").write_text(json.dumps(data))
            self.assertTrue(plan(path)["approval_required"])
            with self.assertRaises(ProjectError):
                run(path)

    def test_init_preserves_existing_files(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)
            (path / "keep.txt").write_text("keep")
            with self.assertRaises(ProjectError):
                create(spec(), path)
            self.assertEqual((path / "keep.txt").read_text(), "keep")

    def test_asset_mutation_blocks_render(self):
        with tempfile.TemporaryDirectory() as folder:
            source = Path(folder) / "image.png"
            source.write_bytes(b"original image fixture")
            value = spec()
            value["timeline"]["scenes"] = [{"id": "image", "type": "image", "start": 0, "end": .5, "image": str(source)}]
            path = Path(folder) / "job"
            result = create(value, path)
            approve(path, result["plan_sha256"])
            image = next((path / "assets").iterdir())
            image.write_bytes(b"changed image")
            with self.assertRaisesRegex(ProjectError, "asset changed"):
                run(path)

    def test_rational_fps(self):
        from studio.core import validate
        value = spec()
        value["timeline"]["fps"] = "30000/1001"
        self.assertAlmostEqual(validate(value)["timeline"]["fps"], 29.97002997)

    def test_styles_fail_before_approval(self):
        from studio.core import validate
        for change in ({"style": {"w": 0}}, {"style": {"x": .9}},
                       {"styleByFormat": {"16x9": {"bogus": 1}}},
                       {"styleByFormat": {"16x9": {"color": "red"}}},
                       {"styleByFormat": {"16x9": {"x": .9}}}):
            with self.subTest(change=change):
                value = spec()
                value["timeline"]["scenes"][0].update(change)
                with self.assertRaises(ProjectError):
                    validate(value)

    def test_cli_resolves_media_from_spec_directory(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "image.png").write_bytes(b"fixture")
            value = spec()
            value["timeline"]["scenes"] = [{"id": "image", "type": "image", "start": 0, "end": .5, "image": "image.png"}]
            source = root / "spec.json"
            source.write_text(json.dumps(value))
            script = Path(__file__).resolve().parents[2] / "scripts/studio.py"
            result = subprocess.run([sys.executable, str(script), "init", "--spec", str(source), "--project", str(root / "job")], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)


class MCPTests(unittest.TestCase):
    def test_protocol_and_workspace_boundary(self):
        server = Path(__file__).resolve().parents[2] / "scripts" / "mcp_server.py"
        messages = [
            {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-03-26"}},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
            {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "project_plan", "arguments": {"project": "../../outside"}}},
        ]
        result = subprocess.run([sys.executable, str(server)], input="".join(json.dumps(v) + "\n" for v in messages), text=True, capture_output=True, check=True)
        responses = [json.loads(line) for line in result.stdout.splitlines()]
        self.assertEqual(responses[0]["result"]["serverInfo"]["name"], "reelcraft")
        self.assertTrue({"project_plan", "project_approve", "engagement_plan", "engagement_command", "work_start"} <= {tool["name"] for tool in responses[1]["result"]["tools"]})
        self.assertTrue(responses[2]["result"]["isError"])


if __name__ == "__main__":
    unittest.main()

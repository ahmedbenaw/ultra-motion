import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

from studio import branch_store, jobs
from studio.project import CONTENT_FIELDS, ProjectError, ProjectStore, new_project


@unittest.skipUnless(shutil.which('git'), 'Git unavailable')
class BranchStoreTests(unittest.TestCase):
    def test_unicode_assets_and_stale_draft_round_trip(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            repo = base/'projects.git'
            branch_store.initialize(repo)
            project = new_project('Unicode draft')
            project['policy']['storage'] = 'github'
            project['moments'] = [{'id': 'asset', 'title': 'Asset', 'content': '', 'anchor': {'kind': 'seconds', 'seconds': 0}, 'duration': 1, 'visual': {'type': 'image', 'image': 'assets/صورة example.png'}}]
            store = ProjectStore.create(base/'active', project)
            (store.directory/'assets').mkdir()
            (store.directory/'assets/صورة example.png').write_bytes(b'synthetic asset')
            jobs.define(store, [{'id': 'preview', 'handler': 'preview', 'inputs': sorted(CONTENT_FIELDS), 'depends_on': []}], 0)
            plan = store.plan()
            store.apply({'id': 'approval', 'expected_revision': plan['revision'], 'action': 'approve', 'payload': {'actor': 'Fixture', 'digest': plan['digest']}})
            jobs.run(store)
            store.apply({'id': 'edit', 'expected_revision': store.read()['revision'], 'action': 'set_mission', 'payload': {'objective': 'Draft revision'}})
            self.assertEqual(jobs.status(store)['jobs'][0]['state'], 'stale')
            branch_store.save(repo, store)
            branch_store.restore(repo, project['id'], base/'restored')
            recovered = ProjectStore(base/'restored')
            self.assertEqual(jobs.status(recovered)['jobs'][0]['state'], 'stale')
            self.assertEqual((recovered.directory/'assets/صورة example.png').read_bytes(), b'synthetic asset')
            artifact = store.directory/store.read()['jobs'][0]['artifacts'][0]['path']
            artifact.write_text('corrupted')
            branch_store.save(repo, store)
            with self.assertRaisesRegex(ProjectError, 'hashes'):
                branch_store.restore(repo, project['id'], base/'corrupted')
            self.assertFalse((base/'corrupted').exists())

    def test_snapshot_rejects_input_that_would_not_be_restored(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            repo = base/'projects.git'
            branch_store.initialize(repo)
            project = new_project('Inputs must survive')
            project['policy']['storage'] = 'github'
            project['moments'] = [{'id': 'asset', 'title': 'Asset', 'content': '', 'anchor': {'kind': 'seconds', 'seconds': 0}, 'duration': 1, 'visual': {'type': 'image', 'image': 'outside-assets.png'}}]
            store = ProjectStore.create(base/'active', project)
            (store.directory/'outside-assets.png').write_bytes(b'synthetic asset')
            with self.assertRaisesRegex(ProjectError, 'inputs in assets'):
                branch_store.save(repo, store)
            self.assertIsNone(branch_store.tip(repo, project['id']))

    def test_save_restore_preserves_verified_artifacts_and_detects_divergence(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            repo = base/'projects.git'
            branch_store.initialize(repo)
            configured = branch_store.configure_origin(repo, 'https://github.com/example/private-projects.git')
            self.assertEqual(configured['state'], 'configured')
            self.assertEqual(branch_store.configure_origin(repo, configured['origin'])['state'], 'unchanged')
            with self.assertRaisesRegex(ProjectError, 'different repository'):
                branch_store.configure_origin(repo, 'https://github.com/example/other.git')
            project = new_project('Decision')
            project['policy']['storage'] = 'github'
            store = ProjectStore.create(base/'active', project)
            jobs.define(store, [{'id': 'inventory', 'handler': 'evidence_inventory', 'depends_on': [], 'inputs': ['truth']}], 0)
            plan = store.plan()
            store.apply({'id': 'approve', 'expected_revision': plan['revision'], 'action': 'approve',
                         'payload': {'digest': plan['digest'], 'actor': 'Synthetic owner'}})
            self.assertEqual(jobs.run(store)['jobs'][0]['state'], 'verified')
            first = branch_store.save(repo, store)
            with self.assertRaisesRegex(ProjectError, 'changed'):
                branch_store.save(repo, store, branch_store.ZERO)
            restored = branch_store.restore(repo, project['id'], base/'fresh')
            self.assertEqual(restored['commit'], first['commit'])
            recovered = ProjectStore(base/'fresh')
            self.assertEqual(jobs.status(recovered)['jobs'][0]['state'], 'verified')
            with self.assertRaisesRegex(ProjectError, 'exists'):
                branch_store.restore(repo, project['id'], base/'fresh')
            command = {'id': 'edit', 'expected_revision': store.read()['revision'], 'action': 'set_mission',
                       'payload': {'objective': 'New decision'}}
            store.apply(command)
            second = branch_store.save(repo, store, first['commit'])
            self.assertEqual(second['previous'], first['commit'])
            self.assertNotEqual(second['commit'], first['commit'])

    def test_rejects_local_mode_and_symlink_escape(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            repo = base/'projects.git'
            branch_store.initialize(repo)
            store = ProjectStore.create(base/'active', new_project('Local'))
            with self.assertRaisesRegex(ProjectError, 'GitHub storage'):
                branch_store.save(repo, store)
            state = store.read()
            state['policy']['storage'] = 'github'
            (store.directory/'project-v2.json').write_text(json.dumps(state))
            (store.directory/'assets').symlink_to(base, target_is_directory=True)
            with self.assertRaisesRegex(ProjectError, 'symlink'):
                branch_store.save(repo, store)


if __name__ == '__main__':
    unittest.main()

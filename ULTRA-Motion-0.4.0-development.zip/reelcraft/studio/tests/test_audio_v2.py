from array import array
import json
from pathlib import Path
import tempfile
import unittest
import wave

from studio.audio_v2 import render_audio
from studio.project import new_project, ProjectError


class AudioTests(unittest.TestCase):
    def test_pcm_is_placed_at_exact_semantic_sample_and_preserved(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with wave.open(str(root/'source.wav'), 'wb') as source:
                source.setparams((1, 2, 8000, 10, 'NONE', 'not compressed'))
                source.writeframes(b'\xe8\x03'*10)
            project = new_project('Sample proof')
            project['outputs'] = [{'id': 'sound', 'kind': 'wav', 'ratio': '16:9', 'fps': '10', 'sample_rate': 8000}]
            project['moments'] = [{'id': 'cue', 'title': 'Cue', 'content': '', 'anchor': {'kind': 'seconds', 'seconds': '1/3'}, 'duration': '2/3', 'audio': {'file': 'source.wav', 'gain': .5}}]
            paths = render_audio(project, root, root)
            with wave.open(str(paths[0]), 'rb') as result:
                self.assertEqual(result.getnframes(), 8000)
                samples = array('h', result.readframes(8000))
            self.assertEqual(samples[2666*2], 0)
            self.assertEqual(samples[2667*2:2677*2], array('h', [500]*20))
            self.assertEqual(json.loads(paths[1].read_text())['cues'][0]['start_sample'], 2667)
            project['moments'][0]['audio']['gain'] = 1
            project['moments'].append(dict(project['moments'][0], id='overlap'))
            # Inputs themselves are safe, but enough explicit overlaps must never silently clip.
            project['moments'] = [dict(project['moments'][0], id='cue'+str(i)) for i in range(40)]
            with self.assertRaisesRegex(ProjectError, 'clip'):
                render_audio(project, root, root)

    def test_wrong_rate_and_non_pcm_options_are_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            project = new_project('Boundary')
            project['outputs'] = [{'id': 'sound', 'kind': 'wav', 'ratio': '1:1', 'fps': '10', 'sample_rate': 8000}]
            project['moments'] = [{'id': 'cue', 'title': 'Cue', 'content': '', 'anchor': {'kind': 'seconds', 'seconds': 0}, 'duration': 1, 'audio': {'kind': 'generated'}}]
            with self.assertRaisesRegex(ProjectError, 'audio.file'):
                render_audio(project, root, root)
            with wave.open(str(root/'wrong.wav'), 'wb') as source:
                source.setparams((1, 2, 16000, 10, 'NONE', 'not compressed'))
                source.writeframes(b'\0\0'*10)
            project['moments'][0]['audio'] = {'file': 'wrong.wav'}
            with self.assertRaisesRegex(ProjectError, 'sample rate'):
                render_audio(project, root, root)

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

from studio.core import ProjectError
from studio.exports_v2 import export_outputs
from studio.project import new_project


def project(*kinds):
    value = new_project('Decision proof')
    value['outputs'] = [{'id': 'out'+str(i), 'kind': kind, 'ratio': '16:9', 'fps': '30', 'sample_rate': 48000} for i, kind in enumerate(kinds)]
    value['moments'] = [{'id': 'first', 'title': 'First', 'content': 'Review <A> & B',
                         'anchor': {'kind': 'seconds', 'seconds': '1/3'}, 'duration': '2/3',
                         'visual': {'type': 'panel'}}]
    return value


class ExportTests(unittest.TestCase):
    def export(self, value):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        directory = Path(temporary.name)
        return export_outputs(value, directory, directory)

    def test_subtitles_preserve_rational_timing_and_escape_markup(self):
        paths = self.export(project('srt', 'vtt', 'json'))
        self.assertIn('00:00:00,333 --> 00:00:01,000', paths[0].read_text())
        self.assertIn('Review <A> & B', paths[0].read_text())
        self.assertIn('Review &lt;A&gt; &amp; B', paths[1].read_text())
        self.assertEqual(json.loads(paths[2].read_text())['compiled_moments'][0]['start'], '1/3')

    def test_overlapping_and_malformed_cues_rejected_before_output(self):
        value = project('json', 'srt')
        other = dict(value['moments'][0], id='second')
        value['moments'].append(other)
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            with self.assertRaisesRegex(ProjectError, 'overlap'):
                export_outputs(value, directory, directory)
            self.assertEqual(list(directory.iterdir()), [])
        value['moments'] = [value['moments'][0]]
        value['moments'][0]['content'] = 'Text\n\n1 --> 2'
        with self.assertRaisesRegex(ProjectError, 'delimiters'):
            self.export(value)

    def test_lottie_solid_panel_and_unsupported_typography(self):
        value = project('lottie')
        with self.assertRaisesRegex(ProjectError, 'empty-content'):
            self.export(value)
        value['moments'][0]['content'] = ''
        value['moments'][0]['visual']['style'] = {'background': '#112233'}
        payload = json.loads(self.export(value)[0].read_text())
        self.assertEqual(payload['layers'][0]['sc'], '#112233')
        self.assertEqual(payload['layers'][0]['ip'], 10)
        self.assertEqual(payload['op'], 30)
        value['moments'][0]['visual']['style']['fontSize'] = 18
        with self.assertRaisesRegex(ProjectError, 'fonts'):
            self.export(value)

    @unittest.skipUnless(importlib.util.find_spec('reportlab') and importlib.util.find_spec('pypdf'), 'optional PDF dependencies')
    def test_pdf_reopened_text_and_unicode_rejected(self):
        from pypdf import PdfReader
        value = project('pdf')
        path = self.export(value)[0]
        text = '\n'.join(p.extract_text() for p in PdfReader(path).pages)
        self.assertIn('Decision proof', text)
        self.assertIn('Review <A> & B', text)
        value['name'] = 'اختبار'
        with self.assertRaisesRegex(ProjectError, 'ASCII'):
            self.export(value)

    @unittest.skipUnless(importlib.util.find_spec('pptx'), 'optional PPTX dependency')
    def test_pptx_long_editable_content_split_and_reopened(self):
        from pptx import Presentation
        value = project('pptx')
        value['moments'][0]['content'] = 'Unique scene phrase '+('long material '*300)
        slides = Presentation(self.export(value)[0]).slides
        text = '\n'.join(shape.text for slide in slides for shape in slide.shapes)
        self.assertIn('Unique scene phrase', text)
        self.assertIn('continued', text)
        self.assertGreater(len(slides), 5)
        self.assertTrue(all(len(slide.shapes[1].text.split('\n')) <= 16 for slide in slides))

    def test_media_only_rejected(self):
        with self.assertRaisesRegex(ProjectError, 'request SRT'):
            self.export(project('mp4'))

    @unittest.skipUnless(importlib.util.find_spec('pptx'), 'optional PPTX dependency')
    def test_pptx_requested_ratios_and_text_regions_reopened(self):
        from pptx import Presentation
        from pptx.util import Inches
        for ratio in ('16:9', '9:16', '1:1', '4:5'):
            with self.subTest(ratio=ratio):
                value = project('pptx')
                value['outputs'][0]['ratio'] = ratio
                value['moments'][0]['title'] = 'Long heading '*60
                value['moments'][0]['content'] = 'A'*700+'\n'+('Content '*500)
                presentation = Presentation(self.export(value)[0])
                num, den = map(int, ratio.split(':'))
                self.assertEqual(presentation.slide_width*den, presentation.slide_height*num)
                text = '\n'.join(slide.shapes[1].text for slide in presentation.slides)
                self.assertEqual(' '.join(text.split()).count('Long heading'), 60)
                for slide in presentation.slides:
                    for shape in slide.shapes:
                        self.assertGreaterEqual(shape.left, 0)
                        self.assertGreaterEqual(shape.top, 0)
                        self.assertLessEqual(shape.left+shape.width, presentation.slide_width)
                        self.assertLessEqual(shape.top+shape.height, presentation.slide_height)
                    body = slide.shapes[1]
                    capacity = int((body.height/Inches(1)-.2)*72/24)
                    self.assertLessEqual(len(body.text.split('\n')), capacity)


if __name__ == '__main__':
    unittest.main()

import tempfile
from pathlib import Path
import unittest

from studio.timing import parse_captions, beat_grid


class TimingTests(unittest.TestCase):
    def test_srt_and_vtt(self):
        for header in ("", "WEBVTT\n\n"):
            with tempfile.TemporaryDirectory() as temp:
                path = Path(temp) / "t.srt"
                path.write_text(header + "1\n00:00:00,500 --> 00:00:01,200\nHello world\n\n2\n00:00:02.000 --> 00:00:03.000\nMore\n")
                cues = parse_captions(path)
                self.assertEqual(len(cues), 2)
                self.assertEqual(cues[0]["start"], .5)

    def test_beat_grid(self):
        self.assertEqual(beat_grid(2, 120), [0, .5, 1, 1.5])


if __name__ == "__main__":
    unittest.main()

"""Network-free capture tests. Run: python3 -m unittest discover -s studio/tests."""

import json
import pathlib
import tempfile
import unittest
from unittest import mock

from studio import capture as mod


HTML = b'''<!doctype html><html><head><title>Northstar Notes</title>
<meta name="description" content="Plan your week">
<meta name="theme-color" content="#123456">
<meta property="og:image" content="/preview.png">
<style>body { background-color: #123456; color: #fedcba }</style></head>
<body style="color:#fedcba">Hello</body></html>'''


class UrlTests(unittest.TestCase):
    def test_rejects_local_private_and_unsafe_urls(self):
        for url in (
            "http://example.com", "https://localhost/", "https://127.0.0.1/",
            "https://10.1.2.3/", "https://192.168.1.5/", "https://[::1]/",
            "https://169.254.169.254/latest", "https://user:password@example.com/",
            "https://example.com:8443/", "https://example.com\r\nHost:evil.test/",
            "https://example.local/", "https://example.com\\@evil.test/",
            "https://224.0.0.1/", "https://[ff02::1]/",
        ):
            with self.subTest(url=url), self.assertRaises(mod.CaptureError):
                mod._url(url)

    def test_public_url_normalization(self):
        url, host, target = mod._url("https://Example.COM/a?b=c#frag")
        self.assertEqual((url, host, target),
                         ("https://example.com/a?b=c", "example.com", "/a?b=c"))

    def test_mixed_dns_results_are_rejected(self):
        public = (None, None, None, None, ("8.8.8.8", 443))
        private = (None, None, None, None, ("127.0.0.1", 443))
        with mock.patch.object(mod.socket, "getaddrinfo", return_value=[public, private]):
            with self.assertRaisesRegex(mod.CaptureError, "DNS returned"):
                mod._public_addresses("example.com")

    def test_dns_timeout(self):
        import time
        with mock.patch.object(mod, "_public_addresses", side_effect=lambda _: time.sleep(.1)):
            with self.assertRaisesRegex(mod.CaptureError, "DNS lookup timed out"):
                mod._resolve_with_deadline("example.com", time.monotonic() + .001)


class FetchTests(unittest.TestCase):
    def test_connection_pins_ip_but_verifies_hostname(self):
        connection = mod._PinnedHTTPSConnection("example.com", "8.8.8.8", 2)
        wrapped = object()
        context = mock.Mock()
        context.wrap_socket.return_value = wrapped
        connection._context = context
        with mock.patch.object(mod.socket, "create_connection", return_value=mock.Mock()) as connect:
            connection.connect()
        connect.assert_called_once_with(("8.8.8.8", 443), 2)
        context.wrap_socket.assert_called_once_with(connect.return_value,
                                                    server_hostname="example.com")
        self.assertIs(connection.sock, wrapped)

    def test_redirect_to_private_address_is_blocked_before_second_fetch(self):
        response = mod.Response("https://example.com/", 302,
                                {"location": "https://127.0.0.1/admin"}, b"", "8.8.8.8")
        with mock.patch.object(mod, "_fetch_once", return_value=response) as fetch:
            with self.assertRaises(mod.CaptureError):
                mod._retrieve("https://example.com/", max_bytes=1024, timeout=3)
        fetch.assert_called_once()

    def test_redirect_loop(self):
        response = mod.Response("https://example.com/", 302,
                                {"location": "/"}, b"", "8.8.8.8")
        with mock.patch.object(mod, "_fetch_once", return_value=response):
            with self.assertRaisesRegex(mod.CaptureError, "Redirect loop"):
                mod._retrieve("https://example.com/", max_bytes=1024, timeout=3)

    def test_streaming_size_limit(self):
        class FakeResponse:
            status = 200
            def getheaders(self):
                return [("Content-Type", "text/html")]
            def read(self, n):
                return b"x" * n
        class FakeConnection:
            sock = None
            def __init__(self, *args):
                pass
            def request(self, *args, **kwargs):
                pass
            def getresponse(self):
                return FakeResponse()
            def close(self):
                pass
        with mock.patch.object(mod, "_resolve_with_deadline", return_value=["8.8.8.8"]), \
             mock.patch.object(mod, "_PinnedHTTPSConnection", FakeConnection):
            import time
            with self.assertRaisesRegex(mod.CaptureError, "byte limit"):
                mod._fetch_once("https://example.com/", time.monotonic() + 3, 1024)


class MetadataTests(unittest.TestCase):
    def test_extracts_metadata_without_downloading_assets(self):
        response = mod.Response("https://example.com/", 200,
                                {"content-type": "text/html; charset=utf-8"}, HTML, "8.8.8.8")
        with tempfile.TemporaryDirectory() as directory, \
             mock.patch.object(mod, "_retrieve", return_value=(response, [{"status": 200}])):
            result = mod.capture("https://example.com/", pathlib.Path(directory) / "assets")
            self.assertEqual(result["brand"]["title"], "Northstar Notes")
            self.assertEqual(result["brand"]["open_graph"]["og:image"],
                             "https://example.com/preview.png")
            self.assertEqual({x["hex"] for x in result["brand"]["colors"]},
                             {"#123456", "#fedcba"})
            self.assertEqual(result["assets"], [])
            saved = json.loads((pathlib.Path(directory) / "assets/provenance.json").read_text())
            self.assertEqual(saved["fetch"]["sha256"], result["fetch"]["sha256"])

    def test_screenshot_is_opt_in_and_offline(self):
        response = mod.Response("https://example.com/", 200,
                                {"content-type": "text/html"}, HTML, "8.8.8.8")
        with tempfile.TemporaryDirectory() as directory, \
             mock.patch.object(mod, "_retrieve", return_value=(response, [])), \
             mock.patch.object(mod, "_offline_screenshot") as screenshot:
            mod.capture("https://example.com/", pathlib.Path(directory) / "assets", screenshot=True)
            screenshot.assert_called_once()

    def test_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            target = pathlib.Path(directory)
            (target / "existing.txt").write_text("keep")
            with self.assertRaisesRegex(mod.CaptureError, "not empty"):
                mod.capture("https://example.com/", target)


if __name__ == "__main__":
    unittest.main()

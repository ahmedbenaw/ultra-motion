import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

from studio import jobs
from studio.project import CONTENT_FIELDS, ProjectError, ProjectStore, new_project


def approve(store):
    plan = store.plan()
    store.apply({'id': 'approve-'+str(plan['revision']), 'expected_revision': plan['revision'],
                 'action': 'approve', 'payload': {'digest': plan['digest'], 'actor': 'Owner'}})


class ReleaseTests(unittest.TestCase):
    def test_replacing_asset_bytes_invalidates_approval_and_result(self):
        with tempfile.TemporaryDirectory() as folder:
            value = new_project('Asset approval')
            value['moments'] = [{'id': 'image', 'title': 'Image', 'content': '',
                'anchor': {'kind': 'seconds', 'seconds': 0}, 'duration': 1,
                'visual': {'type': 'image', 'image': 'proof.png'}}]
            store = ProjectStore.create(Path(folder)/'project', value)
            image = store.directory/'proof.png'
            image.write_bytes(b'first bytes')
            jobs.define(store, [{'id': 'preview', 'handler': 'preview', 'inputs': sorted(CONTENT_FIELDS), 'depends_on': []}], 0)
            approve(store)
            self.assertEqual(jobs.run(store)['jobs'][0]['state'], 'verified')
            image.write_bytes(b'replacement bytes')
            self.assertFalse(store.plan()['approved'])
            self.assertEqual(jobs.status(store)['jobs'][0]['state'], 'stale')
            with self.assertRaisesRegex(ProjectError, 'approval'):
                jobs.start_background(store)
            approve(store)
            self.assertEqual(jobs.run(store)['jobs'][0]['attempt'], 2)
            image.unlink()
            self.assertEqual(jobs.status(store)['jobs'][0]['state'], 'stale')

    def test_document_outputs_are_integrated_hashed_job_artifacts(self):
        with tempfile.TemporaryDirectory() as folder:
            value = new_project('Documents')
            value['outputs'] = [{'id': kind, 'kind': kind, 'ratio': '16:9', 'fps': '10', 'sample_rate': 48000} for kind in ('json', 'srt', 'vtt')]
            value['moments'] = [{'id': 'point', 'title': 'Point', 'content': 'A decision', 'anchor': {'kind': 'seconds', 'seconds': 0}, 'duration': 1}]
            store = ProjectStore.create(Path(folder)/'project', value)
            jobs.define(store, [{'id': 'exports', 'handler': 'export_outputs', 'inputs': sorted(CONTENT_FIELDS), 'depends_on': []}], 0)
            approve(store)
            job = jobs.run(store)['jobs'][0]
            self.assertEqual(job['state'], 'verified', job['error'])
            self.assertEqual({a['media_type'] for a in job['artifacts']}, {'application/json', 'application/x-subrip', 'text/vtt'})
            (store.directory/job['artifacts'][0]['path']).write_bytes(b'tampered')
            self.assertEqual(jobs.status(store)['jobs'][0]['state'], 'stale')

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'media tools unavailable')
    def test_real_webm_gif_preserve_frames_and_duration(self):
        with tempfile.TemporaryDirectory() as folder:
            value = new_project('New media formats')
            value['moments'] = [{'id': 'blank', 'title': 'Blank', 'content': '', 'anchor': {'kind': 'seconds', 'seconds': 0}, 'duration': 1, 'visual': {'type': 'none'}}]
            value['outputs'] = [{'id': kind, 'kind': kind, 'ratio': '1:1', 'fps': '10', 'sample_rate': 48000} for kind in ('webm', 'gif')]
            store = ProjectStore.create(Path(folder)/'project', value)
            jobs.define(store, [{'id': 'media', 'handler': 'render_proof', 'inputs': sorted(CONTENT_FIELDS), 'depends_on': []}], 0)
            approve(store)
            job = jobs.run(store)['jobs'][0]
            self.assertEqual(job['state'], 'verified', job['error'])
            for asset in job['artifacts']:
                path = store.directory/asset['path']
                if path.suffix not in {'.gif', '.webm'}:
                    continue
                probe = subprocess.run(['ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0', '-show_entries', 'stream=nb_read_frames,width,height:format=duration', '-of', 'json', str(path)], capture_output=True, text=True, check=True)
                info = json.loads(probe.stdout)
                self.assertEqual(info['streams'][0]['nb_read_frames'], '10')
                self.assertEqual(info['streams'][0]['width'], 540)
                self.assertAlmostEqual(float(info['format']['duration']), 1, places=2)


if __name__ == '__main__':
    unittest.main()

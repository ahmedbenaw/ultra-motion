"""Deterministic, local audio bed for a motion project.

The module accepts supplied music/voice files or generates an original rhythmic
bed. All external media conversion uses argv subprocesses and ffmpeg's measured
loudness filter. No network service or credentials are involved.
"""

from __future__ import annotations

import math
import os
from pathlib import Path
import struct
import subprocess
import wave


RATE = 48_000


def _inside(root: Path, value: str) -> Path:
    path = (root / value).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError(f"Audio file must exist inside the project: {value}")
    return path


def _synth(path: Path, duration: float, bpm: float, effects: list[dict]) -> None:
    if not (0.25 <= duration <= 600 and 40 <= bpm <= 240):
        raise ValueError("Audio duration or BPM out of range")
    beats_per_second = bpm / 60
    clicks: list[tuple[float, str]] = []
    for effect in effects:
        t = float(effect["time"])
        kind = effect.get("kind", "click")
        if kind not in {"click", "impact"} or not (0 <= t <= duration):
            raise ValueError("Invalid sound effect cue")
        clicks.append((t, kind))
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as out:
        out.setnchannels(2)
        out.setsampwidth(2)
        out.setframerate(RATE)
        for first in range(0, math.ceil(duration * RATE), 4096):
            payload = bytearray()
            for n in range(first, min(first + 4096, math.ceil(duration * RATE))):
                t = n / RATE
                beat = t * beats_per_second
                beat_phase = beat % 1
                beat_number = int(beat)
                kick_envelope = math.exp(-beat_phase * 18)
                kick = math.sin(2 * math.pi * (48 + 90 * math.exp(-beat_phase * 24)) * t) * kick_envelope * .43
                hat = math.sin(2 * math.pi * 7943 * t) * math.exp(-beat_phase * 80) * .045
                chord = (0, 3, 7, 10)[(beat_number // 8) % 4]
                root = 110 * 2 ** (chord / 12)
                pad = (math.sin(2 * math.pi * root * t) + .45 * math.sin(2 * math.pi * root * 1.5 * t)) * .075
                snare_phase = (beat - .5) % 2
                snare = math.sin(2 * math.pi * 1733 * t) * math.exp(-snare_phase * 42) * .075 if snare_phase < .18 else 0
                cue = 0.0
                for mark, kind in clicks:
                    d = t - mark
                    if 0 <= d < .22:
                        freq = 1660 if kind == "click" else 95
                        cue += math.sin(2 * math.pi * freq * d) * math.exp(-d * (42 if kind == "click" else 18)) * .18
                fade = min(1.0, t / .04, (duration - t) / .12)
                sample = max(-.95, min(.95, (kick + hat + pad + snare + cue) * max(0.0, fade)))
                pcm = int(sample * 32767)
                payload.extend(struct.pack("<hh", pcm, pcm))
            out.writeframesraw(payload)


def build_audio(project: dict, attempt_dir: Path) -> Path | None:
    """Return a 48 kHz WAV of exactly the timeline length, or None for silence.

    Audio inputs are paths relative to the project directory. Generated beds are
    repeatable for an identical timeline. The music/voice mix uses ffmpeg and
    reports a subprocess error rather than silently dropping a track.
    """
    audio = project.get("audio") or {}
    mode = audio.get("mode", "none")
    if mode not in {"none", "synth", "file"}:
        raise ValueError("audio.mode must be none, synth, or file")
    duration = float(project["timeline"]["duration"])
    root = Path(project.get("_project_dir", ".")).resolve()
    tracks: list[Path] = []
    if mode == "synth":
        bed = attempt_dir / "score.wav"
        _synth(bed, duration, float(audio.get("bpm", project["timeline"].get("bpm", 120))), audio.get("sfx", []))
        tracks.append(bed)
    elif mode == "file":
        tracks.append(_inside(root, audio["file"]))
    if audio.get("voice_file"):
        tracks.append(_inside(root, audio["voice_file"]))
    if not tracks:
        return None
    output = attempt_dir / "mix.wav"
    args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y"]
    for path in tracks:
        args += ["-i", os.fspath(path)]
    if len(tracks) == 1:
        filters = "[0:a]aresample=48000,apad,loudnorm=I=-14:TP=-1.5:LRA=11,atrim=0:" + str(duration) + "[mix]"
    else:
        filters = ("[0:a]aresample=48000,volume=0.62,apad[a];"
                   "[1:a]aresample=48000,volume=1.0,apad[b];"
                   "[a][b]amix=inputs=2:duration=longest:normalize=0,"
                   "loudnorm=I=-14:TP=-1.5:LRA=11,atrim=0:" + str(duration) + "[mix]")
    args += ["-filter_complex", filters, "-map", "[mix]", "-ar", "48000", "-ac", "2", os.fspath(output)]
    subprocess.run(args, check=True, capture_output=True, text=True, timeout=max(120, duration * 12))
    return output

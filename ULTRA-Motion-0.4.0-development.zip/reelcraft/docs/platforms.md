# Platform support

The shared skills describe the same creative process on both hosts. Runtime access, hooks, and scheduled execution belong to the host, so they are not assumed from plugin installation.

| Surface | Plan and review through skills | Run local renderer | Plugin lifecycle hooks | Durable scheduled work |
| --- | --- | --- | --- | --- |
| Claude Code with dependencies installed | Yes | Yes | Supported when configured | Use a separately configured scheduler or hosted routine |
| Claude chat | Yes | Only through a separately available execution tool or service | No | Separate host task feature, where available |
| Claude Cowork | Yes | Only where its environment exposes the required toolchain | Supported when configured | Separate Cowork task feature, where available |
| ChatGPT Chat | Yes | Only through a separately available execution tool or service | No | Separate host task feature, where available |
| ChatGPT Work or Codex with dependencies installed | Yes | Yes, in an execution environment | Supported after host trust review | Separate host task or external job runner |

The plugin packages eight shared skills, a local stdio MCP server, advisory session hooks, and an optional local runtime. The MCP protocol is tested directly; host connection and path-variable expansion remain install gates. It does not declare a remote MCP rendering service, an account connection, or a background scheduler. Public OpenAI plugin submission with local MCP requires an HTTPS server or a separate supported arrangement. Such a server would need its own deployment, authentication, storage, tool definitions, and end-to-end tests before those capabilities could be advertised.

## Manifests

- Root `plugin.json` is the portable Agent Plugins manifest used by OpenAI plugin surfaces. It discovers `skills/<name>/SKILL.md` automatically.
- `.claude-plugin/plugin.json` gives Claude Code its own plugin identity. Claude Code also discovers the root `skills/` directory.
- These manifests do not force either host to install system dependencies. Run `python3 scripts/studio.py doctor` in the environment that will render.
- A small `SessionStart` hook reads `project.json` only when the session starts inside a v1 project directory. If the plan is unapproved, it reminds the assistant to show the plan and obtain the user's explicit approval. It is silent elsewhere, writes nothing, and never approves a project. Claude Code and Codex use separate hook configuration paths; ordinary chats do not run these hooks. Plugin hooks may require trust review and an environment with Python 3. The runner enforces approval even if a hook is unavailable.
- An asynchronous hook cannot provide a durable background job by itself. The local runner owns background status and recovery.

## Synchronous and background execution

With `run --project DIR`, the local command waits for its work. With `run --project DIR --detach`, the local runner starts a job and returns control; use `status --project DIR` to observe it and the supported `retry` or `cancel` command to manage it. These are runner features, not automatic agent turns. An idle chat does not resume just because a background command finishes.

Do not treat a job as complete until the runner reports completion and the requested exports have been inspected. The project directory holds the approved input and outputs; keep it in storage appropriate to the host. A process on a temporary machine may not survive environment teardown.

## Installation and publishing

A checked-out repository can be loaded locally for testing. Its `.claude-plugin/marketplace.json` points to the plugin at the same repository root. After the repository is published, Claude Code users can add `owner/repo` as a marketplace and install `reelcraft@reelcraft-marketplace`; verify both the catalog and installed plugin with Claude Code before announcing the command. To import into ChatGPT where plugin ZIP upload is available, archive exactly one plugin directory with root `plugin.json` and `skills/`, then test a new conversation. To list it publicly in the ChatGPT/Codex directory, submit through that platform's review flow and publish it after approval. Neither directory listing is implied by pushing code to GitHub.

Cancellation is cooperative: a render subprocess is stopped by its owning worker; audio synthesis and review may finish their current operation before observing cancellation. Retry starts a new attempt and does not resume individual completed stages. Background work requires the host process environment to remain alive.

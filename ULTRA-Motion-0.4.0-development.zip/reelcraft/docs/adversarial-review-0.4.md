# Adversarial review and postmortem — 0.4.0

## Round 1: assumptions and asset evidence

Attack: replace an image at its original filename. A content-only plan digest could leave approval and outputs appearing current. The plan and scoped input digests now incorporate referenced bytes. Missing inputs produce stale outputs. Foreground and background starts both require the current asset-aware digest. Regression checks replace bytes, block background execution, approve a new plan, rerun and remove the input.

## Round 2: export edges and contradiction checks

Attack: request GIF timing that its centisecond timebase cannot preserve. Unsupported rates now fail before a successful export; actual encoded GIF/WebM frames, geometry, codec and duration are reopened and compared. Subtitle overlaps and millisecond-collapsed cues fail. Lottie rejects typography, images, audio and unsupported styles. PDF rejects unsupported standard-font text rather than silently lose glyphs. PPTX ratio and editable content are reopened. PCM placement is checked at an exact rational anchor; clipping and implicit resampling fail.

These gates deliberately expose current format limits. They do not fulfill the original unrestricted output or native-host requirements.

## Round 3: recovery and UI truth

Independent read-only review reproduced two branch defects: Git's quoted Unicode filenames failed restore, and legitimate stale drafts were rejected as corruption. Restore now reads NUL-delimited Git metadata, bounds file size/count, requires ordinary UTF-8 files, and checks artifact bytes separately from input freshness. A regression restores Arabic filenames and an edited draft, then confirms corrupt output is still rejected. Referenced inputs outside the snapshot's assets tree cannot be silently omitted.

Review also confirmed remaining native parity and per-control editing gaps. Root inspection found the room cleared its work list without displaying jobs. The list now displays state/attempt/error and cooperative controls. Result refresh keys include state, so stale output gains a visible regeneration warning. Script behavior checks verify draft preservation and the stale result warning. These checks are not browser visual QA.

Work definitions cannot replace a live graph while pause/cancel is pending. Runtime work/artifact records validate types, states, scoped paths and checksums. Malformed enum/reference commands reject without changing project revision.

## Remaining evidence

Native host install, native voice/tool interaction, browser layout/motion inspection, remote GitHub sync, other operating systems and human creative/consulting quality remain unqualified. Policy blocked local browser navigation; no alternate route was used to defeat that restriction. A passing local suite must not be presented as these checks passing.

# Export support — development 0.4.0

An output request is not a completed export. The work handler must succeed and its output must be reviewed. Every generated artifact has an input digest and SHA-256 checksum. Viewer acceptance remains separate from encoding and content checks.

| Format | Handler | Implemented scope | Checks and limits |
|---|---|---|---|
| MP4 | render_proof | Static title, panel, image or blank short drafts | Encoded frames, codec, dimensions; integer FPS 1–120; 128 Moments; 30 seconds; no audio |
| Alpha MOV | render_proof | Transparent short draft overlays | ProRes/alpha and frame checks; same draft limits |
| PNG | render_proof | Draft still | Decodable geometry; same scene constraints |
| WebM | render_proof | VP9 draft from checked MP4 | Reopened frames, dimensions and duration within 20 ms |
| GIF | render_proof | Palette draft | Exact centisecond rates: 1, 2, 4, 5, 10, 20, 25, 50, 100; reopened frames and duration |
| HTML | preview | Self-contained project snapshot | Text and pacing projection; proposed commands require a runner; native interaction unqualified |
| Markdown | executive_brief | Evidence-labelled text briefing | Decision, objective, claims and assumptions; source accuracy unqualified |
| JSON | compile_moments / export_outputs | Semantic compilation / full snapshot | Schema and round-trip content checks |
| SRT / VTT | export_outputs | Captions from Moment content | Rational millisecond rounding, overlap/collapse/control rejection; VTT markup escaping |
| Lottie JSON | export_outputs | Full-canvas solid panels or no graphics | Text, images, audio and other styles rejected; structural checks only; player acceptance pending |
| PDF | export_outputs | A4 decision/scene briefing | ReportLab and pypdf required; printable ASCII; reopened text; 512 Moments/250,000 text characters |
| PPTX | export_outputs | Editable text decision/scene briefing | python-pptx required; all four ratios; bounded text boxes and pagination; reopened editable text; font/viewer acceptance pending |
| WAV | assemble_audio | Exact-sample PCM assembly or explicit silence | 16-bit mono/stereo input at output sample rate; stereo output; gain 0–1; clipping rejected; samples reopened; 128 Moments/30 seconds |

Install optional document dependencies with `python3 scripts/setup.py --exports`. No dependency installation is implied by loading a skill. Run `runtime_doctor` through MCP for installed dependency status.

These exporters do not establish final motion design, sound mastering, generated speech, production storytelling or MBB consulting quality. Native-host voice and interaction must be tested in the target host. The existing v1 reel/B-roll workflow remains available separately and preserves its own contracts.

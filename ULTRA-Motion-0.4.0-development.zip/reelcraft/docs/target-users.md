# Target users and journeys

Reelcraft targets two kinds of motion work: a standalone product reel from a brief and brand assets, or graphics placed against an existing video. A timestamped SRT/VTT transcript helps B-roll placement but is optional in the current runner. The user should choose an outcome, not configure a pipeline.

**Current v1 boundary:** The local runner validates a scene timeline, requires approval of its digest, renders reel exports or a composite of scenes over source video, and creates contact sheets with objective media checks. The optional capture command reads bounded public HTML metadata and can make an offline screenshot. Discrete alpha clips and placement JSON are implemented. Automated creative shot selection, a comparison viewer, precise beat alignment, and full platform end-to-end installation checks remain goals. The journeys below describe the intended experience; see [acceptance](acceptance.md) for gate status.

## Priority and use cases

| Priority | User | Starting material | Job to be done | Useful delivery |
|---|---|---|---|---|
| P0 | Solo founder or indie maker | Product URL, brief, logo, screenshots | Launch or explain a product without a motion team | Short reel in selected social formats, review preview, editable project |
| P0 | Product marketer or growth lead | Campaign message, brand kit, CTA, product capture | Make consistent launch, feature, and paid social variants | Approved shotlist, format variants, source and export manifest |
| P0 | Educator, presenter, or video creator | Talking-head recording and timestamped transcript | Illustrate complex spoken ideas at the right moment | Cutaway clips, transparent panels, timing sheet, comparison preview |
| P0 | Video editor | Video, transcript, edit timeline, frame rate | Add graphics without rebuilding the edit | Import-ready clips with alpha where appropriate, exact in/out points |
| P1 | Agency producer or creative lead | Multiple brands and client briefs | Delegate repeatable production while retaining review control | Separate project workspaces, reusable brand presets, approval history |
| P1 | Motion designer | Existing design system and footage | Accelerate a first pass, then refine timing, type, and transitions | Readable scene/timeline source, stills, contact sheets, final renders |
| P1 | Community or social media manager | Product update and channel constraints | Adapt one story to vertical, square, and landscape placements | Safe-area-aware exports and phone-size readability review |
| P1 | Internal communications or enablement creator | Screen recording, narration, transcript | Explain a workflow with accurate UI and no invented numbers | Synchronized explainer graphics and evidence of source assets |
| P2 | Developer or automation engineer | Typed brief, assets, CI runner | Batch work, resume jobs, validate output programmatically | Stable CLI/JSON contract, job status, deterministic metadata, errors |
| P2 | Localization or accessibility reviewer | Draft text, captions, format variants | Verify legibility, captions, safe areas, and timing | Review sheet and explicit issues before approval |

## Two target paths

### Product reel

1. Describe the product, audience, duration, desired formats, message, and CTA. Import a brand preset or provide a URL and real assets.
2. Reelcraft checks inputs and dependencies. Unknown brand facts and claims are marked as unknown. The optional capture utility inspects public HTML only; accurate logos, fonts, and product imagery should be supplied as authorized local assets.
3. It proposes a style direction and exact shotlist, with text, duration, motion, sound, and format notes. The user approves or edits that plan.
4. The runner builds from the approved timeline, renders outputs, and produces objective review artifacts. A person or agent with visual access fixes defects and records subjective decisions.
5. The user reviews the output, then exports selected formats with source project and manifest.

### Motion B-roll for an existing edit

1. Provide the source video. Optionally provide SRT/VTT captions, brand assets, an edit reference, and export preferences.
2. In the target workflow, Reelcraft inspects video geometry, frame rate, audio, transcript timing when supplied, and available negative space. Without captions, the plan uses user-supplied or inspected time anchors and does not invent speech.
3. It proposes segments with exact in/out points and chooses full-frame cutaway, transparent overlay, or no graphic for each. The user approves the placement plan.
4. The target runner renders isolated clips at source timing, creates a composited preview, and checks alpha, frame boundaries, content accuracy, and readability. Current v1 produces a composite, a full alpha intermediate, and per-scene alpha clips.
5. The target handoff includes discrete clips, a timing/placement manifest, and side-by-side review material. Current v1 delivers clips, placement JSON, a composite, and a contact-sheet review page. The supplied original remains untouched.

## Interaction model

- **Synchronous:** intake validation, dependency diagnosis, brief analysis, plan generation, status, still-frame review, and manifest inspection. Return useful results promptly without waiting for a final video.
- **Asynchronous target:** multi-frame rendering, encoding, and batch format exports with a job ID, stage, progress, cancel, retry, and resumable completed stages. Current local runner supports detached execution, status, cancel, and retry; stage-level checkpoints and durable resume remain planned. Optional HTML capture is a separate synchronous command.
- **Approval:** a plan requires explicit approval before a costly build. An automated quality score is supporting evidence, not permission to publish, upload, or send files to a third party.
- **Platform:** CLI-capable Claude and ChatGPT environments can run the local engine. A chat-only environment can prepare a brief, shotlist, and review instructions, but rendering requires an available runner. Expose capabilities honestly at intake.

## Design priorities

1. The first choice is **make a reel** or **add graphics to my video**.
2. One clear intake round asks only for missing required information; presets fill known preferences.
3. Every output separates observed brand/product facts, supplied claims, and creative suggestions.
4. A single project directory holds approved brief, assets, timeline, render products, checks, and provenance.
5. Local paths and generated media remain private unless the user explicitly requests sharing or publishing.

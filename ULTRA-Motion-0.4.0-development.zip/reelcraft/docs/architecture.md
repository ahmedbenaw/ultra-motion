# Architecture

Reelcraft has a small shared interface and an explicit execution boundary.

| Layer | Responsibility | Durable artifact |
| --- | --- | --- |
| Skills | Intake, direction, approval, review, delivery instructions | Brief and review notes |
| Studio runner | Validate inputs, plan work, coordinate execution, report job state | Project state and logs |
| Timeline and assets | Describe the approved shots and their source material | Project specification and asset files |
| Renderer | Produce frames and encode supported video formats | Previews and exports |
| Review | Inspect observable picture and sound defects, then verify corrections | Timestamped findings |

The seven skills are `studio-director`, `brand-intake`, `timeline-plan`, `audio-design`, `motion-reel`, `motion-broll`, and `studio-review`. They can be invoked directly or selected from a natural language request. The code runner is `scripts/studio.py`, while the image sequence and export work use `renderer/render.mjs`. The model does creative interpretation; the scripts handle repeatable file and frame operations. The runtime should resolve plugin resources from its own installation directory and project artifacts from an explicit project path.

## Project flow

1. **Intake:** gather the product, audience, purpose, duration, formats, assets, soundtrack and narration choices. Mark unknown inputs instead of silently inventing them.
2. **Initialize:** create a distinct project directory from a versioned specification. Reject an occupied destination rather than overwrite another project.
3. **Plan:** derive a shot table, visual direction, timeline and expected exports. The assistant presents the plan for review.
4. **Approve:** the user explicitly approves or revises the plan. Only the approved plan can advance to execution. The CLI `approve --hash` command records an approval tied to the current plan digest; an agent must not invoke it merely to bypass the conversation gate.
5. **Build:** generate or arrange authorized assets, render previews, inspect them, and export requested formats. A detached run follows the same approval invariant.
6. **Review:** inspect contact sheets and clips, measure facts the tooling can measure, fix specific defects, and recheck affected outputs.
7. **Deliver:** provide locations, formats, duration, observed review result, and remaining limitations.

The v1 specification identifies a `reel` or `broll` workflow and contains input, scene timeline, format, and approval data. B-roll requires a local source video; SRT/VTT captions are optional. The runner copies supplied media into the project so the source remains untouched, then composes timed transparent graphics over the video when scenes call for them. Scripts should reject unknown or malformed schema versions with an actionable message rather than guessing. The precise file schema and defaults belong to the runner and its examples; use its installed `--help` and validation output.

## Reliability boundaries

- **Repeatable frames:** when a scene is deterministic, seeking to the same timestamp should return the same visual result. Test this for any custom animation or generated variation.
- **No hidden overwrite:** distinct project directories and explicit file ownership avoid one run replacing another's assets or outputs.
- **Observable jobs:** a detached run needs a project identifier, status, error output, and clear retry/cancel behavior. A queued or running job is not a delivered video.
- **Useful failure:** missing ffmpeg, Node, Python packages, files, network permission, optional audio credentials, or Chromium when the browser render path is selected should be reported before the relevant stage starts.
- **Human review:** code can measure render and audio properties; someone must inspect visual meaning, brand accuracy, legibility, and pacing. Do not turn a fabricated score into a completion gate.
- **Rights and privacy:** copy only assets the user supplies or is authorized to use. External capture and optional voice services are separate capabilities and must be disclosed before data is sent.

The package is skills first. A remote rendering service, scheduler, and additional host adapters can be added without changing the approved project specification or the shared skill names, once their execution and recovery behavior has been tested.

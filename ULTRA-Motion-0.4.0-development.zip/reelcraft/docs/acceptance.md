# Acceptance criteria and evaluation plan

These are **target release gates**, not a claim that the current implementation passes them. Each criterion calls for observable evidence. The small offline fixtures in `evals/fixtures/` define cases; `evals/validate-fixtures.py` validates only fixture integrity, not an actual Reelcraft render. Artistic decisions require human review.

## Current coverage (2026-09-29)

| Area | Implemented or tested in code | Remaining acceptance work |
|---|---|---|
| Local project | Schema validation, digest approval, isolated creation, run/status/retry/cancel; some unit tests | Run the full approved project journey on each claimed platform; verify background recovery and error paths. |
| Reel rendering | Timed title/panel/image scenes, format exports, media probe, contact sheets, local audio bed | Synthetic reel integration and final audio measurement pass. Fixture story fidelity, human readability, and production critique rounds remain open. |
| B-roll | Source-video composite with timed graphics; SRT/VTT input is optional; renderer can produce alpha intermediate | Alpha visibility, discrete clips and placement JSON have integration coverage. Transcript-driven creative planning, frame-exact placement and comparison viewer require further review. |
| Timing and sound | A basic beat estimator and BPM grid exist in `studio/timing.py`; synthesized/supplied audio can be mixed | Integrate measured beats with scene events and verify synchronization and measured final loudness/peak. |
| Capture | Optional bounded HTTPS HTML metadata/provenance command and offline screenshot path with network-free unit tests | Integrate capture into the intake flow, test a permitted public site in a controlled environment, and verify screenshot quality. |
| Cross-platform | Shared skill files and plugin manifests exist | Fresh-install tests in each advertised host; chat-only rendering remains unavailable without a runner. |

**Status key for the gates below:** A documented intent or isolated unit test is not an end-to-end pass. Unless a passing test/report is linked to a gate, treat it as open. In particular, the four `evals/cases.json` cases are specifications to execute, not recorded results.

## A. Install and platform routing

| ID | Scenario | Pass condition |
|---|---|---|
| A01 | Fresh checkout in each documented CLI environment | Install instructions complete; the doctor reports tool versions and checks Node, Python, ffmpeg/ffprobe, browser, codecs, and Python packages before a render. |
| A02 | Missing ffmpeg or browser | Doctor fails with the missing dependency and one actionable remedy; no partial final artifact is labeled successful. |
| A03 | Chat-only environment | The agent produces a brief/shotlist and clearly identifies the runner needed for media generation. It never claims to have rendered a file. |
| A04 | Existing unrelated project files | Init creates a distinctive isolated project path, refuses an accidental overwrite, and leaves other files intact. |
| A05 | Packaged install | Skills and entry points are discoverable in both advertised environments; commands resolve paths independent of current working directory. |

## B. Shared workflow and safety of content

| ID | Scenario | Pass condition |
|---|---|---|
| B01 | Incomplete brief | Missing required values appear in one concise intake round; optional fields are defaulted only as documented. |
| B02 | Plan approval | A complete plan names exact on-screen words, in/out time, placement, audio, and target format. Rendering is gated until explicit approval or an automation policy supplied by the user. |
| B03 | Unsupported claim | Numeric results or product features absent from supplied material are flagged, omitted, or represented as nonliteral placeholders. They are never asserted as product facts. |
| B04 | Source capture | Asset manifest records source path/URL and capture time; a blocked URL yields a recoverable request for local assets. |
| B05 | Interrupted asynchronous job | Status reports the last completed stage. Retry starts a fresh isolated attempt; final outputs are atomic and never corrupt prior approved files. |
| B06 | Repeat run | An unchanged timeline and assets render identical test frames at selected timestamps under the same engine/environment. |
| B07 | No silent external action | Evaluation does not publish a video, send messages, or upload user material. |

## C. Product reel

| ID | Scenario | Pass condition |
|---|---|---|
| C01 | `reel-basic` fixture | The proposed story includes hook, product demonstration, and CTA; all product text traces to fixture fields. |
| C02 | Measured beat grid | Timeline events reference measured beats or documented free timing; sync report identifies visual/audio offsets. |
| C03 | Selected output formats | Each requested export has intended geometry, playable H.264 video, compatible audio where requested, and duration within one frame of the timeline target or a documented encoder tolerance. |
| C04 | Phone and safe-area review | Review includes a 360 px view and safe-area overlays for vertical output; text is legible and critical elements avoid declared platform zones. |
| C05 | Audio | A mixed output is measured for integrated loudness and true peak against project targets; warnings prevent an unqualified pass. Silent projects are explicitly marked silent. |
| C06 | Quality loop | At least three documented critique passes for a production reel when the configured policy requires it; each records observed evidence, changed items, and unresolved issues. No fabricated score. |

## D. Motion B-roll

| ID | Scenario | Pass condition |
|---|---|---|
| D01 | `broll-basic` fixture with captions | Plan maps each proposed graphic to a transcript line and time interval, with a reason for cutaway, overlay, or no graphic. A separate no-caption case must use user-provided or inspected anchors without inventing spoken lines. |
| D02 | Frame alignment | Rendered clips report frame rate and dimensions compatible with source; start/end placement error is at most one source frame, subject to a stated container timebase tolerance. |
| D03 | Transparent overlay | Alpha is actually present and survives export in the documented overlay codec; preview composites it over source correctly. |
| D04 | Review package | Source video is preserved, and deliverables include discrete clips, placement manifest, composite preview, and a comparison view. |
| D05 | Transcript mismatch | Missing or nonmonotonic timestamps, text beyond source duration, and empty transcript produce clear validation errors or warnings before rendering. |
| D06 | Numeric graphics | The fixture's qualitative comparison does not turn into invented percentages or chart values. |

## E. Evaluation levels

1. **Static:** validate fixture schema, path traversal rejection, transcript order, and timeline bounds.
2. **Unit:** test closed-form motion at arbitrary out-of-order seek times and formatting/timecode arithmetic.
3. **Integration:** use the offline fixture to render one short reel and one short B-roll example. Probe actual media with `ffprobe`, inspect representative frames, and test alpha with a checkerboard composite.
4. **End to end:** drive each advertised platform through intake, plan approval, asynchronous status, failure recovery, and delivery.
5. **Human review:** a reviewer checks storytelling, brand fidelity, legibility, pacing, motion quality, audio, and placement against the approved plan. Record the reviewer, evidence, and remaining issues. An automated score alone cannot establish this gate.

The fixture runner may synthesize a six-second source video using ffmpeg. The fixtures themselves contain no third-party media, user identities, or paid service credentials.

# Verification and release postmortem

## Candidate 0.1.1 — 2026-09-29

This is an original implementation with local execution. It is a release candidate, not a guarantee of defect-free operation or universal host compatibility.

| Check | Observed result | Evidence |
|---|---|---|
| Python tests | 22 passed | `python3 -m unittest discover -s studio/tests -v` |
| Renderer tests | 4 passed, none skipped | `npm test` |
| Fixture integrity | Four cases and two transcript cues valid | `python3 evals/validate-fixtures.py` |
| Native reel journey | Real H.264/AAC output, detached status, measured audio and review artifacts pass | `studio/tests/test_pipeline.py` |
| Native B-roll journey | Composite, visible and transparent alpha, source preservation and audio pass | `studio/tests/test_pipeline.py` |
| Alpha export regression | Complete 60-frame MOV; all four draft formats encode with even dimensions | `renderer/test/render.test.mjs` |
| Approval and assets | Changed plan or imported media blocks execution | `studio/tests/test_core.py` |
| MCP transport | Initialize, tool discovery and path escape rejection pass over stdio | `studio/tests/test_core.py` |
| Capture boundaries | Eleven tests cover public HTTPS, DNS, redirects, size limits and offline screenshot opt-in/dispatch | `studio/tests/test_capture.py` |
| Independent review | GPT-5.6-sol found validator and path-resolution defects; fixes covered by regression tests | `studio/tests/test_core.py`, `docs/decisions.tsv` |

## Postmortem rounds

### 1. Export evidence

An early composite appeared to complete although an intermediate MOV was incomplete, and transparent panels had no visible alpha. File existence was insufficient evidence. Exports now stage to temporary files, verify geometry, codec, complete frame count and duration with ffprobe, and rename only after validation. Native drawbox explicitly replaces alpha. The B-roll runner decodes alpha at a content timestamp and requires both transparent and visible pixels. Regression tests exercise real media rather than mock success.

### 2. Approval boundary

Independent review reproduced a plan that passed Python validation but failed Node validation after approval. Base styles and format overrides now share complete Python checks, including merged default geometry and positive dimensions. Relative CLI asset paths now resolve from the specification's directory. Tests reproduce invalid overrides and a specification outside the launch directory.

### 3. Delivery claims

Documentation now distinguishes implemented tools from target journeys. Seven skills and eight local MCP tools are packaged. Sync and detached rendering are real runner features; durable scheduling and autonomous chat wake-up are not. Review reports contain measured media properties and a pending creative review, not a fabricated quality score. Retry creates a new attempt. A cancelled worker must finish before another attempt starts.

## Open gates

- Chromium could not be installed successfully in the build environment; browser animation, screenshot rendering and browser alpha exports remain unverified. The native engine produces timed static scenes and reports this limitation.
- Claude and OpenAI plugin discovery, MCP path expansion and hook trust must be checked in fresh supported host installations. No host install has been claimed.
- Windows and macOS execution have not been exercised. Python command names and platform media dependencies may need configuration.
- Hosted execution, durable scheduling, comparison viewer, generated voice services, automatic footage selection and beat-to-scene synchronization are not shipped.
- Human review of brand accuracy, story, legibility, pacing and motion is required before a production delivery. Synthetic integration fixtures prove encoding and orchestration, not artistic quality.
- CI is included but has not run on a public remote repository. Public GitHub publication is pending repository creation.

## Reproduce

Install Python 3.10+, Node 22+, FFmpeg/ffprobe, then run:

```bash
python3 scripts/setup.py
python3 -m unittest discover -s studio/tests -v
npm test
python3 evals/validate-fixtures.py
python3 scripts/package.py --output ../reelcraft-0.1.1.zip
```

Native tests need FFmpeg. Browser installation is opt-in through `python3 scripts/setup.py --browser`; use `--engine browser` for a strict renderer check that cannot silently fall back. The studio currently selects `auto` and records the actual engine in export evidence.

## Development 0.4.0 — 3 October 2026

- 69 Python behavioral tests passed with no skips in this Linux environment.
- Seven Node tests passed with no skips: four deterministic/native-media checks and three project-room script behavior checks. The latter are not browser layout tests.
- Four legacy fixtures and two transcript cues validate.
- Three synthetic portable engagements pass: mobile product, consulting decision (real background worker), academic explanation. They exercise current approval, generated files, supplied-input arithmetic, stale edits, regeneration and local branch save/restore. See `evals/results/portable-linux.json`.
- Independent adversarial review reproduced Unicode filename and stale-draft restore failures. Regression fixes preserve valid drafts while rejecting corrupted artifact bytes. See `docs/adversarial-review-0.4.md`.
- New exporters, recipe proposals/composition, referenced asset hashes and exact-sample PCM assembly have executable tests. See `docs/exports.md` for supported constraints.
- Local preview was rejected by the cloud browser; file navigation was explicitly prohibited. Browser layout, animation and accessibility inspection remain unqualified. No bypass was attempted.
- The runtime doctor reports Node/Python/FFmpeg ready and Chromium absent. Native-host installs, native voice and native live-artifact interaction remain unqualified; this is a development package, not the complete requested product.

Reproduce the additional portable engagement evidence with:

```bash
python3 scripts/setup.py --exports
python3 evals/run-engagements.py --output evals/results/portable-linux.json
```

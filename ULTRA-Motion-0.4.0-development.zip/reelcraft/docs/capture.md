# Optional brand capture

Run `python3 scripts/capture.py https://public.example --output path/to/new-assets` to inspect a public product page. Add `--screenshot` only when Playwright and Chromium are installed. The command writes `provenance.json` and, when requested, `page-offline.png`.

The capture fetches a bounded HTML document over HTTPS, checks every DNS answer and redirect destination for public routing, and pins the vetted IP to the TLS connection. It does not fetch linked fonts, images, logos, scripts, or stylesheets. Metadata includes title, description, theme color, inline CSS color candidates, Open Graph values, response hash, and redirect hops. The optional screenshot renders the fetched HTML **offline** with JavaScript and external requests blocked; it may differ substantially from the live page. Provide authorized local brand assets for accurate production.

Default limits: 2 MiB HTML, 12 seconds for the HTTPS fetch including DNS and redirects, three redirects, and HTTPS port 443. The optional offline screenshot has its own bounded browser operations. Capture is an explicit action; it is not part of project initialization.
